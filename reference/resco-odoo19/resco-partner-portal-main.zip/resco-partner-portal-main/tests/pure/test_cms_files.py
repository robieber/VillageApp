from decimal import Decimal

import cms_files as c
from fixtures import COMP, HDR, HRLY, PAY, comp_rows, csv, hdr_row

KNOWN = {'CS-1': 'Acme Mill 1', 'CS-2': 'Acme Mill 2'}
PDF = b'%PDF-1.7\n'
K1 = 'CS-1-202609-B1'


def batch(hdr_rows, comp=None, extra=None, pdfs=('202609-CS-1.pdf',)):
    files = {'MPWR_BILL_HDR_202609.csv': csv(HDR, *hdr_rows),
             'MPWR_BILL_COMP_202609.csv': csv(COMP, *(comp if comp is not None else comp_rows(K1)))}
    files.update({p: PDF for p in pdfs})
    files.update(extra or {})
    return files


def test_classify():
    assert c.classify('MPWR_BILL_HDR_202609.csv') == 'header'
    assert c.classify('mpwr_bill_comp_1.CSV') == 'components'
    assert c.classify('MPWR_PAY_STAT_1.csv') == 'payment'
    assert c.classify('MPWR_ENERGY_HRLY_1.csv') == 'hourly'
    assert c.classify('MPWR_BILL_PDF_1.csv') == 'manifest'
    assert c.classify('x.pdf') == 'pdf' and c.classify('other.csv') is None


def test_valid_batch():
    r, pdfs = c.parse_batch(batch([hdr_row()]), KNOWN)
    assert not r.errors and not r.warnings
    b = r.bills[0]
    assert (b.key, b.bill_key, b.fields['payment_status'], b.fields['total_amount']) == (('CS-1', 2026, 9), K1, 'unpaid', Decimal('1120.00'))
    assert [x.code for x in b.components] == ['GEN', 'TRANS']
    assert b.fields['extract_timestamp'].hour == 2          # 10:00+08:00 is 02:00 UTC


def test_total_must_balance():
    r, _ = c.parse_batch(batch([hdr_row(total='1000.00')]), KNOWN)
    assert not r.bills and 'must equal PREVIOUS_BALANCE' in r.errors[0].message
    r, _ = c.parse_batch(batch([hdr_row(total='1620.00', prev='500', adj='0')]), KNOWN)
    assert len(r.bills) == 1


def test_components_vs_current_charges_is_a_warning():
    r, _ = c.parse_batch(batch([hdr_row()], comp=comp_rows(K1, gen='900.00')), KNOWN)
    assert len(r.bills) == 1 and 'differs from CURRENT_CHARGES' in r.warnings[0].message


def test_all_or_nothing_per_bill():
    rows = [hdr_row(), hdr_row(csin='CS-2', name='Acme Mill 2', status='BOGUS')]
    comps = comp_rows(K1) + comp_rows('CS-2-202609-B1')
    r, _ = c.parse_batch(batch(rows, comps, pdfs=('202609-CS-1.pdf', '202609-CS-2.pdf')), KNOWN)
    assert [b.csin for b in r.bills] == ['CS-1']
    assert len(r.errors) == 1 and 'PAYMENT_STATUS' in r.errors[0].message     # no extra noise for its components


def test_bad_component_rejects_its_bill():
    comps = comp_rows(K1) + [f'{K1},GEN,Generation Again,,,,5.00,30']
    r, _ = c.parse_batch(batch([hdr_row()], comps), KNOWN)
    assert not r.bills and 'appears twice' in r.errors[0].message


def test_missing_components_pdf_and_unknown_account():
    r, _ = c.parse_batch(batch([hdr_row()], comp=[]), KNOWN)
    assert 'no cost components' in r.errors[0].message
    r, _ = c.parse_batch(batch([hdr_row()], pdfs=()), KNOWN)
    assert 'was not supplied' in r.errors[0].message
    r, _ = c.parse_batch(batch([hdr_row(csin='CS-9')], []), KNOWN)
    assert 'does not exist' in r.errors[0].message


def test_revised_needs_supersedes_and_payment_statuses():
    r, _ = c.parse_batch(batch([hdr_row(revised='Y')]), KNOWN)
    assert 'SUPERSEDES_BILL_KEY is required' in r.errors[0].message
    for raw, want in (('Partially Paid', 'partial'), ('PARTIALLY_PAID', 'partial'), ('overdue', 'overdue'), ('PAID', 'paid')):
        r, _ = c.parse_batch(batch([hdr_row(status=raw)]), KNOWN)
        assert r.bills[0].fields['payment_status'] == want
    r, _ = c.parse_batch(batch([hdr_row(status='FOR_VALIDATION')]), KNOWN)
    assert r.errors      # proof-of-payment states live on the payment submission, not on the CMS-RES bill


def test_duplicates_inside_batch():
    rows = [hdr_row(), hdr_row(num='B2', pdf='other.pdf')]
    r, _ = c.parse_batch(batch(rows, comp_rows(K1) + comp_rows('CS-1-202609-B2'), pdfs=('202609-CS-1.pdf', 'other.pdf')), KNOWN)
    assert len(r.bills) == 1 and 'second bill' in r.errors[0].message


def test_payment_updates_batch_or_existing_only():
    pay = csv(PAY, f'{K1},PAID,1120.00,0,2026-10-05,2026-10-05T09:00:00+08:00', 'NOPE,PAID,1,0,,2026-10-05T09:00:00+08:00')
    r, _ = c.parse_batch(batch([hdr_row()], extra={'MPWR_PAY_STAT_1.csv': pay}), KNOWN)
    assert len(r.payments) == 1 and r.payments[0]['payment_status'] == 'paid' and 'No bill with this BILL_KEY' in r.errors[0].message
    r, _ = c.parse_batch({'MPWR_PAY_STAT_1.csv': pay}, KNOWN, existing_keys={K1})
    assert len(r.payments) == 1


def test_hourly():
    h = csv(HRLY, 'CS-1,2026-09-01T00:00:00+08:00,10.5,12', 'CS-1,2026-09-01T01:00:00+08:00,9,', 'CS-1,2026-09-01T01:00:00+08:00,9,',
            'CS-9,2026-09-01T00:00:00+08:00,1,', 'CS-1,2026-09-01T02:00:00+08:00,-3,')
    r, _ = c.parse_batch({'MPWR_ENERGY_HRLY_202609.csv': h}, KNOWN)
    assert [(i[0], str(i[1]), i[2], i[3]) for i in r.intervals] == [
        ('CS-1', '2026-08-31 16:00:00', Decimal('10.5'), Decimal('12')), ('CS-1', '2026-08-31 17:00:00', Decimal('9'), None)]
    assert len(r.errors) == 3


def test_unknown_and_manifest_files_and_empty_batch():
    r, _ = c.parse_batch(batch([hdr_row()], extra={'MPWR_BILL_PDF_202609.csv': b'Title', 'notes.csv': b'x', 'unused.pdf': PDF}), KNOWN)
    msgs = ' | '.join(w.message for w in r.warnings)
    assert 'manifest ignored' in msgs or 'Salesforce' in msgs
    assert 'not recognised' in msgs and 'not referenced' in msgs
    r, _ = c.parse_batch({'a.pdf': PDF}, KNOWN)
    assert 'no CSV' in r.errors[0].message


def test_non_pdf_content_and_missing_columns_and_cp1252():
    r, _ = c.parse_batch(batch([hdr_row()], extra={'202609-CS-1.pdf': b'<html>'}), KNOWN)
    assert any('not a PDF' in e.message for e in r.errors) and not r.bills
    r, _ = c.parse_batch({'MPWR_BILL_HDR_1.csv': b'BILL_KEY,CSIN\nx,y\n'}, KNOWN)
    assert 'Missing column' in r.errors[0].message
    assert c.decode_csv('Peñafrancia'.encode('cp1252')) == 'Peñafrancia'


def test_safe_file_name():
    assert c.safe_file_name('../../a.pdf') == 'a.pdf'


# ---- accounts and control totals --------------------------------------------------------------------------------
ACCT = ('CSIN,ACCOUNT_NAME,PARENT_COMPANY_ID,PARENT_COMPANY_NAME,SERVICE_ADDRESS,PRICING_PRODUCT,CONTRACTED_CAPACITY_KW,'
        'MEQ_KWH,CONTRACT_START,CONTRACT_END,SAM_NAME,SAM_EMAIL,PRIMARY_CONTACT_NAME,PRIMARY_CONTACT_EMAIL,'
        'PRIMARY_CONTACT_MOBILE,ACCOUNT_STATUS')


def test_accounts_parse_and_new_account_is_known_to_bills_in_the_same_batch():
    row = 'CS-7,Seven Mill,PC7,Seven Group,Pasig,Fixed,500,1000,2024-01-26,2027-01-25,Sam,sam@x.com,Ana,ANA@X.COM,0917,Active'
    files = batch([hdr_row(csin='CS-7', name='Seven Mill')], comp_rows('CS-7-202609-B1'), pdfs=('202609-CS-7.pdf',))
    files['MPWR_ACCOUNT_SAMPLE.csv'] = csv(ACCT, row)
    r, _ = c.parse_batch(files, {})
    assert not r.errors and len(r.bills) == 1
    a = r.accounts[0]
    assert (a['csin'], a['company'], a['contact_email'], a['active'], a['capacity']) == ('CS-7', 'Seven Group', 'ana@x.com', True, Decimal('500'))
    assert str(a['end']) == '2027-01-25'


def test_account_rows_are_checked_one_by_one():
    rows = ['CS-1,A,PC1,Co,,,,,,,,,,not-an-email,,Active', 'CS-2,B,PC1,Co,,,-5,,,,,,,,,Active', 'CS-3,C,PC1,Co,,,,,,,,,,,,Inactive',
            'CS-3,C,PC1,Co,,,,,,,,,,,,Active']
    r, _ = c.parse_batch({'MPWR_ACCOUNT_X.csv': csv(ACCT, *rows)}, {})
    assert [e.key for e in r.errors] == ['CS-1', 'CS-2', 'CS-3']
    assert [a['csin'] for a in r.accounts] == ['CS-3'] and r.accounts[0]['active'] is False
    assert any('No PRIMARY_CONTACT_EMAIL' in w.message for w in r.warnings)


CTRL = 'EXTRACT_BATCH_ID,FILE_NAME,ROW_COUNT,CONTROL_FIELD,CONTROL_TOTAL,EXTRACT_TIMESTAMP'


def test_control_totals_match_and_mismatch():
    ok = batch([hdr_row()])
    ok['MPWR_CTRL_202609.csv'] = csv(CTRL, 'B1,MPWR_BILL_HDR_202609.csv,1,TOTAL_AMOUNT_DUE,1120.00,2026-10-05T08:00:00+08:00',
                                     'B1,MPWR_BILL_COMP_202609.csv,2,AMOUNT,1000.00,2026-10-05T08:00:00+08:00')
    r, _ = c.parse_batch(ok, KNOWN)
    assert not r.errors and len(r.bills) == 1
    bad = dict(ok)
    bad['MPWR_CTRL_202609.csv'] = csv(CTRL, 'B1,MPWR_BILL_HDR_202609.csv,1,TOTAL_AMOUNT_DUE,9999.00,2026-10-05T08:00:00+08:00')
    r, _ = c.parse_batch(bad, KNOWN)
    assert not r.bills and 'Control total' in r.errors[0].message and 'Nothing was loaded' in r.errors[-1].message
    short = dict(ok)
    short['MPWR_CTRL_202609.csv'] = csv(CTRL, 'B1,MPWR_BILL_HDR_202609.csv,5,TOTAL_AMOUNT_DUE,1120.00,2026-10-05T08:00:00+08:00')
    r, _ = c.parse_batch(short, KNOWN)
    assert not r.bills and 'may be incomplete' in r.errors[0].message
