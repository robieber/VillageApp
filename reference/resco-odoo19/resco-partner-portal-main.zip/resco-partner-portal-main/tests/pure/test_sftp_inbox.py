import sftp_inbox as s


class Fake(s.Transport):
    def __init__(self, files):
        self.files = dict(files)

    def isdir(self, path):
        p = path.rstrip('/') + '/'
        return any(f.startswith(p) for f in self.files)

    def listdir(self, path):
        p = path.rstrip('/') + '/'
        return sorted({f[len(p):].split('/')[0] for f in self.files if f.startswith(p)})

    def read(self, path):
        return self.files[path]

    def write(self, path, data):
        self.files[path] = data

    def move(self, src, dst):
        self.files[dst] = self.files.pop(src)

    def makedirs(self, path):
        pass


def test_only_folders_with_marker_are_ready():
    t = Fake({
        '/inbound/B1/MPWR_BILL_HDR_202610.csv': b'x', '/inbound/B1/a.pdf': b'%PDF-', '/inbound/B1/B1.done': b'',
        '/inbound/B1/notes.txt': b'x',
        '/inbound/B2/MPWR_BILL_HDR_202611.csv': b'x',          # no marker yet
    })
    ready = s.find_ready_batches(t)
    assert [b.name for b in ready] == ['B1']
    assert set(ready[0].paths) == {'MPWR_BILL_HDR_202610.csv', 'a.pdf'}


def test_no_inbound_folder():
    assert s.find_ready_batches(Fake({})) == []


def test_archive_moves_everything_and_writes_result():
    t = Fake({'/inbound/B1/h.csv': b'x', '/inbound/B1/a.pdf': b'%PDF-', '/inbound/B1/B1.done': b''})
    b = s.find_ready_batches(t)[0]
    dest = s.archive_batch(t, b, True, 'ok')
    assert dest == '/processed/B1'
    assert not [p for p in t.files if p.startswith('/inbound/')]
    assert t.files['/processed/B1/result.txt'] == b'ok'
    s.archive_batch(Fake({}), b, False, 'bad') if False else None
