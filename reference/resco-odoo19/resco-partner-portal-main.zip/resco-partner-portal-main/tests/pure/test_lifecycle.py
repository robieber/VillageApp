from datetime import date

import lifecycle as l


def test_deactivation_date_takes_earlier_rule():
    # last bill 1 Jan -> 1 Mar; activity 1 Feb -> 1 May
    assert l.deactivation_date(date(2026, 1, 1), date(2026, 2, 1)) == date(2026, 3, 1)
    # recent bill, stale activity
    assert l.deactivation_date(date(2026, 9, 1), date(2026, 1, 10)) == date(2026, 4, 10)


def test_never_logged_in_counts_from_creation():
    assert l.deactivation_date(None, None, date(2026, 1, 31)) == date(2026, 4, 30)
    assert l.deactivation_date(None, None, None) is None


def test_state_warn_then_deactivate():
    dd = date(2026, 3, 1)
    assert l.deactivation_state(date(2026, 2, 1), dd, None) is None
    assert l.deactivation_state(date(2026, 2, 15), dd, None) == 'warn'
    assert l.deactivation_state(date(2026, 2, 20), dd, date(2026, 2, 15)) is None   # already warned
    assert l.deactivation_state(date(2026, 3, 1), dd, date(2026, 2, 15)) == 'deactivate'
    assert l.deactivation_state(date(2026, 3, 5), dd, None) == 'deactivate'


def test_new_bill_after_warning_rewarns_later():
    # warned for an older date; deactivation date has since moved out; the old warning must not suppress the new one
    assert l.deactivation_state(date(2026, 6, 20), date(2026, 7, 1), date(2026, 2, 15)) == 'warn'


def test_offsets_and_reminders():
    assert l.parse_offsets('5, 1,-1, x') == [5, 1, -1]
    off = [5, 1, -1]
    due = date(2026, 10, 15)
    assert l.reminder_due(date(2026, 10, 10), due, off)
    assert l.reminder_due(date(2026, 10, 14), due, off)
    assert l.reminder_due(date(2026, 10, 16), due, off)
    assert not l.reminder_due(date(2026, 10, 12), due, off)
