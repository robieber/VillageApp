import user_import as u


def test_good_file():
    rows, errs = u.parse(u.TEMPLATE)
    assert not errs and len(rows) == 1
    assert rows[0]['csins'] == ['CS-100234', 'CS-100235'] and rows[0]['role'] == 'billing' and rows[0]['action'] == 'add'


def test_defaults_bom_and_blank_lines():
    rows, errs = u.parse('\ufeffemail,csins\n\nA@B.com,CS-1\n')
    assert not errs and rows[0]['email'] == 'a@b.com' and rows[0]['role'] == 'viewer'


def test_problems_are_reported_by_row():
    text = 'EMAIL,ROLE,CSINS,ACTION\nbad,viewer,CS-1,add\na@b.com,boss,CS-1,add\nc@d.com,viewer,,add\na@b.com,viewer,CS-1,add\ne@f.com,viewer,,deactivate\ng@h.com,viewer,CS-1,remove\n'
    rows, errs = u.parse(text)
    assert [r['email'] for r in rows] == ['e@f.com']
    assert [e[0] for e in errs] == [2, 3, 4, 5, 7]


def test_header_and_size():
    assert u.parse('')[1][0][0] == 0
    assert 'EMAIL column' in u.parse('name\nx\n')[1][0][1]
    big = 'email,csins\n' + ''.join(f'u{i}@x.com,CS-1\n' for i in range(600))
    rows, errs = u.parse(big)
    assert len(rows) == u.MAX_ROWS and errs and 'More than' in errs[-1][1]
