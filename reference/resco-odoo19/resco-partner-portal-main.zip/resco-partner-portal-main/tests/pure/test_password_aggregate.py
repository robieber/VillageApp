import aggregate as a
import password_policy as pp


def test_password_policy():
    assert pp.check('Str0ng!Passw0rd', 'juan@acme.com') == []
    assert 'at least 12 characters' in pp.check('Sh0rt!pw')
    assert 'a symbol' in pp.check('NoSymbol12345Aa')
    assert 'a number' in pp.check('NoNumber!!!!Aaaa')
    assert 'an uppercase letter' in pp.check('lowercase1!lowercase')
    assert 'no part of your email address' in pp.check('XjuandelaX1!Passwrd', 'juandela@acme.com')
    assert pp.message([]) == '' and 'needs' in pp.message(['a number'])


def test_billing_history_stacks_accounts_and_fills_gaps():
    rows = [(2026, 8, 'Gen', 100), (2026, 8, 'Gen', 50), (2026, 8, 'VAT', 18), (2026, 10, 'Gen', 70)]
    r = a.billing_history(rows, months=4)
    assert [p['period'] for p in r['periods']] == ['2026-07', '2026-08', '2026-09', '2026-10']
    assert r['periods'][1]['values'] == {'Gen': 150, 'VAT': 18} and r['periods'][1]['total'] == 168
    assert r['periods'][2]['total'] == 0
    assert r['components'] == ['Gen', 'VAT']


def test_billing_history_crosses_year_and_is_empty_safe():
    r = a.billing_history([(2026, 2, 'Gen', 1)], months=3)
    assert [p['period'] for p in r['periods']] == ['2025-12', '2026-01', '2026-02']
    assert a.billing_history([]) == {'components': [], 'periods': []}


def test_billing_history_drops_components_outside_window():
    r = a.billing_history([(2024, 1, 'Old', 5), (2026, 10, 'Gen', 1)], months=12)
    assert r['components'] == ['Gen']


def test_energy_yearly_clusters():
    r = a.energy_yearly([(2026, 1, 100, 90), (2026, 1, 50, None), (2026, 3, 7, None), (2025, 1, 9, 9)], 2026)
    assert r['months'][0] == {'month': 1, 'energy_kwh': 150.0, 'meq_kwh': 90.0}
    assert r['months'][2]['meq_kwh'] is None and len(r['months']) == 12


def test_energy_daily_uses_philippine_time():
    from datetime import datetime
    rows = [(datetime(2026, 8, 31, 16, 0), 10, 12), (datetime(2026, 9, 1, 3, 0), 5, 20), (datetime(2026, 9, 30, 16, 0), 1, None)]
    r = a.energy_daily(rows, 2026, 9)
    assert len(r['days']) == 30
    assert r['days'][0] == {'day': 1, 'kwh': 15.0, 'peak_kw': 20.0}      # 00:00 and 11:00 PH time on 1 Sep
    assert r['days'][29]['kwh'] == 0.0                                    # 30 Sep 16:00 UTC is already 1 Oct in PH
    assert a.energy_daily([], 2026, 2)['days'][-1]['day'] == 28


def test_energy_hourly():
    from datetime import date, datetime
    r = a.energy_hourly([(datetime(2026, 8, 31, 16, 0), 10, 12), (datetime(2026, 9, 1, 17, 0), 3, None)], date(2026, 9, 1))
    assert r['hours'][0] == {'hour': 0, 'kwh': 10.0, 'kw': 12.0} and r['hours'][1]['kwh'] == 0 and len(r['hours']) == 24
