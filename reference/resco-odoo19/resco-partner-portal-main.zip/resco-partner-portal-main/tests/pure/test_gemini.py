import pytest
import gemini as g


def text(t):
    return 200, {'candidates': [{'content': {'role': 'model', 'parts': [{'text': t}]}}]}


def call(name, args):
    return 200, {'candidates': [{'content': {'role': 'model', 'parts': [{'functionCall': {'name': name, 'args': args}}]}}]}


def make_post(*replies):
    sent = []
    it = iter(replies)

    def post(url, headers, body):
        sent.append((url, headers, body))
        return next(it)
    return post, sent


def test_plain_answer():
    post, sent = make_post(text('Hello'))
    out, called = g.run_turn(post, 'gemini-flash-latest', 'KEY', 'sys', [{'role': 'user', 'parts': [{'text': 'hi'}]}], [], lambda n, a: {})
    assert (out, called) == ('Hello', [])
    assert sent[0][0].endswith('models/gemini-flash-latest:generateContent')
    assert sent[0][1]['x-goog-api-key'] == 'KEY'
    assert 'tools' not in sent[0][2]


def test_tool_round_trip():
    post, sent = make_post(call('list_bills', {'limit': 2}), text('You have 2 bills.'))
    out, called = g.run_turn(post, 'm', 'K', 's', [{'role': 'user', 'parts': [{'text': 'bills?'}]}],
                             [{'name': 'list_bills'}], lambda n, a: {'bills': [1, 2], 'args': a})
    assert out == 'You have 2 bills.' and called == ['list_bills']
    second = sent[1][2]['contents']
    assert second[-1]['parts'][0]['functionResponse']['response']['result']['args'] == {'limit': 2}
    assert second[-2]['role'] == 'model'


def test_tool_error_goes_to_model_not_customer():
    def boom(n, a):
        raise ValueError('secret internal detail ' + 'x' * 1000)
    post, sent = make_post(call('x', {}), text('Sorry, could not look that up.'))
    out, _ = g.run_turn(post, 'm', 'K', 's', [], [{'name': 'x'}], boom)
    assert out.startswith('Sorry')
    assert len(sent[1][2]['contents'][-1]['parts'][0]['functionResponse']['response']['result']['error']) <= 300


def test_loop_is_bounded():
    post, _ = make_post(*[call('x', {})] * 10)
    with pytest.raises(g.GeminiError, match='too many steps'):
        g.run_turn(post, 'm', 'K', 's', [], [{'name': 'x'}], lambda n, a: {})


@pytest.mark.parametrize('status,data,msg', [
    (429, {}, 'busy'), (500, {}, 'could not answer'), (400, {'error': {'message': 'API key not valid'}}, 'not set up'),
    (200, {'promptFeedback': {'blockReason': 'SAFETY'}}, 'cannot help'), (200, {'candidates': [{'content': {'parts': []}}]}, 'no answer')])
def test_errors_are_friendly(status, data, msg):
    post, _ = make_post((status, data))
    with pytest.raises(g.GeminiError, match=msg):
        g.run_turn(post, 'm', 'K', 's', [], [], lambda n, a: {})


def test_big_tool_result_is_clipped():
    assert g.clip({'a': 'x' * 20000})['truncated'] is True
    assert g.clip({'a': 1}) == {'a': 1}
