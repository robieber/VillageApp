HDR = ('BILL_KEY,CSIN,ACCOUNT_NAME,SERVICE_ADDRESS,BILL_NUMBER,BILL_MONTH,BILL_YEAR,BILL_DATE,BILLING_PERIOD_FROM,'
       'BILLING_PERIOD_TO,DUE_DATE,PRICING_PRODUCT,CONTRACTED_CAPACITY_KW,ENERGY_KWH,MEQ_KWH,CURRENT_CHARGES,VAT_AMOUNT,'
       'PREVIOUS_BALANCE,ADJUSTMENTS,TOTAL_AMOUNT_DUE,CURRENCY,PAYMENT_STATUS,PDF_FILE_NAME,IS_REVISED,'
       'SUPERSEDES_BILL_KEY,SOURCE_SYSTEM,EXTRACT_BATCH_ID,EXTRACT_TIMESTAMP')
COMP = 'BILL_KEY,COMPONENT_CODE,COMPONENT_NAME,QUANTITY,UOM,RATE,AMOUNT,SORT_ORDER'
PAY = 'BILL_KEY,PAYMENT_STATUS,AMOUNT_PAID,OUTSTANDING_BALANCE,LAST_PAYMENT_DATE,STATUS_AS_OF'
HRLY = 'CSIN,INTERVAL_START,KWH,KW_DEMAND'


def hdr_row(csin='CS-1', y=2026, m=9, num='B1', total='1120.00', current='1000.00', prev='0', adj='0', vat='120.00',
            status='UNPAID', revised='N', supersedes='', name='Acme Mill 1', pdf=None, key=None):
    key = key or f'{csin}-{y}{m:02d}-{num}'
    pdf = pdf or f'{y}{m:02d}-{csin}.pdf'
    return (f'{key},{csin},{name},Laguna,{num},{m},{y},{y}-{m:02d}-28,{y}-{m:02d}-01,{y}-{m:02d}-30,{y}-{m + 1:02d}-15,'
            f'Fixed,500,5000,4800,{current},{vat},{prev},{adj},{total},PHP,{status},{pdf},{revised},{supersedes},CMS-RES,'
            f'X1,{y}-{m:02d}-28T10:00:00+08:00')


def comp_rows(key, gen='700.00', trans='300.00'):
    return [f'{key},GEN,Generation,5000,KWH,0.14,{gen},10', f'{key},TRANS,Transmission,5000,KWH,0.06,{trans},20']


def csv(head, *rows):
    return (head + '\n' + '\n'.join(rows) + '\n').encode()
