import io
import zipfile

import ziputil as z


def make(files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as zf:
        for n, d in files.items():
            zf.writestr(n, d)
    return buf.getvalue()


def test_extracts_csv_and_pdfs_flattened():
    files, msgs = z.extract_batch(make({'b/MPWR_BILL_HDR_1.csv': 'x', 'b/pdfs/a.pdf': b'%PDF-', 'readme.txt': 'hi'}))
    assert set(files) == {'MPWR_BILL_HDR_1.csv', 'a.pdf'}
    assert any('readme.txt' in m for m in msgs)


def test_traversal_names_are_flattened():
    files, _ = z.extract_batch(make({'a.csv': 'x', '../../evil.pdf': b'%PDF-'}))
    assert set(files) == {'a.csv', 'evil.pdf'}


def test_needs_a_csv_and_a_real_zip():
    files, msgs = z.extract_batch(make({'a.pdf': b'%PDF-'}))
    assert files is None and 'no CSV' in msgs[-1]
    assert z.extract_batch(b'not a zip')[0] is None
