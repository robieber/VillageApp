from datetime import date
from decimal import Decimal

import pytest
import payment_rules as p

TODAY = date(2026, 10, 22)
PNG = b'\x89PNG\r\n\x1a\n' + b'0' * 20


def test_money():
    assert p.money('1,250.50') == Decimal('1250.50')
    assert p.money(100) == Decimal('100')
    for bad in ('abc', '1.234', 'NaN', 'Infinity', True, None, ''):
        with pytest.raises(ValueError):
            p.money(bad)


def test_file_checks_use_content_not_name():
    assert p.check_file('my receipt.PNG', PNG) == ('my_receipt.png', 'image/png')
    assert p.check_file('x.jpg', b'\xff\xd8\xff\xe0abc')[1] == 'image/jpeg'
    assert p.check_file('../../etc/passwd.pdf', b'%PDF-1.7 x') == ('passwd.pdf', 'application/pdf')
    with pytest.raises(ValueError):
        p.check_file('evil.png', b'<html><script>alert(1)</script>')
    with pytest.raises(ValueError):
        p.check_file('big.png', PNG + b'0' * p.MAX_PROOF_BYTES)
    with pytest.raises(ValueError):
        p.check_file('empty.png', b'')


def test_header():
    ok = p.check_header(date(2026, 10, 20), ' BDO ', 'bank_transfer', '1000.00', TODAY)
    assert ok == (date(2026, 10, 20), 'BDO', 'bank_transfer', Decimal('1000.00'))
    for args in [(date(2026, 10, 23), 'BDO', 'check', 5), (date(2024, 1, 1), 'BDO', 'check', 5), (None, 'BDO', 'check', 5),
                 (TODAY, '', 'check', 5), (TODAY, 'BDO', 'cash', 5), (TODAY, 'BDO', 'check', 0), (TODAY, 'BDO', 'check', 'x')]:
        with pytest.raises(ValueError):
            p.check_header(*args, TODAY)


def test_allocations():
    lines = [{'account_id': 1, 'bill_id': 10, 'amount': '600'}, {'account_id': 2, 'bill_id': None, 'amount': 400}]
    out = p.check_allocations(lines, Decimal('1000'), {1, 2}, {10: 1})
    assert [x['amount'] for x in out] == [Decimal('600'), Decimal('400')]
    with pytest.raises(ValueError, match='add up to PHP 1,000.00'):
        p.check_allocations(lines, Decimal('999'), {1, 2}, {10: 1})
    with pytest.raises(ValueError, match='one of your accounts'):
        p.check_allocations(lines, Decimal('1000'), {1}, {10: 1})
    with pytest.raises(ValueError, match='does not belong'):
        p.check_allocations(lines, Decimal('1000'), {1, 2}, {10: 2})
    with pytest.raises(ValueError, match='twice'):
        p.check_allocations([lines[0], dict(lines[0])], Decimal('1200'), {1}, {10: 1})
    with pytest.raises(ValueError):
        p.check_allocations([], Decimal('1'), {1}, {})
    with pytest.raises(ValueError, match='more than zero'):
        p.check_allocations([{'account_id': 1, 'amount': '-5'}, {'account_id': 2, 'amount': '5'}], Decimal('0'), {1, 2}, {})
