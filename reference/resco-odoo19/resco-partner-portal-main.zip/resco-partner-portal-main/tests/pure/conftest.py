import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'odoo', 'addons', 'resco_portal', 'lib'))
