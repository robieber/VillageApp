import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

// APP_BASE=/resco_portal/static/app/ when the build is bundled into the Odoo module
// (Odoo serves index.html at /app and the assets from the module's static folder).
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
    },
  },
  root: path.resolve(import.meta.dirname, "client"),
  base: process.env.APP_BASE || "./",
  build: {
    outDir: path.resolve(import.meta.dirname, process.env.OUT_DIR || "dist/public"),
    emptyOutDir: true,
  },
  server: {
    port: 3000,
    host: "0.0.0.0",
    proxy: { "/api": "http://localhost:8069", "/get-in-touch": "http://localhost:8069", "/web": "http://localhost:8069" },
  },
});
