# MyMSpectrum Residential Solar & EMS UI Evolution

An architectural and UI enhancement plan to transform the MyMSpectrum application into a consumer-first, household-centric Solar and Energy Management System (EMS) mobile experience based on the residential PRD and mockup designs, while maintaining the approved color scheme, 6-tab navigation, and live Odoo backend integration.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed based on your requirements and interactive clarification:
> - **Primary Navigation**: Preserved the 6-tab layout (`Home`, `Energy`, `Health`, `Bills`, `Support`, `Account`) so customer support remains instantly accessible on mobile while renaming the "Quality" tab to **"Health"** (Power Quality & Appliance Protection).
> - **Visual Density & Health Tab**: Combined the PRD's **Hero Protection Status & Appliance Safety FAQ** with the comprehensive voltage/frequency engineering charts so homeowners get immediate reassurance without losing deep technical telemetry.
> - **Dynamic Calculations**: Client-side computation of household peso savings, energy autonomy index, and battery backup runtime from live inverter and circuit telemetry, with graceful fallbacks.
> - **Scope Discipline**: UI/UX modernization is maximized first; backend-dependent workflows (e.g. native referral code tracking server endpoints) are wired with intuitive front-end modals and direct sharing affordances without creating mock servers or breaking CI constraints.

---

## 1. Overview & Core Concept

- **Product Name**: MyMSpectrum Residential Solar & EMS
- **Core Value Proposition**: Translate complex industrial inverter data (string voltages, phase frequency, cumulative raw kWh) into everyday household metrics: **real-time peso savings**, **energy autonomy & self-consumption percentage**, **home appliance protection reassurance**, and **frictionless billing**.
- **Visual Posture**: Premium modern dark-slate / navy aesthetic with MSpectrum solar gold, amber, and emerald accents, honoring the established palette.

---

## 2. User Experience & Screen-by-Screen Visual Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        MyMSpectrum Mobile Shell                        │
│  [Logo / Wordmark]                           [Ask AI] [Notifications]  │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  Tab 1: Home (Value & Flow)                                            │
│  ├── Personalized Salutation ("Hello, [Family Name]!")                 │
│  ├── Hero Value Card: Est. Savings This Month (₱XX,XXX) + Backup Left  │
│  ├── Live Energy Flow Node Map (Solar ──> Home ──> Battery ──> Grid)   │
│  │   └── Self-Consumption Micro-Metric (XX%)                           │
│  └── Current Generation Arc Gauge (X.X kW now · +X.X kWh today)        │
│      └── Quick CTA: "See Daily Saving Details"                         │
│                                                                        │
│  Tab 2: Energy (Solar & Grid Energy)                                   │
│  ├── Time Range Selector (Today | 7 days | Month | Year)               │
│  ├── Summary Banner (Total kWh Produced + Est. Savings Badge)          │
│  ├── Yield Bar Chart with Interactive Day Tooltip (kWh + ₱ Saved)      │
│  └── Insight Cards Grid (Best Day kWh + Energy Autonomy % Index)       │
│                                                                        │
│  Tab 3: Health (Home Protection & Power Quality)                       │
│  ├── Time Window Filter (24 hours | 7 days | Timeline view)           │
│  ├── Hero Protection Card ("Good System Health · Stabilized Events")   │
│  ├── Reassuring Grid Tiles (Voltage 247.6V · Frequency 60.1Hz · PF)    │
│  ├── Interactive Voltage & Frequency Band Charts (Engineering Depth)   │
│  └── Educational Micro-Accordion (Appliance Protection FAQ)            │
│                                                                        │
│  Tab 4: Bills (PPA Invoices & Payment)                                 │
│  ├── Outstanding Statement Balance Card + Quick-Pay CTA                │
│  ├── Supported Payment Rails (GCash, Maya, Cards, Bank, Auto-Debit)    │
│  └── Statement History List (kWh, Period, Due Date, PDF Invoice)       │
│                                                                        │
│  Tab 5: Support (Help & Service Tickets)                               │
│  ├── Active Tickets & Direct In-App Message Threads                    │
│  └── "New Request" Flow (Billing, Maintenance, System Outage)          │
│                                                                        │
│  Tab 6: Account (Referrals, Upgrades & Preferences)                    │
│  ├── Household Profile Header (Account No., Energization Date)         │
│  ├── Advocacy Hero: "Share the Sun!" Referral Program (₱2,500 benefit) │
│  ├── Modular Solar Upgrades (Add BESS, EV Charger, Cleaning/PM)        │
│  └── Account & System Preferences (Agreements, Inverter S/N Details)   │
│                                                                        │
├────────────────────────────────────────────────────────────────────────┤
│  Bottom Nav: [Home] [Energy] [Health] [Bills] [Support] [Account]      │
└────────────────────────────────────────────────────────────────────────┘
```

### Detailed Screen Enhancements

1. **Screen 1: Home Tab (Value-First Dashboard)**
   - **Hero Value Card**: Prominently highlights **Estimated Peso Savings This Month** (`₱3,540`) calculated from solar production multiplied by the retail tariff rate, highlighting the PPA rate advantage.
   - **Battery & Autonomy Indicator**: Displays estimated backup hours remaining based on current battery state of charge (SoC) and active home load.
   - **Dynamic Energy Flow Map**: Streamlines the 4-node flow (Solar, Home, Battery, Grid) with a centered self-consumption indicator (`Self-consumption is at 82%`).
   - **Current Generation Arc**: High-visibility radial arc gauge showing real-time kW output and cumulative day energy with direct CTA button `"See Daily Saving Details"`.

2. **Screen 2: Energy Tab (Insightful Flow & Autonomy)**
   - **Summary Strip**: Displays total solar produced in the selected range alongside an **Estimated Total Savings** badge in Philippine Peso (`Saved: ₱789`).
   - **Interactive Bar Tooltips**: Hover and tap interactions display both kilowatt-hours generated and the corresponding peso savings for that specific interval.
   - **Energy Autonomy Index**: Replaces technical jargon with household autonomy percentage (`82% Self-Reliant`), paired with the best production day record.

3. **Screen 3: Health Tab (Home Protection & Power Quality)**
   - **Reassurance Hero**: Highlights the inverter's function as an active surge and grid stabilization shield (`"Your MSpectrum inverter successfully stabilized 2 grid fluctuations in the last 24 hours, keeping your household appliances safe and protected"`).
   - **Protection Status Badges**: Clean status indicators (`Normal`, `Protected`) alongside line voltage, frequency, and power factor.
   - **Appliance Protection FAQ**: Integrated accordion explaining grid voltage risks, brownout protection, and inverter regulation.
   - **Preserved Engineering Depth**: Maintains detailed 24-hour and 7-day voltage/frequency charts below the hero for users who want to review exact grid curves.

4. **Screen 4: Bills Tab (PPA & Payment)**
   - **Value-Focused Statements**: Prominent balance display, clear PPA rate breakdown, one-tap payment dialog supporting local payment methods (GCash, Maya, Card, Bank), and PDF download link.

5. **Screen 5: Support Tab**
   - Retained as a dedicated tab per user preference, maintaining seamless ticketing, status tracking, and conversational message thread history.

6. **Screen 6: Account Tab (Referral & Modular Upgrades)**
   - **Advocacy Hero ("Share the Sun! Refer a Neighbor")**: Dedicated referral card offering bill credits (`Get ₱2,500 off your next bill, they get ₱5,000 off installation`) with an interactive Share Link action (native Web Share API / clipboard copy).
   - **Modular Solar Upgrades Section**: Interactive cards to explore battery expansion, smart EV charger installation, or scheduled preventive maintenance (panel cleaning and inspection).
   - **Clean Technical Disclosure**: Technical serial numbers and inverter specifications organized in collapsible sections to prevent visual clutter.

---

## 3. Key Product Decisions & Trade-Offs

- **Dynamic Household Metrics**:
  - *Decision*: Compute estimated peso savings and autonomy index on the client side using live dashboard metrics (`today_kwh`, `month_kwh`, `grid_rate`, `rate`, and site capacity) rather than waiting for backend schema updates.
  - *Why*: Delivers an immediate, impactful consumer experience aligned with the PRD without modifying backend APIs or breaking existing Odoo contract models.
- **Appliance Protection Framing for Grid Quality**:
  - *Decision*: Re-label and re-frame the Quality tab as **"Health"** with appliance safety narratives, while retaining the underlying charts.
  - *Why*: Resolves customer anxiety around grid instability and highlights the protective value of MSpectrum hardware.
- **Advocacy & Upgrade Actions**:
  - *Decision*: Wire "Share Link" to the native browser share sheet / clipboard, and wire "Request Upgrade" directly to the support ticket generator with pre-filled category and subject.
  - *Why*: Every button and action is completely functional and actionable without requiring new backend endpoints.

---

## 4. Technical Architecture & Component Mapping

```
┌────────────────────────────────────────────────────────┐
│                   client/src/App.tsx                   │
│          Routes: /, /energy, /quality (/health),       │
│                  /bills, /support, /account            │
└──────────────────────────┬─────────────────────────────┘
                           │
         ┌─────────────────┴─────────────────┐
         ▼                                   ▼
┌──────────────────┐               ┌──────────────────┐
│  shell.tsx       │               │  format.ts       │
│  - 6-tab nav     │               │  - peso()        │
│  - Health icon   │               │  - autonomyPct() │
│  - Wordmark      │               │  - savingsCalc() │
└────────┬─────────┘               └──────────────────┘
         │
         ├──> /pages/home.tsx      (Hero Value, Est. Savings, Flow Triangle, Arc Gauge)
         ├──> /pages/energy.tsx    (Solar & Grid Energy, Savings Tooltip, Autonomy Index)
         ├──> /pages/quality.tsx   (Home Protection & Health, Appliance Shield FAQ, Charts)
         ├──> /pages/bills.tsx     (PPA Bills, Payment Rails, Breakdown)
         ├──> /pages/support.tsx   (Tickets, Inquiries, Maintenance Requests)
         └──> /pages/account.tsx   (Profile, "Share the Sun" Referral, Solar Upgrades)
```

- **Protected API Integrity**: `client/src/lib/api.ts` remains strictly unmodified per system rules and CI assertions (`ODOO_ORIGIN` intact, no server added).
- **Test ID Stability**: All existing test IDs (`data-testid`) are preserved throughout components to prevent regression.

---

## 5. Verification & Quality Gates

1. **Type-Check & Compilation**: Execute `npm run check` (`tsc --noEmit`) and verify clean compilation via `compile_applet`.
2. **Design Integrity Verification**:
   - Zero pill badge sandwiches on cards; clean unboxed metadata with subtle typographic separators.
   - Single-line navigation labels and touch targets $\ge 44\text{px}$ on mobile.
   - All interactive controls (tabs, filter toggles, accordions, referral sharing, payment modal) have working handlers with no dead clicks.
   - Tabular figures (`font-mono tabular-nums`) applied to all numerical, financial, and electrical readouts.
