import { QueryClient } from "@tanstack/react-query";

// Same origin when Odoo serves the app. VITE_API_ORIGIN is only for a separately hosted front end.
export const API_ORIGIN: string = (import.meta.env.VITE_API_ORIGIN as string) || "";
const API = `${API_ORIGIN}/api/resco/v1`;
const KEY = "resco.token";

let token: string | null = null;
try { token = window.localStorage.getItem(KEY); } catch { token = null; }
export function setToken(t: string | null) {
  token = t;
  try { t ? window.localStorage.setItem(KEY, t) : window.localStorage.removeItem(KEY); } catch { /* storage blocked */ }
}

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}
let onUnauthenticated: (() => void) | null = null;
export const setUnauthenticatedHandler = (fn: () => void) => { onUnauthenticated = fn; };

function headers(json: boolean): Record<string, string> {
  const h: Record<string, string> = { Accept: "application/json", "X-Requested-With": "RescoPortal" };
  if (json) h["Content-Type"] = "application/json";
  if (token) { if (API_ORIGIN) h.Authorization = `Bearer ${token}`; else h["X-Resco-Token"] = token; }
  return h;
}

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API}${path}`, {
      method: opts.method || "GET", headers: headers(opts.body !== undefined),
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      credentials: API_ORIGIN ? "omit" : "same-origin",
    });
  } catch {
    throw new ApiError(0, "network", "Can't reach the server. Check your connection and try again.");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = data?.error || {};
    if (res.status === 401 && err.code === "unauthenticated") onUnauthenticated?.();
    throw new ApiError(res.status, err.code || "error", err.message || res.statusText || "Something went wrong");
  }
  return data as T;
}

/** Download a file that needs the login (bill PDF, company logo): fetch with the token, then save from memory. */
export async function download(path: string, filename: string) {
  const res = await fetch(`${API}${path}`, { headers: headers(false), credentials: API_ORIGIN ? "omit" : "same-origin" });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new ApiError(res.status, data?.error?.code || "error", data?.error?.message || "The file could not be downloaded.");
  }
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement("a"), { href: url, download: filename });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: ({ queryKey }) => api(queryKey.join("") as string),
      staleTime: 30_000, refetchOnWindowFocus: true,
      retry: (count, err: any) => !(err instanceof ApiError && err.status < 500) && count < 2,
    },
  },
});

// ---- Types (mirror the JSON API) -----------------------------------------------
export type Role = "admin" | "billing" | "viewer";
export interface Me {
  id: number; name: string; email: string; designation: string; mobile: string; landline: string; gender: string;
  birthday: string | null; role: Role; account_count: number;
  company: { name: string; website: string; has_logo: boolean; address: string };
  preferences: { email_optout: boolean; email_optout_reason: string };
}
export interface Sam { name: string; email: string; phone: string; designation: string }
export interface Account {
  id: number; name: string; csin: string; company: string; service_address: string; pricing_product: string;
  contracted_capacity_kw: number; sam: Sam | null;
}
export type PayStatus = "unpaid" | "partial" | "paid" | "overdue";
export interface Bill {
  id: number; account_id: number; csin: string; account_name: string; year: number; month: number; period: string;
  bill_number: string; due_date: string; total_amount: number; payment_status: PayStatus; overdue: boolean; has_pdf: boolean;
  version: number; payment_pending?: boolean; submissions?: Submission[]; amount_paid: number; outstanding_balance: number; last_payment_date: string | null;
  period_from: string | null; period_to: string | null;
  // detail only
  pricing_product?: string; energy_kwh?: number; meq_kwh?: number; peak_demand_kw?: number; current_charges?: number;
  vat_amount?: number; previous_balance?: number; adjustments?: number;
  components?: { code: string; name: string; quantity: number; uom: string; rate: number; amount: number }[];
}
export interface History { components: string[]; periods: { period: string; total: number; values: Record<string, number> }[] }
export interface Yearly { year: number; months: { month: number; energy_kwh: number; meq_kwh: number | null }[] }
export interface Daily { year: number; month: number; days: { day: number; kwh: number; peak_kw: number | null }[] }
export interface Hourly { date: string; hours: { hour: number; kwh: number; kw: number | null }[] }
export interface CompanyUser { id: number; name: string; email: string; role: Role; designation: string; accounts: { id: number; name: string; csin: string }[] }

export type SubmissionStatus = "for_validation" | "confirmed" | "rejected";
export interface PaymentLine { account_id: number; csin: string; account_name: string; bill_id: number | null; bill_number: string; period: string; amount: number }
export interface Submission {
  id: number; reference: string; submitted_on: string; submitted_by: string; payment_date: string; bank_name: string; payment_mode: string;
  amount_paid: number; status: SubmissionStatus; remarks: string; validated_on: string | null; partial_view: boolean;
  lines: PaymentLine[]; files: { id: number; name: string; mimetype: string }[];
}
export interface PaymentOptions {
  can_submit: boolean; max_files: number; max_file_mb: number; modes: { key: string; label: string }[];
  open_bills: { id: number; account_id: number; bill_number: string; period: string; total_amount: number; outstanding: number }[];
}

export type TicketStatus = "new" | "in_progress" | "waiting_customer" | "resolved" | "closed";
export interface TicketMessage { id: number; from: string; staff: boolean; at: string; text: string; files: { id: number; name: string }[] }
export interface Ticket {
  id: number; reference: string; subject: string; status: TicketStatus; status_label: string; category: string; account_id: number; csin: string;
  account_name: string; created_on: string; last_activity: string; assigned_to: string; raised_by: string; source: string; messages?: TicketMessage[];
}
export interface TicketOptions { categories: { id: number; name: string; to_account_manager: boolean }[]; max_files: number; max_file_mb: number }
export interface ChatMessage { role: "user" | "model"; text: string }
export interface ChatReply { session_id: number; reply: string; tickets: { id: number; reference: string }[] }

export interface Updates {
  posts: { id: number; title: string; subtitle: string; blog: string; blog_id: number; published: string; url: string }[];
  events: { id: number; title: string; start: string; end: string; location: string; url: string }[];
  pages: { title: string; url: string }[];
}
