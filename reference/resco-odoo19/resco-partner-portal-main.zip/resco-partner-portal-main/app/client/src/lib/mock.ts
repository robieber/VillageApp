// Made-up data for design review (`npm run dev:mock`). Never included in the production build.
const ACC = [
  { id: 1, name: "Northgate Foods Inc. - Plant 1", csin: "CS-100234", company: "Northgate Foods Inc.", service_address: "Km 18 East Service Rd, Taguig City", pricing_product: "Fixed Rate 24M", contracted_capacity_kw: 1500, sam: { name: "Maria Santos", email: "maria.santos@mpower.example", phone: "+63 917 555 0142", designation: "Senior Account Manager" } },
  { id: 2, name: "Northgate Foods Inc. - Warehouse", csin: "CS-100235", company: "Northgate Foods Inc.", service_address: "Lot 4 Logistics Park, Calamba, Laguna", pricing_product: "Indexed Rate", contracted_capacity_kw: 600, sam: { name: "Maria Santos", email: "maria.santos@mpower.example", phone: "+63 917 555 0142", designation: "Senior Account Manager" } },
  { id: 3, name: "Northgate Foods Inc. - HQ Tower", csin: "CS-100301", company: "Northgate Foods Inc.", service_address: "Ayala Ave, Makati City", pricing_product: "Fixed Rate 12M", contracted_capacity_kw: 900, sam: null },
];
const ME = { id: 7, name: "Jose Dela Cruz", email: "jose@northgate.example", designation: "Facilities Manager", mobile: "0917 555 0100", landline: "", gender: "", birthday: null, role: "admin", account_count: 3,
  company: { name: "Northgate Foods Inc.", website: "", has_logo: false, address: "" }, preferences: { email_optout: false, email_optout_reason: "" } };
const COMP: [string, string, number][] = [["GEN", "Generation", .46], ["TRANS", "Transmission", .13], ["DIST", "Distribution", .16], ["SYSLOSS", "System loss", .05], ["UC", "Universal charges", .07], ["GOVTAX", "Gov't taxes", .13]];
const now = new Date(2026, 9, 22);
const seed = (n: number) => { const x = Math.sin(n * 9301 + 49297) * 233280; return x - Math.floor(x); };

const bills = ACC.flatMap((a) => Array.from({ length: 12 }, (_, i) => {
  const d = new Date(now.getFullYear(), now.getMonth() - 1 - i, 1);
  const kwh = Math.round((a.contracted_capacity_kw * 380) * (0.75 + seed(a.id * 50 + i) * 0.5));
  const total = Math.round(kwh * (9.4 + seed(i + a.id) * 1.3) * 100) / 100;
  const due = new Date(d.getFullYear(), d.getMonth() + 1, 15);
  const status = i === 0 ? "unpaid" : i === 1 && a.id === 1 ? "partial" : i === 1 && a.id === 2 ? "overdue" : "paid";
  return { id: a.id * 100 + i, account_id: a.id, csin: a.csin, account_name: a.name, year: d.getFullYear(), month: d.getMonth() + 1,
    period: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`, bill_number: `B-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}-${a.id}0${i}`,
    due_date: due.toISOString().slice(0, 10), total_amount: total, payment_status: status, overdue: status === "overdue", has_pdf: true, version: 1,
    amount_paid: status === "paid" ? total : status === "partial" ? total / 2 : 0, outstanding_balance: status === "paid" ? 0 : status === "partial" ? total / 2 : total,
    last_payment_date: status === "paid" ? due.toISOString().slice(0, 10) : null, period_from: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`,
    period_to: new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().slice(0, 10), energy_kwh: kwh, meq_kwh: Math.round(kwh * 0.98) };
})).sort((x, y) => (y.year * 12 + y.month) - (x.year * 12 + x.month) || x.account_id - y.account_id);

const SUBS = [
  { id: 1, reference: "PAY/2026/00001", submitted_on: "2026-10-05 02:10:00", submitted_by: "Jose Dela Cruz", payment_date: "2026-10-04", bank_name: "BDO", payment_mode: "bank_transfer", amount_paid: 250000, status: "confirmed", remarks: "", validated_on: "2026-10-06 03:00:00", partial_view: false,
    lines: [{ account_id: 1, csin: "CS-100234", account_name: ACC[0].name, bill_id: 101, bill_number: "B-202609-101", period: "2026-09", amount: 150000 }, { account_id: 2, csin: "CS-100235", account_name: ACC[1].name, bill_id: null, bill_number: "", period: "", amount: 100000 }], files: [{ id: 1, name: "receipt.png", mimetype: "image/png" }] },
  { id: 2, reference: "PAY/2026/00002", submitted_on: "2026-10-20 05:00:00", submitted_by: "Ana Reyes", payment_date: "2026-10-19", bank_name: "BPI", payment_mode: "check", amount_paid: 80000, status: "rejected", remarks: "The check number is not readable. Please upload a clearer photo.", validated_on: "2026-10-21 01:00:00", partial_view: false,
    lines: [{ account_id: 3, csin: "CS-100301", account_name: ACC[2].name, bill_id: null, bill_number: "", period: "", amount: 80000 }], files: [{ id: 2, name: "check.pdf", mimetype: "application/pdf" }] },
  { id: 3, reference: "PAY/2026/00003", submitted_on: "2026-10-22 01:00:00", submitted_by: "Jose Dela Cruz", payment_date: "2026-10-22", bank_name: "Metrobank", payment_mode: "bank_deposit", amount_paid: 120000, status: "for_validation", remarks: "", validated_on: null, partial_view: false,
    lines: [{ account_id: 2, csin: "CS-100235", account_name: ACC[1].name, bill_id: 200, bill_number: "B-202609-200", period: "2026-09", amount: 120000 }], files: [{ id: 3, name: "deposit.jpg", mimetype: "image/jpeg" }] },
];
const TICKETS = [
  { id: 1, reference: "HLP/2026/00001", subject: "Rate on September bill", status: "waiting_customer", status_label: "Waiting for Customer", category: "Billing and payments", account_id: 1, csin: "CS-100234", account_name: "Northgate Foods Inc.", created_on: "2026-10-10 02:00:00", last_activity: "2026-10-12 06:00:00", assigned_to: "Maria Santos", raised_by: "Jose Dela Cruz", source: "portal",
    messages: [{ id: 1, from: "Jose Dela Cruz", staff: false, at: "2026-10-10 02:00:00", text: "The generation rate looks higher than in August.", files: [] }, { id: 2, from: "Maria Santos", staff: true, at: "2026-10-12 06:00:00", text: "Thanks. Could you send the August bill so we can compare?", files: [] }] },
];
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json" } });

function route(path: string, q: URLSearchParams) {
  const ids = (q.get("account_id") || "").split(",").filter(Boolean).map(Number);
  const pick = <T extends { account_id: number }>(l: T[]) => (ids.length ? l.filter((x) => ids.includes(x.account_id)) : l);
  if (path === "/me") return ME;
  if (path === "/accounts") return ACC;
  if (path === "/company/users") return [{ id: 7, name: ME.name, email: ME.email, role: "admin", designation: ME.designation, accounts: ACC }, { id: 8, name: "Ana Reyes", email: "ana@northgate.example", role: "billing", designation: "Accounting", accounts: ACC.slice(0, 2) }, { id: 9, name: "Paolo Lim", email: "paolo@northgate.example", role: "viewer", designation: "Engineer", accounts: ACC.slice(0, 1) }];
  if (path === "/bills") return pick(bills).filter((b) => (!q.get("year") || b.year === +q.get("year")!) && (!q.get("month") || b.month === +q.get("month")!));
  const pm = path.match(/^\/payments\/(\d+)$/);
  if (pm) return SUBS.find((x) => x.id === +pm[1]) ?? null;
  const m = path.match(/^\/bills\/(\d+)$/);
  if (m) {
    const b = bills.find((x) => x.id === +m[1])!; const net = b.total_amount / 1.12;
    return { ...b, vat_amount: Math.round((b.total_amount - net) * 100) / 100, previous_balance: 0, adjustments: 0,
      components: COMP.slice(0, 5).map(([code, name, w]) => ({ code, name, quantity: code === "GEN" ? b.energy_kwh : 0, uom: "KWH", rate: 0, amount: Math.round(net * w / 0.87 * 100) / 100 })) };
  }
  if (path === "/updates") return { posts: [
      { id: 1, title: "WESM prices ease in September", subtitle: "Average spot price down 8% month on month.", blog: "Energy Bulletin", blog_id: 1, published: "2026-10-15 01:00:00", url: "/blog/energy-bulletin-1/wesm-1" },
      { id: 2, title: "ERC Resolution on retail supply contracts", subtitle: "New disclosure rules take effect in January.", blog: "Regulatory Updates", blog_id: 2, published: "2026-10-08 01:00:00", url: "/blog/regulatory-updates-2/erc-2" },
      { id: 3, title: "Scheduled portal maintenance", subtitle: "Saturday 2 to 4 AM.", blog: "Advisories", blog_id: 3, published: "2026-10-20 01:00:00", url: "/blog/advisories-3/maint-3" }],
    events: [{ id: 1, title: "Contestable Customers Forum", start: "2026-11-12 01:00:00", end: "2026-11-12 08:00:00", location: "Ortigas, Pasig", url: "/event/forum-1" }],
    pages: [{ title: "Payment Guidelines", url: "/payment-guidelines" }, { title: "Energy Solutions", url: "/energy-solutions" }] };
  if (path === "/privacy") return { version: 1, title: "Privacy Notice", paragraphs: ["Sample privacy notice."], accepted: true };
  if (path === "/popups") return [];
  if (path === "/chat/status") return { enabled: true };
  if (path === "/chat/sessions") return [{ id: 1, title: "Which bills are unpaid?" }];
  if (path === "/tickets/options") return { max_files: 5, max_file_mb: 5, categories: [{ id: 1, name: "Billing and payments", to_account_manager: false }, { id: 5, name: "Message to my account manager", to_account_manager: true }] };
  if (path === "/tickets") return TICKETS.map(({ messages, ...t }) => t);
  const tm = path.match(/^\/tickets\/(\d+)$/);
  if (tm) return TICKETS.find((x) => x.id === +tm[1]) ?? null;
  if (path === "/payments/options") return { can_submit: true, max_files: 5, max_file_mb: 5, modes: [{ key: "bank_transfer", label: "Bank transfer / online banking" }, { key: "bank_deposit", label: "Bank deposit" }, { key: "check", label: "Check" }],
    open_bills: bills.filter((b) => b.payment_status !== "paid").map((b) => ({ id: b.id, account_id: b.account_id, bill_number: b.bill_number, period: b.period, total_amount: b.total_amount, outstanding: b.outstanding_balance || b.total_amount })) };
  if (path === "/payments") return pick(SUBS.map((s) => ({ ...s, account_id: s.lines[0].account_id }))).map(({ account_id, ...s }) => s);
  if (path === "/billing-history") {
    const periods = [...new Set(pick(bills).map((b) => b.period))].sort().slice(-12);
    return { components: COMP.map((c) => c[1]), periods: periods.map((p) => {
      const rows = pick(bills).filter((b) => b.period === p); const values: Record<string, number> = {}; let total = 0;
      COMP.forEach(([, n, w]) => { values[n] = Math.round(rows.reduce((s, b) => s + b.total_amount * w, 0)); total += values[n]; });
      return { period: p, total, values }; }) };
  }
  if (path === "/energy/yearly") {
    const y = +(q.get("year") || now.getFullYear());
    return { year: y, months: Array.from({ length: 12 }, (_, i) => { const kwh = pick(bills).filter((b) => b.year === y && b.month === i + 1).reduce((s, b) => s + b.energy_kwh, 0) || (y < now.getFullYear() ? Math.round(900000 * (0.8 + seed(i + y) * 0.4)) : 0); return { month: i + 1, energy_kwh: kwh, meq_kwh: kwh ? Math.round(kwh * 0.97) : null }; }) };
  }
  if (path === "/energy/daily") {
    const y = +q.get("year")!, mo = +q.get("month")!; const n = new Date(y, mo, 0).getDate();
    return { year: y, month: mo, days: Array.from({ length: n }, (_, i) => { const wk = [0, 6].includes(new Date(y, mo - 1, i + 1).getDay()); const kwh = Math.round((wk ? 21000 : 30000) * (0.85 + seed(i + mo) * 0.3)); return { day: i + 1, kwh, peak_kw: Math.round(kwh / 24 * (1.5 + seed(i) * 0.4)) }; }) };
  }
  if (path === "/energy/hourly") {
    return { date: q.get("date"), hours: Array.from({ length: 24 }, (_, h) => { const f = 0.55 + 0.45 * Math.sin(((h - 6) / 24) * Math.PI * 2 * 0.9) ** 2 + seed(h) * 0.1; const kwh = Math.round(1700 * f); return { hour: h, kwh, kw: Math.round(kwh * 1.08) }; }) };
  }
  return null;
}

export function installMock() {
  const real = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    const url = new URL(typeof input === "string" ? input : (input as Request).url, window.location.origin);
    if (!url.pathname.startsWith("/api/resco/v1")) return real(input, init);
    const path = url.pathname.replace("/api/resco/v1", "");
    await new Promise((r) => setTimeout(r, 120));
    if (path === "/auth/login") { try { window.localStorage.setItem("resco.token", "mock"); } catch { /* ignore */ } return json({ token: "mock", me: ME }); }
    if (!window.localStorage.getItem("resco.token")) return json({ error: { code: "unauthenticated", message: "Sign in" } }, 401);
    if (path === "/auth/logout" || path === "/auth/reset-password") return json({ message: "If that email is registered, a reset link is on its way." });
    if (init?.method === "POST" && path === "/payments") return json({ ...SUBS[2], id: 4, reference: "PAY/2026/00004" }, 201);
    if (init?.method === "POST" && path === "/chat") return json({ session_id: 1, reply: "Your latest bill is B-202609-101 for September: ₱150,000.00, due Oct 25. It is unpaid.", tickets: [] });
    if (init?.method && init.method !== "GET") return json(ME);
    const r = route(path, url.searchParams);
    return r ? json(r) : json({ error: { code: "not_found", message: "Not found" } }, 404);
  };
  if (!window.location.search.includes("login")) window.localStorage.setItem("resco.token", "mock");
  else window.localStorage.removeItem("resco.token");
}
