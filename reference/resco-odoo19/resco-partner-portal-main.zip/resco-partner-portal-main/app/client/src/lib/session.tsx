import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Account, api, ApiError, Me, queryClient, setToken, setUnauthenticatedHandler } from "./api";

interface SessionCtx {
  me: Me | null; loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  setMe: (m: Me | null) => void;
}
const Ctx = createContext<SessionCtx>(null as any);
export const useSession = () => useContext(Ctx);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const clear = useCallback(() => { setToken(null); setMe(null); queryClient.clear(); }, []);

  useEffect(() => {
    setUnauthenticatedHandler(clear);
    api<Me>("/me").then(setMe).catch((e) => { if (e instanceof ApiError && e.status === 401) clear(); }).finally(() => setLoading(false));
  }, [clear]);

  const login = async (email: string, password: string) => {
    const r = await api<{ token: string; me: Me }>("/auth/login", { method: "POST", body: { email, password } });
    setToken(r.token); setMe(r.me);
  };
  const logout = async () => {
    try { await api("/auth/logout", { method: "POST", body: {} }); } finally { clear(); window.location.hash = "#/"; }
  };
  return <Ctx.Provider value={{ me, loading, login, logout, setMe }}>{children}</Ctx.Provider>;
}

/** Which service accounts the user is looking at. Empty selection means all of them. */
interface ScopeCtx { accounts: Account[]; selected: number[]; ids: number[]; setSelected: (ids: number[]) => void; loading: boolean }
const Scope = createContext<ScopeCtx>(null as any);
export const useScope = () => useContext(Scope);

export function ScopeProvider({ children }: { children: ReactNode }) {
  const { data, isLoading } = useQuery<Account[]>({ queryKey: ["/accounts"] });
  const [selected, setSelectedRaw] = useState<number[]>(() => {
    try { return JSON.parse(sessionStorage.getItem("resco.scope") || "[]"); } catch { return []; }
  });
  const accounts = data || [];
  const valid = selected.filter((id) => accounts.some((a) => a.id === id));
  const setSelected = (ids: number[]) => { setSelectedRaw(ids); try { sessionStorage.setItem("resco.scope", JSON.stringify(ids)); } catch { /* ignore */ } };
  const ids = useMemo(() => (valid.length ? valid : accounts.map((a) => a.id)), [valid.join(","), accounts.length]); // eslint-disable-line
  return <Scope.Provider value={{ accounts, selected: valid, ids, setSelected, loading: isLoading }}>{children}</Scope.Provider>;
}
