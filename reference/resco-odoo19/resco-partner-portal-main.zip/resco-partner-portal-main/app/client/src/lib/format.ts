export const peso = (n: number | null | undefined, digits = 2) =>
  `₱${(n ?? 0).toLocaleString("en-PH", { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;
export const num = (n: number | null | undefined, digits = 0) =>
  (n ?? 0).toLocaleString("en-PH", { minimumFractionDigits: digits, maximumFractionDigits: digits });
export const compact = (n: number) => new Intl.NumberFormat("en-PH", { notation: "compact", maximumFractionDigits: 1 }).format(n);
export const fmtDate = (s?: string | null) =>
  s ? new Date(`${s.slice(0, 10)}T00:00:00`).toLocaleDateString("en-PH", { day: "numeric", month: "short", year: "numeric" }) : "-";
export const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
export const MONTHS_SHORT = MONTHS.map((m) => m.slice(0, 3));
export const periodLabel = (p: string) => { const [y, m] = p.split("-").map(Number); return `${MONTHS_SHORT[m - 1]} ${String(y).slice(2)}`; };
export const greeting = () => { const h = new Date().getHours(); return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening"; };
