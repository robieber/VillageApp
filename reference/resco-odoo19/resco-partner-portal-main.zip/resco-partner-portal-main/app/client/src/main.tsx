import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

if (!window.location.hash) window.location.hash = "#/";

async function start() {
  // `npm run dev:mock` serves made-up data so the screens can be reviewed without Odoo.
  if (import.meta.env.VITE_MOCK) (await import("./lib/mock")).installMock();
  createRoot(document.getElementById("root")!).render(<App />);
}
start();
