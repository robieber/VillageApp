import { Bar, BarChart, CartesianGrid, ComposedChart, Legend, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { compact, MONTHS_SHORT, num, periodLabel, peso } from "@/lib/format";
import type { Daily, History, Hourly, Yearly } from "@/lib/api";

// Blue first, orange as the contrast colour, then supporting tones.
export const SERIES = ["#1d3fbf", "#ff5016", "#18a0e0", "#f2b134", "#6a5acd", "#0b1b6b", "#9aa8d6", "#d9480f"];
const axis = { fontSize: 12, fill: "#5b6585" };
const grid = <CartesianGrid strokeDasharray="3 3" stroke="#e3e7f2" vertical={false} />;
const tip = { contentStyle: { borderRadius: 10, border: "1px solid #e3e7f2", boxShadow: "0 8px 24px -8px rgba(20,35,100,.2)", fontSize: 12 } };

export function BillingHistoryChart({ data }: { data: History }) {
  const rows = data.periods.map((p) => ({ period: periodLabel(p.period), ...p.values }));
  return (
    <ResponsiveContainer width="100%" height={340}>
      <BarChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        {grid}
        <XAxis dataKey="period" tick={axis} tickLine={false} axisLine={false} />
        <YAxis tick={axis} tickLine={false} axisLine={false} tickFormatter={(v) => `₱${compact(v)}`} width={64} />
        <Tooltip {...tip} formatter={(v: number, n) => [peso(v), n]} cursor={{ fill: "rgba(29,63,191,.06)" }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        {data.components.map((c, i) => <Bar key={c} dataKey={c} stackId="a" fill={SERIES[i % SERIES.length]} radius={i === data.components.length - 1 ? [4, 4, 0, 0] : 0} />)}
      </BarChart>
    </ResponsiveContainer>
  );
}

export function YearlyChart({ data }: { data: Yearly }) {
  const rows = data.months.map((m) => ({ month: MONTHS_SHORT[m.month - 1], "Billed energy": m.energy_kwh || null, MEQ: m.meq_kwh }));
  return (
    <ResponsiveContainer width="100%" height={340}>
      <BarChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }} barGap={2}>
        {grid}
        <XAxis dataKey="month" tick={axis} tickLine={false} axisLine={false} />
        <YAxis tick={axis} tickLine={false} axisLine={false} tickFormatter={compact} width={56} />
        <Tooltip {...tip} formatter={(v: number, n) => [`${num(v)} kWh`, n]} cursor={{ fill: "rgba(29,63,191,.06)" }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar dataKey="Billed energy" fill={SERIES[0]} radius={[4, 4, 0, 0]} />
        <Bar dataKey="MEQ" fill={SERIES[1]} radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function DailyChart({ data }: { data: Daily }) {
  const rows = data.days.map((d) => ({ day: d.day, "Energy (kWh)": d.kwh || null, "Peak demand (kW)": d.peak_kw }));
  return (
    <ResponsiveContainer width="100%" height={340}>
      <ComposedChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        {grid}
        <XAxis dataKey="day" tick={axis} tickLine={false} axisLine={false} />
        <YAxis yAxisId="l" tick={axis} tickLine={false} axisLine={false} tickFormatter={compact} width={56} />
        <YAxis yAxisId="r" orientation="right" tick={axis} tickLine={false} axisLine={false} tickFormatter={compact} width={48} />
        <Tooltip {...tip} cursor={{ fill: "rgba(29,63,191,.06)" }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar yAxisId="l" dataKey="Energy (kWh)" fill={SERIES[0]} radius={[4, 4, 0, 0]} />
        <Line yAxisId="r" type="monotone" dataKey="Peak demand (kW)" stroke={SERIES[1]} strokeWidth={2.5} dot={false} connectNulls />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

export function HourlyChart({ data }: { data: Hourly }) {
  const rows = data.hours.map((h) => ({ hour: `${String(h.hour).padStart(2, "0")}:00`, "Energy (kWh)": h.kwh || null, "Demand (kW)": h.kw }));
  return (
    <ResponsiveContainer width="100%" height={340}>
      <ComposedChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        {grid}
        <XAxis dataKey="hour" tick={axis} tickLine={false} axisLine={false} interval={2} />
        <YAxis yAxisId="l" tick={axis} tickLine={false} axisLine={false} tickFormatter={compact} width={56} />
        <YAxis yAxisId="r" orientation="right" tick={axis} tickLine={false} axisLine={false} tickFormatter={compact} width={48} />
        <Tooltip {...tip} cursor={{ fill: "rgba(29,63,191,.06)" }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar yAxisId="l" dataKey="Energy (kWh)" fill={SERIES[0]} radius={[4, 4, 0, 0]} />
        <Line yAxisId="r" type="monotone" dataKey="Demand (kW)" stroke={SERIES[1]} strokeWidth={2.5} dot={false} connectNulls />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
