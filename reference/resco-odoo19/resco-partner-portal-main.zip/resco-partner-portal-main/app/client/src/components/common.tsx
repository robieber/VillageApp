import { ReactNode } from "react";
import { AlertCircle, Inbox } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import type { PayStatus, SubmissionStatus, TicketStatus } from "@/lib/api";

const base = import.meta.env.BASE_URL;
export const Logo = ({ light, className }: { light?: boolean; className?: string }) => (
  <img src={`${base}${light ? "mpower-logo-light.png" : "mpower-logo.png"}`} alt="Meralco MPower, local retail electricity supplier" className={cn("h-9 w-auto", className)} />
);

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
        <div className="brand-bar mt-3 h-1 w-14 rounded-full" />
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

const STATUS: Record<PayStatus, { label: string; cls: string }> = {
  paid: { label: "Paid", cls: "bg-emerald-50 text-emerald-700 ring-emerald-600/20" },
  unpaid: { label: "Unpaid", cls: "bg-blue-50 text-blue-700 ring-blue-600/20" },
  partial: { label: "Partially paid", cls: "bg-amber-50 text-amber-700 ring-amber-600/25" },
  overdue: { label: "Overdue", cls: "bg-orange-50 text-orange-700 ring-orange-600/30" },
};
export const StatusBadge = ({ status, overdue }: { status: PayStatus; overdue?: boolean }) => {
  const s = STATUS[overdue && status !== "paid" ? "overdue" : status];
  return <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset", s.cls)}>{s.label}</span>;
};

export function Stat({ label, value, hint, icon, accent }: { label: string; value: ReactNode; hint?: ReactNode; icon?: ReactNode; accent?: boolean }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-card-border bg-card p-4 shadow-[var(--shadow-sm)]">
      <div className={cn("absolute inset-y-0 left-0 w-1", accent ? "bg-brand" : "bg-primary")} />
      <div className="flex items-start justify-between gap-2 pl-2">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
          <p className="tabular mt-1 truncate font-display text-2xl font-extrabold text-foreground">{value}</p>
          {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
        </div>
        {icon && <div className={cn("rounded-lg p-2", accent ? "bg-brand/10 text-brand" : "bg-primary/10 text-primary")}>{icon}</div>}
      </div>
    </div>
  );
}

export const Empty = ({ title, hint }: { title: string; hint?: string }) => (
  <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/60 px-6 py-14 text-center">
    <div className="mb-3 rounded-full bg-primary/10 p-3 text-primary"><Inbox className="h-6 w-6" /></div>
    <p className="font-semibold">{title}</p>
    {hint && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{hint}</p>}
  </div>
);

export const ErrorNote = ({ error }: { error: unknown }) => (
  <div className="flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span>{(error as Error)?.message || "Something went wrong."}</span>
  </div>
);

export const Panel = ({ title, action, children, className }: { title?: string; action?: ReactNode; children: ReactNode; className?: string }) => (
  <section className={cn("rounded-xl border border-card-border bg-card p-5 shadow-[var(--shadow-sm)]", className)}>
    {(title || action) && (
      <div className="mb-4 flex items-center justify-between gap-2">
        {title && <h2 className="font-display text-base font-bold">{title}</h2>}{action}
      </div>
    )}
    {children}
  </section>
);

export const ListSkeleton = ({ rows = 4 }: { rows?: number }) => (
  <div className="space-y-2">{Array.from({ length: rows }, (_, i) => <Skeleton key={i} className="h-14 w-full rounded-lg" />)}</div>
);

const SUB: Record<SubmissionStatus, { label: string; cls: string }> = {
  for_validation: { label: "For validation", cls: "bg-blue-50 text-blue-700 ring-blue-600/20" },
  confirmed: { label: "Confirmed", cls: "bg-emerald-50 text-emerald-700 ring-emerald-600/20" },
  rejected: { label: "Rejected", cls: "bg-red-50 text-red-700 ring-red-600/20" },
};
export const SubmissionBadge = ({ status }: { status: SubmissionStatus }) => (
  <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset", SUB[status].cls)}>{SUB[status].label}</span>
);

const TKT: Record<TicketStatus, { label: string; cls: string }> = {
  new: { label: "New", cls: "bg-blue-50 text-blue-700 ring-blue-600/20" },
  in_progress: { label: "In progress", cls: "bg-indigo-50 text-indigo-700 ring-indigo-600/20" },
  waiting_customer: { label: "Waiting for you", cls: "bg-amber-50 text-amber-800 ring-amber-600/20" },
  resolved: { label: "Resolved", cls: "bg-emerald-50 text-emerald-700 ring-emerald-600/20" },
  closed: { label: "Closed", cls: "bg-slate-100 text-slate-600 ring-slate-500/20" },
};
export const TicketBadge = ({ status }: { status: TicketStatus }) => (
  <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset", TKT[status].cls)}>{TKT[status].label}</span>
);
