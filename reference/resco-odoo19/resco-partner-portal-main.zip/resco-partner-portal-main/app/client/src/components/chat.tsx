import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bot, History, Loader2, LifeBuoy, Plus, Send, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Textarea } from "@/components/ui/textarea";
import { api, ChatMessage, ChatReply, Ticket, TicketOptions } from "@/lib/api";
import { useScope } from "@/lib/session";

const SUGGESTIONS = ["What is my latest bill and when is it due?", "Which of my bills are unpaid?", "What is the status of my last payment submission?", "Compare my last three months of charges"];

/** Floating assistant. Answers come from the customer's own data on the server; it can also open a ticket after the customer agrees. */
export function ChatWidget() {
  const { data: status } = useQuery<{ enabled: boolean }>({ queryKey: ["/chat/status"], staleTime: 5 * 60_000 });
  const [open, setOpen] = useState(false);
  if (!status?.enabled) return null;
  return (
    <>
      <button onClick={() => setOpen(true)} data-testid="open-chat" aria-label="Ask the assistant"
        className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-lg transition hover:brightness-110">
        <Sparkles className="h-4 w-4" />Ask the assistant
      </button>
      <ChatPanel open={open} onOpenChange={setOpen} />
    </>
  );
}

function ChatPanel({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const qc = useQueryClient();
  const [sid, setSid] = useState<number | null>(null);
  const [msgs, setMsgs] = useState<ChatMessage[]>([]);
  const [text, setText] = useState(""); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const [tickets, setTickets] = useState<{ id: number; reference: string }[]>([]);
  const [handOver, setHandOver] = useState(false); const [showHistory, setShowHistory] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const { data: past } = useQuery<{ id: number; title: string }[]>({ queryKey: ["/chat/sessions"], enabled: open && showHistory });

  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [msgs, busy]);

  const send = async (q?: string) => {
    const message = (q ?? text).trim();
    if (!message || busy) return;
    setText(""); setErr(""); setBusy(true); setMsgs((m) => [...m, { role: "user", text: message }]);
    try {
      const r = await api<ChatReply>("/chat", { method: "POST", body: { session_id: sid, message } });
      setSid(r.session_id); setMsgs((m) => [...m, { role: "model", text: r.reply }]);
      if (r.tickets.length) { setTickets((t) => [...t, ...r.tickets]); qc.invalidateQueries({ queryKey: ["/tickets"], exact: false }); }
    } catch (e: any) { setErr(e.message || "The assistant could not answer."); } finally { setBusy(false); }
  };
  const load = async (id: number) => {
    const s = await api<{ id: number; messages: ChatMessage[]; tickets: { id: number; reference: string }[] }>(`/chat/sessions/${id}`);
    setSid(s.id); setMsgs(s.messages); setTickets(s.tickets); setShowHistory(false);
  };
  const fresh = () => { setSid(null); setMsgs([]); setTickets([]); setErr(""); setShowHistory(false); };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex w-full flex-col gap-0 p-0 sm:max-w-md">
        <SheetHeader className="border-b border-border p-4 text-left">
          <SheetTitle className="flex items-center gap-2"><Bot className="h-5 w-5 text-primary" />Portal assistant</SheetTitle>
          <SheetDescription>Answers use your own accounts, bills, payments and requests. It can open a support request for you.</SheetDescription>
          <div className="flex gap-2 pt-1">
            <Button size="sm" variant="outline" onClick={fresh}><Plus className="mr-1 h-3.5 w-3.5" />New chat</Button>
            <Button size="sm" variant="outline" onClick={() => setShowHistory((v) => !v)}><History className="mr-1 h-3.5 w-3.5" />Earlier chats</Button>
            {sid && <Button size="sm" variant="outline" onClick={() => setHandOver(true)}><LifeBuoy className="mr-1 h-3.5 w-3.5" />Talk to a person</Button>}
          </div>
        </SheetHeader>
        <div className="flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
          {showHistory ? (
            <div className="space-y-1">{past?.length ? past.map((p) => <button key={p.id} onClick={() => load(p.id)} className="block w-full rounded-lg border border-border p-2 text-left text-sm hover:bg-muted">{p.title}</button>) : <p className="text-sm text-muted-foreground">No earlier chats.</p>}</div>
          ) : !msgs.length ? (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Try asking:</p>
              {SUGGESTIONS.map((s) => <button key={s} onClick={() => send(s)} className="block w-full rounded-lg border border-border p-2 text-left text-sm hover:bg-muted">{s}</button>)}
            </div>
          ) : msgs.map((m, i) => (
            <div key={i} className={m.role === "user" ? "ml-8 rounded-xl bg-primary px-3 py-2 text-sm text-primary-foreground" : "mr-8 rounded-xl bg-muted px-3 py-2 text-sm"}>
              <p className="whitespace-pre-wrap break-words">{m.text}</p>
            </div>
          ))}
          {busy && <div className="mr-8 flex items-center gap-2 rounded-xl bg-muted px-3 py-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />Looking that up</div>}
          {tickets.map((t) => <p key={t.id} className="rounded-lg border border-emerald-600/30 bg-emerald-50 p-2 text-sm text-emerald-800">Request {t.reference} was opened. Follow it under Support.</p>)}
          {err && <p role="alert" className="text-sm text-destructive">{err}</p>}
          <div ref={end} />
        </div>
        <form className="border-t border-border p-3" onSubmit={(e) => { e.preventDefault(); send(); }}>
          <div className="flex items-end gap-2">
            <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={2} maxLength={1500} placeholder="Ask about your bills, payments or requests"
              aria-label="Message" onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} />
            <Button type="submit" size="icon" disabled={busy || !text.trim()} aria-label="Send"><Send className="h-4 w-4" /></Button>
          </div>
          <p className="mt-2 text-[11px] text-muted-foreground">AI answers can be wrong. Check amounts on your bill. Your question and the data needed to answer it are processed by Google Gemini.</p>
        </form>
        {sid && <HandOver open={handOver} onClose={() => setHandOver(false)} sid={sid} onDone={(t) => { setHandOver(false); setTickets((x) => [...x, { id: t.id, reference: t.reference }]); qc.invalidateQueries(); }} />}
      </SheetContent>
    </Sheet>
  );
}

function HandOver({ open, onClose, sid, onDone }: { open: boolean; onClose: () => void; sid: number; onDone: (t: Ticket) => void }) {
  const { accounts } = useScope();
  const { data: opts } = useQuery<TicketOptions>({ queryKey: ["/tickets/options"] });
  const [account, setAccount] = useState(""); const [category, setCategory] = useState(""); const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const acc = account || (accounts.length === 1 ? String(accounts[0].id) : "");
  const go = async () => {
    if (!acc || !category) { setErr("Choose an account and a category."); return; }
    setBusy(true); setErr("");
    try { onDone(await api<Ticket>(`/chat/sessions/${sid}/ticket`, { method: "POST", body: { account_id: Number(acc), category_id: Number(category), note } })); }
    catch (e: any) { setErr(e.message || "The request could not be opened."); } finally { setBusy(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Talk to a person</DialogTitle><DialogDescription>We open a support request that includes this chat, so you do not have to repeat yourself.</DialogDescription></DialogHeader>
        <div className="space-y-1.5"><Label>Account</Label>
          <Select value={acc} onValueChange={setAccount}><SelectTrigger aria-label="Account"><SelectValue placeholder="Choose" /></SelectTrigger>
            <SelectContent>{accounts.map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name} ({a.csin})</SelectItem>)}</SelectContent></Select></div>
        <div className="space-y-1.5"><Label>Category</Label>
          <Select value={category} onValueChange={setCategory}><SelectTrigger aria-label="Category"><SelectValue placeholder="Choose" /></SelectTrigger>
            <SelectContent>{opts?.categories.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent></Select></div>
        <div className="space-y-1.5"><Label htmlFor="hn">Anything to add (optional)</Label><Textarea id="hn" rows={3} maxLength={1000} value={note} onChange={(e) => setNote(e.target.value)} /></div>
        {err && <p role="alert" className="text-sm text-destructive">{err}</p>}
        <div className="flex justify-end gap-2"><Button variant="ghost" onClick={onClose} disabled={busy}>Cancel</Button><Button onClick={go} disabled={busy}>{busy && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />}Open request</Button></div>
      </DialogContent>
    </Dialog>
  );
}
