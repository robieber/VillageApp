import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { api } from "@/lib/api";

interface Notice { version: number | null; title?: string; paragraphs?: string[]; accepted: boolean }
interface Popup { id: number; title: string; paragraphs: string[]; link_url: string; link_label: string }

/** Privacy notice that must be accepted (and is recorded) before the portal is used, then any popups RESCo has scheduled. */
export function Gates() {
  const qc = useQueryClient();
  const { data: notice } = useQuery<Notice>({ queryKey: ["/privacy"] });
  const needConsent = !!notice && notice.version != null && !notice.accepted;
  const { data: popups } = useQuery<Popup[]>({ queryKey: ["/popups"], enabled: !!notice && !needConsent });
  const [agree, setAgree] = useState(false); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const [hidden, setHidden] = useState<number[]>([]);
  const popup = popups?.find((p) => !hidden.includes(p.id));

  const accept = async () => {
    setBusy(true); setErr("");
    try { await api("/privacy/accept", { method: "POST", body: { version: notice?.version } }); await qc.invalidateQueries({ queryKey: ["/privacy"] }); await qc.invalidateQueries({ queryKey: ["/me"] }); }
    catch (e: any) { setErr(e.message || "Could not record your choice."); } finally { setBusy(false); }
  };
  const close = async (p: Popup) => { setHidden((h) => [...h, p.id]); try { await api(`/popups/${p.id}/dismiss`, { method: "POST", body: {} }); } catch { /* shown again next time */ } };

  return (
    <>
      <Dialog open={needConsent}>
        <DialogContent className="max-h-[90vh] max-w-xl overflow-y-auto" onEscapeKeyDown={(e) => e.preventDefault()} onPointerDownOutside={(e) => e.preventDefault()} onInteractOutside={(e) => e.preventDefault()}>
          <DialogHeader><DialogTitle>{notice?.title}</DialogTitle><DialogDescription>Please read and accept this notice to continue.</DialogDescription></DialogHeader>
          <div className="space-y-3 text-sm">{notice?.paragraphs?.map((p, i) => <p key={i}>{p}</p>)}</div>
          <div className="flex items-start gap-2"><Checkbox id="agree" checked={agree} onCheckedChange={(v) => setAgree(v === true)} /><Label htmlFor="agree" className="leading-snug">I have read this privacy notice and I agree.</Label></div>
          {err && <p role="alert" className="text-sm text-destructive">{err}</p>}
          <div className="flex justify-end"><Button onClick={accept} disabled={!agree || busy} data-testid="accept-privacy">{busy && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />}Accept and continue</Button></div>
        </DialogContent>
      </Dialog>
      <Dialog open={!needConsent && !!popup} onOpenChange={(o) => !o && popup && close(popup)}>
        <DialogContent className="max-w-md">
          {popup && (<>
            <DialogHeader><DialogTitle>{popup.title}</DialogTitle><DialogDescription className="sr-only">Notice from RESCo</DialogDescription></DialogHeader>
            <div className="space-y-3 text-sm">{popup.paragraphs.map((p, i) => <p key={i}>{p}</p>)}</div>
            <div className="flex justify-end gap-2">
              {popup.link_url && <Button asChild variant="outline"><a href={popup.link_url} target="_blank" rel="noopener noreferrer">{popup.link_label || "Learn more"}</a></Button>}
              <Button onClick={() => close(popup)}>Close</Button>
            </div>
          </>)}
        </DialogContent>
      </Dialog>
    </>
  );
}
