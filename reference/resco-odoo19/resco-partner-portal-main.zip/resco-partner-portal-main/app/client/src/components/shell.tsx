import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { BarChart3, FileText, LifeBuoy, Newspaper, Wallet, Home, LogOut, Menu, UserCircle, Users, Zap } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Logo } from "@/components/common";
import { ChatWidget } from "@/components/chat";
import { Gates } from "@/components/gates";
import { useSession } from "@/lib/session";
import { cn } from "@/lib/utils";

const ROLE: Record<string, string> = { admin: "Customer Administrator", billing: "Billing contact", viewer: "Viewer" };

export function Shell({ children }: { children: ReactNode }) {
  const { me, logout } = useSession();
  const [loc] = useLocation();
  const [open, setOpen] = useState(false);
  const nav = [
    { to: "/", label: "Overview", icon: Home },
    { to: "/bills", label: "Bills", icon: FileText },
    { to: "/payments", label: "Payments", icon: Wallet },
    { to: "/history", label: "Billing History", icon: BarChart3 },
    { to: "/energy", label: "Energy", icon: Zap },
    { to: "/updates", label: "Updates", icon: Newspaper },
    { to: "/support", label: "Support", icon: LifeBuoy },
    ...(me?.role === "admin" ? [{ to: "/users", label: "Company Users", icon: Users }] : []),
  ];
  const active = (to: string) => (to === "/" ? loc === "/" : loc.startsWith(to));
  const initials = (me?.name || "?").split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div className="min-h-dvh bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-card/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></Button>
          <Link href="/" className="shrink-0"><Logo /></Link>
          <nav className="hidden flex-1 items-center gap-1 md:flex" aria-label="Main">
            {nav.map((n) => (
              <Link key={n.to} href={n.to}
                className={cn("relative rounded-md px-3 py-2 text-sm font-semibold transition-colors",
                  active(n.to) ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
                {n.label}
                {active(n.to) && <span className="absolute inset-x-3 -bottom-[17px] h-[3px] rounded-full bg-brand" />}
              </Link>
            ))}
          </nav>
          <div className="ml-auto md:ml-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-full py-1 pl-1 pr-3 hover:bg-muted" data-testid="user-menu">
                  <Avatar className="h-8 w-8"><AvatarFallback className="bg-primary text-xs font-bold text-primary-foreground">{initials}</AvatarFallback></Avatar>
                  <span className="hidden text-sm font-semibold sm:block">{me?.name}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-60">
                <DropdownMenuLabel>
                  <span className="block truncate">{me?.name}</span>
                  <span className="block text-xs font-normal text-muted-foreground">{me?.company.name} · {ROLE[me?.role || "viewer"]}</span>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild><Link href="/profile"><UserCircle className="mr-2 h-4 w-4" />My profile</Link></DropdownMenuItem>
                <DropdownMenuItem onClick={() => logout()}><LogOut className="mr-2 h-4 w-4" />Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="border-b p-4"><SheetTitle><Logo /></SheetTitle></SheetHeader>
          <nav className="space-y-1 p-3">
            {nav.map((n) => (
              <Link key={n.to} href={n.to} onClick={() => setOpen(false)}
                className={cn("flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold",
                  active(n.to) ? "bg-primary/10 text-primary" : "text-foreground hover:bg-muted")}>
                <n.icon className={cn("h-4 w-4", active(n.to) && "text-brand")} />{n.label}
              </Link>
            ))}
          </nav>
        </SheetContent>
      </Sheet>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">{children}</main>
      <Gates />
      <ChatWidget />
      <footer className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        MPower Partners Portal · Local Retail Electricity Supplier
      </footer>
    </div>
  );
}
