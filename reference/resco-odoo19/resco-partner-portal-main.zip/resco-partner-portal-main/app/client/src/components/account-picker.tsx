import { useState } from "react";
import { Building2, Check, ChevronsUpDown, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useScope } from "@/lib/session";
import { cn } from "@/lib/utils";

/** Search by account name or CSIN and pick one or more accounts. Nothing picked means all accounts. */
export function AccountPicker({ single }: { single?: boolean }) {
  const { accounts, selected, setSelected } = useScope();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  if (accounts.length <= 1) return null;
  const ql = q.trim().toLowerCase();
  const list = accounts.filter((a) => !ql || a.name.toLowerCase().includes(ql) || a.csin.toLowerCase().includes(ql));
  const label = selected.length === 0 ? `All accounts (${accounts.length})`
    : selected.length === 1 ? accounts.find((a) => a.id === selected[0])?.name ?? "1 account" : `${selected.length} accounts`;
  const toggle = (id: number) => {
    if (single) { setSelected([id]); setOpen(false); return; }
    setSelected(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
  };
  return (
    <>
      <Button variant="outline" className="min-w-[13rem] justify-between bg-card" onClick={() => setOpen(true)} data-testid="account-picker">
        <span className="flex items-center gap-2 truncate"><Building2 className="h-4 w-4 text-primary" />{label}</span>
        <ChevronsUpDown className="h-4 w-4 opacity-50" />
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Choose accounts</DialogTitle>
            <DialogDescription>Search by account name or CSIN.</DialogDescription>
          </DialogHeader>
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Account name or CSIN" className="pl-9" />
          </div>
          <div className="max-h-72 space-y-1 overflow-y-auto">
            {list.map((a) => {
              const on = selected.includes(a.id);
              return (
                <button key={a.id} onClick={() => toggle(a.id)}
                  className={cn("flex w-full items-center justify-between rounded-lg border px-3 py-2 text-left text-sm transition-colors",
                    on ? "border-primary bg-primary/5" : "border-transparent hover:bg-muted")}>
                  <span><span className="block font-semibold">{a.name}</span><span className="text-xs text-muted-foreground">CSIN {a.csin}</span></span>
                  {on && <Check className="h-4 w-4 text-primary" />}
                </button>
              );
            })}
            {list.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">No account matches.</p>}
          </div>
          {!single && (
            <div className="flex justify-between pt-1">
              <Button variant="ghost" size="sm" onClick={() => setSelected([])}>Select all</Button>
              <Button size="sm" onClick={() => setOpen(false)}>Done</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
