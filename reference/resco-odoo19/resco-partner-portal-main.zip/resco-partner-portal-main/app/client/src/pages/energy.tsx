import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AccountPicker } from "@/components/account-picker";
import { DailyChart, HourlyChart, YearlyChart } from "@/components/charts";
import { Empty, ErrorNote, PageHeader, Panel } from "@/components/common";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Daily, Hourly, Yearly } from "@/lib/api";
import { MONTHS, num } from "@/lib/format";
import { useScope } from "@/lib/session";

const now = new Date();
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export default function EnergyPage() {
  const { ids } = useScope();
  const [view, setView] = useState<"yearly" | "monthly" | "hourly">("yearly");
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [day, setDay] = useState(iso(new Date(now.getFullYear(), now.getMonth(), Math.max(1, now.getDate() - 1))));
  const acc = `account_id=${ids.join(",")}`;
  const on = ids.length > 0;
  const yearly = useQuery<Yearly>({ queryKey: [`/energy/yearly?${acc}&year=${year}`], enabled: on && view === "yearly" });
  const daily = useQuery<Daily>({ queryKey: [`/energy/daily?${acc}&year=${year}&month=${month}`], enabled: on && view === "monthly" });
  const hourly = useQuery<Hourly>({ queryKey: [`/energy/hourly?${acc}&date=${day}`], enabled: on && view === "hourly" });
  const years = Array.from({ length: 5 }, (_, i) => now.getFullYear() - i);

  const q = view === "yearly" ? yearly : view === "monthly" ? daily : hourly;
  const total = view === "yearly" ? yearly.data?.months.reduce((s, m) => s + m.energy_kwh, 0)
    : view === "monthly" ? daily.data?.days.reduce((s, d) => s + d.kwh, 0) : hourly.data?.hours.reduce((s, h) => s + h.kwh, 0);
  const noData = !!total === false;

  return (
    <div>
      <PageHeader title="Energy Dashboard" subtitle="How much energy your facilities used." actions={<AccountPicker />} />
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Tabs value={view} onValueChange={(v) => setView(v as typeof view)}>
          <TabsList>
            <TabsTrigger value="yearly">Yearly</TabsTrigger><TabsTrigger value="monthly">Monthly (by day)</TabsTrigger><TabsTrigger value="hourly">Daily (by hour)</TabsTrigger>
          </TabsList>
        </Tabs>
        {view !== "hourly" && (
          <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
            <SelectTrigger className="w-28 bg-card"><SelectValue /></SelectTrigger>
            <SelectContent>{years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
          </Select>
        )}
        {view === "monthly" && (
          <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
            <SelectTrigger className="w-40 bg-card"><SelectValue /></SelectTrigger>
            <SelectContent>{MONTHS.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
          </Select>
        )}
        {view === "hourly" && <Input type="date" value={day} max={iso(now)} onChange={(e) => e.target.value && setDay(e.target.value)} className="w-44 bg-card" />}
      </div>

      {q.error ? <ErrorNote error={q.error} /> : q.isLoading ? <Skeleton className="h-96 w-full rounded-xl" /> : (
        <Panel
          title={view === "yearly" ? `Energy by month, ${year}` : view === "monthly" ? `Daily energy, ${MONTHS[month - 1]} ${year}` : `Hourly energy, ${day}`}
          action={<span className="text-sm text-muted-foreground">Total <b className="tabular text-foreground">{num(total)} kWh</b></span>}>
          {noData ? <Empty title="No energy readings for this period" hint={view === "yearly" ? "Billed energy appears once bills are released." : "Hourly readings are loaded from the supplier's meter data file."} /> : (
            <>
              {view === "yearly" && yearly.data && <YearlyChart data={yearly.data} />}
              {view === "monthly" && daily.data && <DailyChart data={daily.data} />}
              {view === "hourly" && hourly.data && <HourlyChart data={hourly.data} />}
            </>
          )}
        </Panel>
      )}
    </div>
  );
}
