import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useSearch } from "wouter";
import { Download, Loader2, Wallet } from "lucide-react";
import { AccountPicker } from "@/components/account-picker";
import { Empty, ErrorNote, ListSkeleton, PageHeader, StatusBadge, SubmissionBadge } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Bill, download } from "@/lib/api";
import { fmtDate, MONTHS, num, peso } from "@/lib/format";
import { useScope } from "@/lib/session";

function PdfButton({ bill, variant = "outline" }: { bill: Bill; variant?: "outline" | "default" }) {
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();
  if (!bill.has_pdf) return null;
  return (
    <Button size="sm" variant={variant} disabled={busy} onClick={async (e) => {
      e.stopPropagation(); setBusy(true);
      try { await download(`/bills/${bill.id}/pdf`, `${bill.period}-${bill.csin}.pdf`); }
      catch (err: any) { toast({ title: "Download failed", description: err.message, variant: "destructive" }); }
      finally { setBusy(false); }
    }}>
      {busy ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Download className="mr-1.5 h-3.5 w-3.5" />}PDF
    </Button>
  );
}

export default function BillsPage() {
  const { ids } = useScope();
  const [year, setYear] = useState("all");
  const [month, setMonth] = useState("all");
  const preset = new URLSearchParams(useSearch()).get("open");
  const [openId, setOpenId] = useState<number | null>(preset ? Number(preset) : null);
  const qs = `/bills?account_id=${ids.join(",")}${year !== "all" ? `&year=${year}` : ""}${month !== "all" ? `&month=${month}` : ""}`;
  const { data, isLoading, error } = useQuery<Bill[]>({ queryKey: [qs], enabled: ids.length > 0 });
  const years = [...new Set((data || []).map((b) => b.year))].sort((a, b) => b - a);
  const now = new Date().getFullYear();
  const yearOptions = [...new Set([...years, now, now - 1])].sort((a, b) => b - a);

  return (
    <div>
      <PageHeader title="Bills" subtitle="Choose a month and year to find a bill, then download the PDF." actions={<AccountPicker />} />
      <div className="mb-4 flex flex-wrap gap-2">
        <Select value={year} onValueChange={setYear}>
          <SelectTrigger className="w-32 bg-card"><SelectValue placeholder="Year" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All years</SelectItem>{yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={month} onValueChange={setMonth}>
          <SelectTrigger className="w-40 bg-card"><SelectValue placeholder="Month" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All months</SelectItem>{MONTHS.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      {error ? <ErrorNote error={error} /> : isLoading ? <ListSkeleton rows={6} /> : !data?.length ? (
        <Empty title="No bills found" hint="Try another month or year, or another account. New bills appear here as soon as they are released." />
      ) : (
        <div className="overflow-hidden rounded-xl border border-card-border bg-card shadow-[var(--shadow-sm)]">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/60">
                <TableHead>Account</TableHead><TableHead>Period</TableHead><TableHead className="hidden md:table-cell">Bill no.</TableHead>
                <TableHead className="hidden sm:table-cell">Due</TableHead><TableHead className="text-right">Amount</TableHead><TableHead>Status</TableHead><TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((b) => (
                <TableRow key={b.id} className="cursor-pointer" onClick={() => setOpenId(b.id)}>
                  <TableCell><span className="block font-semibold">{b.account_name}</span><span className="text-xs text-muted-foreground">CSIN {b.csin}</span></TableCell>
                  <TableCell className="whitespace-nowrap">{MONTHS[b.month - 1].slice(0, 3)} {b.year}</TableCell>
                  <TableCell className="hidden md:table-cell">{b.bill_number}</TableCell>
                  <TableCell className="hidden whitespace-nowrap sm:table-cell">{fmtDate(b.due_date)}</TableCell>
                  <TableCell className="tabular text-right font-bold">{peso(b.total_amount)}</TableCell>
                  <TableCell><StatusBadge status={b.payment_status} overdue={b.overdue} /></TableCell>
                  <TableCell className="text-right"><PdfButton bill={b} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      <BillDialog id={openId} onClose={() => setOpenId(null)} />
    </div>
  );
}

function BillDialog({ id, onClose }: { id: number | null; onClose: () => void }) {
  const { data, isLoading } = useQuery<Bill>({ queryKey: [`/bills/${id}`], enabled: id != null });
  return (
    <Dialog open={id != null} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        {isLoading || !data ? <div className="py-10"><ListSkeleton rows={3} /></div> : (
          <>
            <DialogHeader>
              <DialogTitle>{data.account_name}</DialogTitle>
              <DialogDescription>Bill {data.bill_number} · {MONTHS[data.month - 1]} {data.year}{data.period_from && data.period_to ? ` · ${fmtDate(data.period_from)} to ${fmtDate(data.period_to)}` : ""}</DialogDescription>
            </DialogHeader>
            <div className="flex items-center justify-between rounded-xl bg-primary/5 p-4">
              <div><p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Total amount due</p>
                <p className="tabular font-display text-3xl font-extrabold text-primary">{peso(data.total_amount)}</p>
                <p className="text-xs text-muted-foreground">Due {fmtDate(data.due_date)}</p></div>
              <StatusBadge status={data.payment_status} overdue={data.overdue} />
            </div>
            <div className="max-h-64 overflow-y-auto">
              <Table>
                <TableHeader><TableRow><TableHead>Component</TableHead><TableHead className="hidden sm:table-cell text-right">Quantity</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                <TableBody>
                  {data.components?.map((c) => (
                    <TableRow key={c.code}><TableCell>{c.name}</TableCell>
                      <TableCell className="hidden text-right text-muted-foreground sm:table-cell">{c.quantity ? `${num(c.quantity)} ${c.uom === "KWH" ? "kWh" : c.uom === "KW" ? "kW" : ""}` : ""}</TableCell>
                      <TableCell className="tabular text-right">{peso(c.amount)}</TableCell></TableRow>
                  ))}
                  <TableRow><TableCell>VAT</TableCell><TableCell className="hidden sm:table-cell" /><TableCell className="tabular text-right">{peso(data.vat_amount)}</TableCell></TableRow>
                  {!!data.previous_balance && <TableRow><TableCell>Previous balance</TableCell><TableCell className="hidden sm:table-cell" /><TableCell className="tabular text-right">{peso(data.previous_balance)}</TableCell></TableRow>}
                  {!!data.adjustments && <TableRow><TableCell>Adjustments</TableCell><TableCell className="hidden sm:table-cell" /><TableCell className="tabular text-right">{peso(data.adjustments)}</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
            {data.payment_status !== "unpaid" && (
              <p className="text-xs text-muted-foreground">Paid {peso(data.amount_paid)}, outstanding {peso(data.outstanding_balance)}{data.last_payment_date ? `, last payment ${fmtDate(data.last_payment_date)}` : ""}.</p>
            )}
            {!!data.submissions?.length && (
              <div className="space-y-1.5 rounded-lg border border-border p-3 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Proof of payment submitted</p>
                {data.submissions.map((s) => (
                  <div key={s.id} className="flex items-center justify-between gap-2">
                    <span>{s.reference} · {fmtDate(s.payment_date)} · {peso(s.lines.find((l) => l.bill_id === data.id)?.amount ?? s.amount_paid)}</span>
                    <SubmissionBadge status={s.status} />
                  </div>
                ))}
              </div>
            )}
            <div className="flex flex-wrap justify-end gap-2">
              {data.payment_status !== "paid" && (
                <Button asChild variant="outline"><Link href={`/payments?bill=${data.id}`}><Wallet className="mr-1.5 h-4 w-4" />Submit proof of payment</Link></Button>
              )}
              <PdfButton bill={data} variant="default" />
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
