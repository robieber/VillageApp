import { FormEvent, useState } from "react";
import { Loader2 } from "lucide-react";
import { PageHeader, Panel } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { api, Me } from "@/lib/api";
import { useSession } from "@/lib/session";

const ROLE = { admin: "Customer Administrator", billing: "Billing contact", viewer: "Viewer" };

function Field({ id, label, children, hint }: { id: string; label: string; children: React.ReactNode; hint?: string }) {
  return <div className="space-y-1.5"><Label htmlFor={id}>{label}</Label>{children}{hint && <p className="text-xs text-muted-foreground">{hint}</p>}</div>;
}

export default function ProfilePage() {
  const { me, setMe } = useSession();
  const { toast } = useToast();
  const [f, setF] = useState({ name: me!.name, designation: me!.designation, mobile: me!.mobile, landline: me!.landline });
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const save = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { setMe(await api<Me>("/me", { method: "PATCH", body: f })); toast({ title: "Profile saved" }); }
    catch (err: any) { toast({ title: "Could not save", description: err.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  return (
    <div>
      <PageHeader title="My Profile" subtitle={`${me!.company.name} · ${ROLE[me!.role]}`} />
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Your details">
          <form onSubmit={save} className="space-y-4">
            <Field id="name" label="Full name"><Input id="name" value={f.name} onChange={set("name")} required /></Field>
            <Field id="email" label="Email" hint="Your email is your login. Ask your account manager to change it."><Input id="email" value={me!.email} disabled /></Field>
            <Field id="designation" label="Designation"><Input id="designation" value={f.designation} onChange={set("designation")} /></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="mobile" label="Mobile"><Input id="mobile" value={f.mobile} onChange={set("mobile")} inputMode="tel" /></Field>
              <Field id="landline" label="Landline"><Input id="landline" value={f.landline} onChange={set("landline")} inputMode="tel" /></Field>
            </div>
            <Button type="submit" disabled={busy}>{busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Save changes</Button>
          </form>
        </Panel>
        <div className="space-y-6">
          <PasswordPanel />
          <EmailPanel />
        </div>
      </div>
    </div>
  );
}

function PasswordPanel() {
  const { toast } = useToast();
  const [old, setOld] = useState(""); const [pw, setPw] = useState(""); const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await api("/me/password", { method: "POST", body: { old_password: old, new_password: pw } }); setOld(""); setPw(""); toast({ title: "Password changed" }); }
    catch (err: any) { toast({ title: "Could not change password", description: err.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };
  return (
    <Panel title="Password">
      <form onSubmit={submit} className="space-y-4">
        <Field id="old" label="Current password"><Input id="old" type="password" autoComplete="current-password" value={old} onChange={(e) => setOld(e.target.value)} required /></Field>
        <Field id="new" label="New password" hint="At least 12 characters with upper and lower case letters, a number and a symbol.">
          <Input id="new" type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} required /></Field>
        <Button type="submit" variant="outline" disabled={busy}>{busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Change password</Button>
      </form>
    </Panel>
  );
}

function EmailPanel() {
  const { me, setMe } = useSession();
  const { toast } = useToast();
  const [optout, setOptout] = useState(me!.preferences.email_optout);
  const [reason, setReason] = useState(me!.preferences.email_optout_reason);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try { setMe(await api<Me>("/me/email-preferences", { method: "PATCH", body: { email_optout: optout, reason } })); toast({ title: "Email preferences saved" }); }
    catch (err: any) { toast({ title: "Could not save", description: err.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };
  return (
    <Panel title="Email notifications">
      <div className="flex items-start justify-between gap-4">
        <div><p className="text-sm font-semibold">Bill and payment reminder emails</p><p className="text-xs text-muted-foreground">Turn off to stop receiving them. Your bills stay available here.</p></div>
        <Switch checked={!optout} onCheckedChange={(on) => setOptout(!on)} aria-label="Receive emails" />
      </div>
      {optout && <div className="mt-4"><Label htmlFor="reason">Why are you unsubscribing?</Label><Textarea id="reason" value={reason} onChange={(e) => setReason(e.target.value)} className="mt-1.5" /></div>}
      <Button className="mt-4" variant="outline" onClick={save} disabled={busy || (optout && !reason.trim())}>{busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Save preferences</Button>
    </Panel>
  );
}
