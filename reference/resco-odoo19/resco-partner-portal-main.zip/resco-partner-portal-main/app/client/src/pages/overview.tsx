import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowRight, CalendarClock, FileText, Mail, MapPin, Phone, Receipt, Wallet } from "lucide-react";
import { AccountPicker } from "@/components/account-picker";
import { ErrorNote, ListSkeleton, Panel, Stat, StatusBadge } from "@/components/common";
import { Button } from "@/components/ui/button";
import type { Bill } from "@/lib/api";
import { fmtDate, greeting, num, peso } from "@/lib/format";
import { useScope, useSession } from "@/lib/session";

export default function OverviewPage() {
  const { me } = useSession();
  const { accounts, ids } = useScope();
  const { data: bills, isLoading, error } = useQuery<Bill[]>({ queryKey: [`/bills?account_id=${ids.join(",")}`], enabled: ids.length > 0 });
  const scoped = accounts.filter((a) => ids.includes(a.id));

  // Latest bill of each selected account.
  const latest = new Map<number, Bill>();
  (bills || []).forEach((b) => { const c = latest.get(b.account_id); if (!c || b.year * 12 + b.month > c.year * 12 + c.month) latest.set(b.account_id, b); });
  const latestBills = [...latest.values()];
  const open = latestBills.filter((b) => b.payment_status !== "paid");
  const due = open.reduce((s, b) => s + (b.outstanding_balance || b.total_amount), 0);
  const nextDue = open.map((b) => b.due_date).sort()[0];
  const overdue = open.filter((b) => b.overdue).length;
  const kwh = latestBills.reduce((s, b) => s + (b.energy_kwh || 0), 0);
  const recent = (bills || []).slice(0, 6);

  return (
    <div className="space-y-8">
      <section className="hero-bg relative overflow-hidden rounded-2xl p-6 text-white shadow-[var(--shadow-lg)] sm:p-8">
        <div className="brand-bar absolute inset-x-0 top-0 h-1" />
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-white/70">{me?.company.name}</p>
            <h1 className="font-display mt-1 text-2xl font-extrabold sm:text-3xl">{greeting()}, {me?.name.split(" ")[0]}</h1>
            <p className="mt-1 text-sm text-white/75">{scoped.length} service account{scoped.length === 1 ? "" : "s"} in view</p>
          </div>
          <div className="[&_button]:border-white/30 [&_button]:bg-white/10 [&_button]:text-white [&_button]:hover:bg-white/20"><AccountPicker /></div>
        </div>
      </section>

      {error ? <ErrorNote error={error} /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Amount due" value={isLoading ? "…" : peso(due)} hint={open.length ? `${open.length} open bill${open.length === 1 ? "" : "s"}` : "Nothing outstanding"} icon={<Wallet className="h-5 w-5" />} accent />
          <Stat label="Next due date" value={nextDue ? fmtDate(nextDue) : "-"} hint={overdue ? `${overdue} overdue` : "No overdue bills"} icon={<CalendarClock className="h-5 w-5" />} />
          <Stat label="Latest bills" value={latestBills.length} hint={latestBills[0] ? `Latest period ${latestBills[0].period}` : "No bills yet"} icon={<Receipt className="h-5 w-5" />} />
          <Stat label="Energy, latest bills" value={`${num(kwh)} kWh`} hint="Billed energy" icon={<FileText className="h-5 w-5" />} />
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Panel title="Recent bills" action={<Button asChild variant="ghost" size="sm"><Link href="/bills">All bills <ArrowRight className="ml-1 h-4 w-4" /></Link></Button>}>
          {isLoading ? <ListSkeleton /> : recent.length === 0 ? <p className="py-8 text-center text-sm text-muted-foreground">No bills have been released for these accounts yet.</p> : (
            <ul className="divide-y divide-border">
              {recent.map((b) => (
                <li key={b.id}>
                  <Link href={`/bills?open=${b.id}`} className="flex items-center justify-between gap-3 py-3 hover:bg-muted/50 sm:px-2 sm:rounded-lg">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{b.account_name}</p>
                      <p className="text-xs text-muted-foreground">{b.period} · {b.bill_number} · due {fmtDate(b.due_date)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="tabular text-sm font-bold">{peso(b.total_amount)}</span>
                      <StatusBadge status={b.payment_status} overdue={b.overdue} />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <div className="space-y-4">
          <h2 className="font-display text-base font-bold">Your accounts</h2>
          {scoped.map((a) => (
            <div key={a.id} className="rounded-xl border border-card-border bg-card p-4 shadow-[var(--shadow-sm)]">
              <p className="font-semibold">{a.name}</p>
              <p className="text-xs text-muted-foreground">CSIN {a.csin}{a.pricing_product ? ` · ${a.pricing_product}` : ""}{a.contracted_capacity_kw ? ` · ${num(a.contracted_capacity_kw)} kW` : ""}</p>
              {a.service_address && <p className="mt-2 flex items-start gap-1.5 text-xs text-muted-foreground"><MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />{a.service_address}</p>}
              {a.sam && (
                <div className="mt-3 rounded-lg bg-primary/5 p-3 text-xs">
                  <p className="font-semibold text-primary">Your account manager</p>
                  <p className="mt-0.5 text-sm font-semibold text-foreground">{a.sam.name}</p>
                  <div className="mt-1 space-y-0.5 text-muted-foreground">
                    {a.sam.email && <p className="flex items-center gap-1.5"><Mail className="h-3 w-3" /><a className="hover:underline" href={`mailto:${a.sam.email}`}>{a.sam.email}</a></p>}
                    {a.sam.phone && <p className="flex items-center gap-1.5"><Phone className="h-3 w-3" />{a.sam.phone}</p>}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
