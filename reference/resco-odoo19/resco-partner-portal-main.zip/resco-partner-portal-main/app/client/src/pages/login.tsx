import { FormEvent, useState } from "react";
import { Loader2, ShieldCheck, Zap, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/common";
import { api } from "@/lib/api";
import { useSession } from "@/lib/session";

export default function LoginPage() {
  const { login } = useSession();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [forgot, setForgot] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setError("");
    try { await login(email, password); } catch (err: any) { setError(err.message); } finally { setBusy(false); }
  };

  return (
    <div className="grid min-h-dvh lg:grid-cols-[1.1fr_1fr]">
      <aside className="hero-bg relative hidden flex-col justify-between p-12 text-white lg:flex">
        <Logo light className="h-12 self-start" />
        <div className="max-w-md">
          <div className="brand-bar mb-6 h-1.5 w-16 rounded-full" />
          <h2 className="font-display text-4xl font-extrabold leading-tight">Your power account, in one place.</h2>
          <p className="mt-4 text-base text-white/80">Check your bills, follow your billing history and see how your facilities use energy.</p>
          <ul className="mt-8 space-y-4 text-sm text-white/90">
            <li className="flex items-center gap-3"><span className="rounded-lg bg-white/10 p-2"><FileText className="h-4 w-4 text-brand" /></span>Download your monthly bill as PDF</li>
            <li className="flex items-center gap-3"><span className="rounded-lg bg-white/10 p-2"><Zap className="h-4 w-4 text-brand" /></span>Track consumption by month, day and hour</li>
            <li className="flex items-center gap-3"><span className="rounded-lg bg-white/10 p-2"><ShieldCheck className="h-4 w-4 text-brand" /></span>Secure access for the people you authorise</li>
          </ul>
        </div>
        <p className="text-xs text-white/60">MPower Partners Portal · Local Retail Electricity Supplier</p>
      </aside>

      <main className="flex items-center justify-center bg-background px-6 py-12">
        <div className="w-full max-w-sm">
          <Logo className="mb-8 h-11 lg:hidden" />
          <h1 className="font-display text-3xl font-extrabold tracking-tight">Sign in</h1>
          <p className="mt-1 text-sm text-muted-foreground">Use the email address registered for your account.</p>
          <form onSubmit={submit} className="mt-8 space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <button type="button" onClick={() => setForgot(true)} className="text-xs font-semibold text-primary hover:underline">Forgot password?</button>
              </div>
              <Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} className="h-11" />
            </div>
            {error && <p role="alert" className="rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive">{error}</p>}
            <Button type="submit" disabled={busy} className="h-11 w-full bg-brand text-brand-foreground hover:bg-brand/90 border-brand">
              {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Sign in
            </Button>
          </form>
          <p className="mt-8 text-center text-xs text-muted-foreground">
            No access yet? Ask your account manager to set you up, or <a className="font-semibold text-primary hover:underline" href="/get-in-touch">tell us about your business</a>.
          </p>
        </div>
      </main>
      <ForgotDialog open={forgot} onOpenChange={setForgot} initial={email} />
    </div>
  );
}

function ForgotDialog({ open, onOpenChange, initial }: { open: boolean; onOpenChange: (o: boolean) => void; initial: string }) {
  const [email, setEmail] = useState(initial);
  const [done, setDone] = useState("");
  const [busy, setBusy] = useState(false);
  const send = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { const r = await api<{ message: string }>("/auth/reset-password", { method: "POST", body: { email } }); setDone(r.message); }
    catch (err: any) { setDone(err.message); } finally { setBusy(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(o) => { onOpenChange(o); if (!o) setDone(""); }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reset your password</DialogTitle>
          <DialogDescription>We will email a link to the address registered for your account.</DialogDescription>
        </DialogHeader>
        {done ? <p className="rounded-lg bg-primary/5 p-3 text-sm">{done}</p> : (
          <form onSubmit={send} className="space-y-4">
            <Input type="email" required placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            <DialogFooter><Button type="submit" disabled={busy}>{busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Send reset link</Button></DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
