import { useQuery } from "@tanstack/react-query";
import { AccountPicker } from "@/components/account-picker";
import { BillingHistoryChart } from "@/components/charts";
import { Empty, ErrorNote, PageHeader, Panel } from "@/components/common";
import { Skeleton } from "@/components/ui/skeleton";
import type { History } from "@/lib/api";
import { peso } from "@/lib/format";
import { useScope } from "@/lib/session";

export default function HistoryPage() {
  const { ids } = useScope();
  const { data, isLoading, error } = useQuery<History>({ queryKey: [`/billing-history?months=12&account_id=${ids.join(",")}`], enabled: ids.length > 0 });
  const total = data?.periods.reduce((s, p) => s + p.total, 0) ?? 0;
  const empty = !data || data.periods.length === 0;
  return (
    <div>
      <PageHeader title="Billing History" subtitle="The last 12 months, split by cost component. Choose several accounts to see them stacked together." actions={<AccountPicker />} />
      {error ? <ErrorNote error={error} /> : isLoading ? <Skeleton className="h-96 w-full rounded-xl" /> : empty ? (
        <Empty title="No billing history yet" hint="Charts appear once bills have been released." />
      ) : (
        <div className="space-y-6">
          <Panel title="Charges by component" action={<span className="text-sm text-muted-foreground">12-month total <b className="tabular text-foreground">{peso(total, 0)}</b></span>}>
            <BillingHistoryChart data={data!} />
          </Panel>
          <Panel title="Month by month">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="py-2 pr-4">Period</th>{data!.components.map((c) => <th key={c} className="py-2 pr-4 text-right">{c}</th>)}<th className="py-2 text-right">Total</th></tr></thead>
                <tbody>
                  {[...data!.periods].reverse().map((p) => (
                    <tr key={p.period} className="border-b last:border-0">
                      <td className="py-2 pr-4 font-semibold">{p.period}</td>
                      {data!.components.map((c) => <td key={c} className="tabular py-2 pr-4 text-right">{p.values[c] ? peso(p.values[c], 0) : "-"}</td>)}
                      <td className="tabular py-2 text-right font-bold">{peso(p.total, 0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
      )}
    </div>
  );
}
