import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useSearch } from "wouter";
import { Download, Loader2, Paperclip, Plus, Search, Trash2, Wallet } from "lucide-react";
import { AccountPicker } from "@/components/account-picker";
import { Empty, ErrorNote, ListSkeleton, PageHeader, SubmissionBadge } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { api, download, PaymentOptions, Submission, SubmissionStatus } from "@/lib/api";
import { fmtDate, peso } from "@/lib/format";
import { useScope } from "@/lib/session";

const NO_BILL = "none";
const readB64 = (f: File) => new Promise<string>((ok, bad) => {
  const r = new FileReader();
  r.onload = () => ok(String(r.result).split(",")[1] || "");
  r.onerror = () => bad(new Error(`"${f.name}" could not be read.`));
  r.readAsDataURL(f);
});

export default function PaymentsPage() {
  const { ids } = useScope();
  const [status, setStatus] = useState<"all" | SubmissionStatus>("all");
  const [openId, setOpenId] = useState<number | null>(null);
  const preset = new URLSearchParams(useSearch()).get("bill");
  const [formOpen, setFormOpen] = useState(!!preset);
  const { data: opts } = useQuery<PaymentOptions>({ queryKey: ["/payments/options"] });
  const qs = `/payments?account_id=${ids.join(",")}${status !== "all" ? `&status=${status}` : ""}`;
  const { data, isLoading, error } = useQuery<Submission[]>({ queryKey: [qs], enabled: ids.length > 0 });

  return (
    <div>
      <PageHeader title="Payments" subtitle="Submit proof of payment and follow its validation. History covers the last 12 months."
        actions={<>
          <AccountPicker />
          {opts?.can_submit && <Button onClick={() => setFormOpen(true)} data-testid="new-payment"><Plus className="mr-1.5 h-4 w-4" />Submit proof of payment</Button>}
        </>} />
      <div className="mb-4">
        <Select value={status} onValueChange={(v) => setStatus(v as any)}>
          <SelectTrigger className="w-48 bg-card"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem><SelectItem value="for_validation">For validation</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem><SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <p className="mb-4 text-xs text-muted-foreground">Confirming a submission means RESCo accepted your proof. A bill's Paid status is updated separately when the payment is posted.</p>

      {error ? <ErrorNote error={error} /> : isLoading ? <ListSkeleton rows={5} /> : !data?.length ? (
        <Empty title="No payment submissions yet" hint={opts?.can_submit ? "Use Submit proof of payment after you pay a bill." : "Your Customer Administrator or Billing contact submits proof of payment."} />
      ) : (
        <div className="overflow-hidden rounded-xl border border-card-border bg-card shadow-[var(--shadow-sm)]">
          <Table>
            <TableHeader><TableRow className="bg-muted/60">
              <TableHead>Reference</TableHead><TableHead>Paid on</TableHead><TableHead className="hidden md:table-cell">Accounts</TableHead>
              <TableHead className="hidden sm:table-cell">Bank</TableHead><TableHead className="text-right">Amount</TableHead><TableHead>Status</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {data.map((s) => (
                <TableRow key={s.id} className="cursor-pointer" onClick={() => setOpenId(s.id)}>
                  <TableCell className="font-semibold">{s.reference}</TableCell>
                  <TableCell className="whitespace-nowrap">{fmtDate(s.payment_date)}</TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground">{[...new Set(s.lines.map((l) => l.csin))].join(", ")}</TableCell>
                  <TableCell className="hidden sm:table-cell">{s.bank_name}</TableCell>
                  <TableCell className="tabular text-right font-bold">{peso(s.amount_paid)}</TableCell>
                  <TableCell><SubmissionBadge status={s.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      <DetailDialog sub={data?.find((s) => s.id === openId) || null} onClose={() => setOpenId(null)} />
      {opts && <SubmitDialog open={formOpen} onClose={() => { setFormOpen(false); if (preset) window.location.hash = "#/payments"; }} opts={opts} presetBill={preset ? Number(preset) : null} onDone={(id) => { setFormOpen(false); setOpenId(id); }} />}
    </div>
  );
}

function DetailDialog({ sub, onClose }: { sub: Submission | null; onClose: () => void }) {
  const { toast } = useToast();
  return (
    <Dialog open={!!sub} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        {sub && (
          <>
            <DialogHeader>
              <DialogTitle>{sub.reference}</DialogTitle>
              <DialogDescription>Submitted {fmtDate(sub.submitted_on)} by {sub.submitted_by}</DialogDescription>
            </DialogHeader>
            <div className="flex items-center justify-between rounded-xl bg-primary/5 p-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Amount paid</p>
                <p className="tabular font-display text-3xl font-extrabold text-primary">{peso(sub.amount_paid)}</p>
                <p className="text-xs text-muted-foreground">{fmtDate(sub.payment_date)} · {sub.bank_name} · {sub.payment_mode.replace(/_/g, " ")}</p>
              </div>
              <SubmissionBadge status={sub.status} />
            </div>
            {sub.remarks && <p className="rounded-lg border border-border p-3 text-sm"><span className="font-semibold">RESCo remarks: </span>{sub.remarks}</p>}
            <Table>
              <TableHeader><TableRow><TableHead>Account</TableHead><TableHead>Bill</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
              <TableBody>
                {sub.lines.map((l, i) => (
                  <TableRow key={i}><TableCell><span className="block font-medium">{l.account_name}</span><span className="text-xs text-muted-foreground">CSIN {l.csin}</span></TableCell>
                    <TableCell>{l.bill_number ? `${l.bill_number} (${l.period})` : "Not specified"}</TableCell><TableCell className="tabular text-right">{peso(l.amount)}</TableCell></TableRow>
                ))}
              </TableBody>
            </Table>
            {sub.partial_view && <p className="text-xs text-muted-foreground">Part of this payment covers accounts you do not have access to. Only your accounts are listed.</p>}
            <div className="flex flex-wrap gap-2">
              {sub.files.map((f) => (
                <Button key={f.id} variant="outline" size="sm" onClick={async () => {
                  try { await download(`/payments/${sub.id}/file/${f.id}`, f.name); }
                  catch (e: any) { toast({ title: "Download failed", description: e.message, variant: "destructive" }); }
                }}><Download className="mr-1.5 h-3.5 w-3.5" />{f.name}</Button>
              ))}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

interface Row { key: number; account_id: string; bill_id: string; amount: string }

function SubmitDialog({ open, onClose, opts, presetBill, onDone }: { open: boolean; onClose: () => void; opts: PaymentOptions; presetBill: number | null; onDone: (id: number) => void }) {
  const { accounts } = useScope();
  const { toast } = useToast();
  const qc = useQueryClient();
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [bank, setBank] = useState("");
  const [mode, setMode] = useState("");
  const [amount, setAmount] = useState("");
  const [rows, setRows] = useState<Row[]>([{ key: 1, account_id: "", bill_id: NO_BILL, amount: "" }]);
  const [files, setFiles] = useState<File[]>([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const next = useRef(2);
  const applied = useRef(false);

  useEffect(() => {
    if (!open || applied.current || presetBill == null) return;
    const b = opts.open_bills.find((x) => x.id === presetBill);
    if (b) { applied.current = true; setRows([{ key: 1, account_id: String(b.account_id), bill_id: String(b.id), amount: "" }]); }
  }, [open, presetBill, opts]);

  const ql = q.trim().toLowerCase();
  const choices = useMemo(() => accounts.filter((a) => !ql || a.name.toLowerCase().includes(ql) || a.csin.toLowerCase().includes(ql)), [accounts, ql]);
  const total = rows.reduce((s, r) => s + (Number(r.amount) || 0), 0);
  const paid = Number(amount) || 0;
  const diff = Math.round((paid - total) * 100) / 100;
  const set = (key: number, patch: Partial<Row>) => setRows((rs) => rs.map((r) => (r.key === key ? { ...r, ...patch } : r)));

  const addFiles = (list: FileList | null) => {
    const picked = Array.from(list || []); const bad = picked.find((f) => f.size > opts.max_file_mb * 1024 * 1024);
    if (bad) { setErr(`"${bad.name}" is larger than ${opts.max_file_mb} MB.`); return; }
    setErr(""); setFiles((fs) => [...fs, ...picked].slice(0, opts.max_files));
  };

  const submit = async () => {
    setErr("");
    if (!date || !bank.trim() || !mode || !(paid > 0)) { setErr("Fill in the date, bank, mode of payment and amount paid."); return; }
    if (rows.some((r) => !r.account_id || !(Number(r.amount) > 0))) { setErr("Choose an account and enter an amount on every line."); return; }
    if (diff !== 0) { setErr(`The lines add up to ${peso(total)}, but the amount paid is ${peso(paid)}.`); return; }
    if (!files.length) { setErr("Attach the proof of payment (PNG, JPEG or PDF)."); return; }
    setBusy(true);
    try {
      const payload = {
        payment_date: date, bank_name: bank.trim(), payment_mode: mode, amount_paid: amount,
        lines: rows.map((r) => ({ account_id: Number(r.account_id), bill_id: r.bill_id === NO_BILL ? null : Number(r.bill_id), amount: r.amount })),
        files: await Promise.all(files.map(async (f) => ({ name: f.name, data: await readB64(f) }))),
      };
      const res = await api<Submission>("/payments", { method: "POST", body: payload });
      await qc.invalidateQueries();
      toast({ title: "Proof of payment received", description: `Reference ${res.reference}. We will validate it shortly.` });
      setBank(""); setMode(""); setAmount(""); setFiles([]); setRows([{ key: next.current++, account_id: "", bill_id: NO_BILL, amount: "" }]);
      onDone(res.id);
    } catch (e: any) { setErr(e.message || "The submission failed."); }
    finally { setBusy(false); }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit proof of payment</DialogTitle>
          <DialogDescription>Enter the payment details, split the amount across accounts and bills if needed, and attach the receipt.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5"><Label htmlFor="pd">Date of payment</Label><Input id="pd" type="date" max={today} value={date} onChange={(e) => setDate(e.target.value)} /></div>
          <div className="space-y-1.5"><Label htmlFor="pb">Bank name</Label><Input id="pb" maxLength={100} value={bank} onChange={(e) => setBank(e.target.value)} placeholder="e.g. BDO" /></div>
          <div className="space-y-1.5"><Label>Mode of payment</Label>
            <Select value={mode} onValueChange={setMode}><SelectTrigger><SelectValue placeholder="Choose" /></SelectTrigger>
              <SelectContent>{opts.modes.map((m) => <SelectItem key={m.key} value={m.key}>{m.label}</SelectItem>)}</SelectContent></Select></div>
          <div className="space-y-1.5"><Label htmlFor="pa">Amount paid (PHP)</Label><Input id="pa" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))} placeholder="0.00" /></div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm font-semibold">Accounts and bills paid</p>
            {accounts.length > 3 && (
              <div className="relative w-56"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find account name or CSIN" className="h-9 pl-8" aria-label="Search accounts" /></div>
            )}
          </div>
          {rows.map((r) => {
            const bills = opts.open_bills.filter((b) => String(b.account_id) === r.account_id);
            return (
              <div key={r.key} className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-[1.4fr_1.2fr_.9fr_auto]">
                <Select value={r.account_id} onValueChange={(v) => set(r.key, { account_id: v, bill_id: NO_BILL })}>
                  <SelectTrigger aria-label="Account"><SelectValue placeholder="Account" /></SelectTrigger>
                  <SelectContent>
                    {choices.map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name} ({a.csin})</SelectItem>)}
                    {r.account_id && !choices.some((a) => String(a.id) === r.account_id) && accounts.filter((a) => String(a.id) === r.account_id).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name} ({a.csin})</SelectItem>)}
                    {!choices.length && <div className="p-2 text-sm text-muted-foreground">No account matches.</div>}
                  </SelectContent>
                </Select>
                <Select value={r.bill_id} onValueChange={(v) => set(r.key, { bill_id: v })} disabled={!r.account_id}>
                  <SelectTrigger aria-label="Bill"><SelectValue placeholder="Bill" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NO_BILL}>Not specified</SelectItem>
                    {bills.map((b) => <SelectItem key={b.id} value={String(b.id)}>{b.bill_number} · {b.period} · {peso(b.outstanding)}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Input inputMode="decimal" aria-label="Amount" value={r.amount} onChange={(e) => set(r.key, { amount: e.target.value.replace(/[^0-9.]/g, "") })} placeholder="Amount" />
                <Button variant="ghost" size="icon" aria-label="Remove line" disabled={rows.length === 1} onClick={() => setRows((rs) => rs.filter((x) => x.key !== r.key))}><Trash2 className="h-4 w-4" /></Button>
              </div>
            );
          })}
          <div className="flex items-center justify-between">
            <Button variant="outline" size="sm" onClick={() => setRows((rs) => [...rs, { key: next.current++, account_id: "", bill_id: NO_BILL, amount: "" }])}><Plus className="mr-1 h-3.5 w-3.5" />Add account</Button>
            <p className={`tabular text-sm ${diff === 0 && paid > 0 ? "text-emerald-700" : "text-muted-foreground"}`}>Allocated {peso(total)} of {peso(paid)}{diff !== 0 && paid > 0 ? ` (${diff > 0 ? "remaining" : "over by"} ${peso(Math.abs(diff))})` : ""}</p>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="pf">Proof of payment</Label>
          <label htmlFor="pf" className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border p-3 text-sm text-muted-foreground hover:bg-muted/50">
            <Paperclip className="h-4 w-4" />PNG, JPEG or PDF, up to {opts.max_file_mb} MB each, at most {opts.max_files} files
          </label>
          <input id="pf" type="file" multiple accept="image/png,image/jpeg,application/pdf" className="sr-only" onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }} />
          {files.map((f, i) => (
            <div key={i} className="flex items-center justify-between rounded-md bg-muted/60 px-3 py-1.5 text-sm">
              <span className="truncate">{f.name}</span>
              <Button variant="ghost" size="sm" onClick={() => setFiles((fs) => fs.filter((_, j) => j !== i))}>Remove</Button>
            </div>
          ))}
        </div>

        {err && <p role="alert" className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">{err}</p>}
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} disabled={busy}>Cancel</Button>
          <Button onClick={submit} disabled={busy} data-testid="submit-payment">{busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Wallet className="mr-1.5 h-4 w-4" />}Submit</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
