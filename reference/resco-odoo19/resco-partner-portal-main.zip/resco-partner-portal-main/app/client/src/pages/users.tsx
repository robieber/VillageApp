import { useQuery } from "@tanstack/react-query";
import { Empty, ErrorNote, ListSkeleton, PageHeader } from "@/components/common";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { CompanyUser } from "@/lib/api";
import { useSession } from "@/lib/session";

const ROLE = { admin: "Customer Administrator", billing: "Billing contact", viewer: "Viewer" };

export default function UsersPage() {
  const { me } = useSession();
  const { data, isLoading, error } = useQuery<CompanyUser[]>({ queryKey: ["/company/users"], enabled: me?.role === "admin" });
  if (me?.role !== "admin") return <Empty title="Only Customer Administrators can see this page" />;
  return (
    <div>
      <PageHeader title="Company Users" subtitle={`People at ${me.company.name} who can sign in, and the accounts each can see. To add or change users, contact your account manager.`} />
      {error ? <ErrorNote error={error} /> : isLoading ? <ListSkeleton /> : (
        <div className="overflow-hidden rounded-xl border border-card-border bg-card shadow-[var(--shadow-sm)]">
          <Table>
            <TableHeader><TableRow className="bg-muted/60"><TableHead>Name</TableHead><TableHead>Role</TableHead><TableHead>Accounts</TableHead></TableRow></TableHeader>
            <TableBody>
              {data?.map((u) => (
                <TableRow key={u.id}>
                  <TableCell><span className="block font-semibold">{u.name}</span><span className="text-xs text-muted-foreground">{u.email}{u.designation ? ` · ${u.designation}` : ""}</span></TableCell>
                  <TableCell>{ROLE[u.role]}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1.5">
                      {u.accounts.map((a) => <span key={a.id} className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">{a.name}</span>)}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
