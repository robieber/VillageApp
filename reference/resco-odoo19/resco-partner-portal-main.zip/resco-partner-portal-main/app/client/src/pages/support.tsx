import { useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Loader2, LifeBuoy, Paperclip, Plus, Send } from "lucide-react";
import { AccountPicker } from "@/components/account-picker";
import { Empty, ErrorNote, ListSkeleton, PageHeader, TicketBadge } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { api, download, Ticket, TicketOptions, TicketStatus } from "@/lib/api";
import { fmtDate } from "@/lib/format";
import { useScope } from "@/lib/session";

const readB64 = (f: File) => new Promise<string>((ok, bad) => {
  const r = new FileReader();
  r.onload = () => ok(String(r.result).split(",")[1] || "");
  r.onerror = () => bad(new Error(`"${f.name}" could not be read.`));
  r.readAsDataURL(f);
});

function FilePicker({ files, setFiles, opts, setErr }: { files: File[]; setFiles: (f: File[]) => void; opts?: TicketOptions; setErr: (s: string) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const max = opts?.max_files ?? 5; const mb = opts?.max_file_mb ?? 5;
  return (
    <div className="space-y-2">
      <Button type="button" variant="outline" size="sm" onClick={() => ref.current?.click()}><Paperclip className="mr-1.5 h-3.5 w-3.5" />Attach files</Button>
      <input ref={ref} type="file" multiple accept="image/png,image/jpeg,application/pdf" className="sr-only" aria-label="Attach files"
        onChange={(e) => {
          const picked = Array.from(e.target.files || []); e.target.value = "";
          const bad = picked.find((f) => f.size > mb * 1024 * 1024);
          if (bad) { setErr(`"${bad.name}" is larger than ${mb} MB.`); return; }
          setErr(""); setFiles([...files, ...picked].slice(0, max));
        }} />
      <span className="ml-2 text-xs text-muted-foreground">PNG, JPEG or PDF, up to {mb} MB each, at most {max}</span>
      {files.map((f, i) => (
        <div key={i} className="flex items-center justify-between rounded-md bg-muted/60 px-3 py-1.5 text-sm">
          <span className="truncate">{f.name}</span><Button type="button" variant="ghost" size="sm" onClick={() => setFiles(files.filter((_, j) => j !== i))}>Remove</Button>
        </div>
      ))}
    </div>
  );
}

export default function SupportPage() {
  const { ids } = useScope();
  const [status, setStatus] = useState<"all" | TicketStatus>("all");
  const [openId, setOpenId] = useState<number | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const { data: opts } = useQuery<TicketOptions>({ queryKey: ["/tickets/options"] });
  const qs = `/tickets?account_id=${ids.join(",")}${status !== "all" ? `&status=${status}` : ""}`;
  const { data, isLoading, error } = useQuery<Ticket[]>({ queryKey: [qs], enabled: ids.length > 0 });

  return (
    <div>
      <PageHeader title="Support" subtitle="Send a concern or a message to your account manager and follow the replies here."
        actions={<><AccountPicker /><Button onClick={() => setFormOpen(true)} data-testid="new-ticket"><Plus className="mr-1.5 h-4 w-4" />New request</Button></>} />
      <div className="mb-4">
        <Select value={status} onValueChange={(v) => setStatus(v as any)}>
          <SelectTrigger className="w-52 bg-card"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem><SelectItem value="new">New</SelectItem><SelectItem value="in_progress">In progress</SelectItem>
            <SelectItem value="waiting_customer">Waiting for you</SelectItem><SelectItem value="resolved">Resolved</SelectItem><SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {error ? <ErrorNote error={error} /> : isLoading ? <ListSkeleton rows={4} /> : !data?.length ? (
        <Empty title="No requests yet" hint="Use New request to reach your account manager or the support team." />
      ) : (
        <div className="overflow-hidden rounded-xl border border-card-border bg-card shadow-[var(--shadow-sm)]">
          <Table>
            <TableHeader><TableRow className="bg-muted/60">
              <TableHead>Reference</TableHead><TableHead>Subject</TableHead><TableHead className="hidden md:table-cell">Category</TableHead>
              <TableHead className="hidden sm:table-cell">Last activity</TableHead><TableHead>Status</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {data.map((t) => (
                <TableRow key={t.id} className="cursor-pointer" onClick={() => setOpenId(t.id)}>
                  <TableCell className="whitespace-nowrap font-semibold">{t.reference}</TableCell>
                  <TableCell><span className="block font-medium">{t.subject}</span><span className="text-xs text-muted-foreground">CSIN {t.csin}</span></TableCell>
                  <TableCell className="hidden md:table-cell">{t.category}</TableCell>
                  <TableCell className="hidden sm:table-cell whitespace-nowrap">{fmtDate(t.last_activity)}</TableCell>
                  <TableCell><TicketBadge status={t.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      <NewTicket open={formOpen} onClose={() => setFormOpen(false)} opts={opts} onDone={(id) => { setFormOpen(false); setOpenId(id); }} />
      <TicketDetail id={openId} onClose={() => setOpenId(null)} opts={opts} />
    </div>
  );
}

function NewTicket({ open, onClose, opts, onDone }: { open: boolean; onClose: () => void; opts?: TicketOptions; onDone: (id: number) => void }) {
  const { accounts } = useScope();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [account, setAccount] = useState(""); const [category, setCategory] = useState("");
  const [subject, setSubject] = useState(""); const [text, setText] = useState("");
  const [files, setFiles] = useState<File[]>([]); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const acc = account || (accounts.length === 1 ? String(accounts[0].id) : "");
  const sam = accounts.find((a) => String(a.id) === acc)?.sam;

  const send = async () => {
    if (!acc || !category || !subject.trim() || !text.trim()) { setErr("Choose an account and a category, then add a subject and your message."); return; }
    setBusy(true); setErr("");
    try {
      const body = { account_id: Number(acc), category_id: Number(category), subject: subject.trim(), description: text.trim(),
        files: await Promise.all(files.map(async (f) => ({ name: f.name, data: await readB64(f) }))) };
      const t = await api<Ticket>("/tickets", { method: "POST", body });
      await qc.invalidateQueries();
      toast({ title: "Request sent", description: `Reference ${t.reference}.` });
      setSubject(""); setText(""); setFiles([]); setCategory("");
      onDone(t.id);
    } catch (e: any) { setErr(e.message || "The request could not be sent."); } finally { setBusy(false); }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="max-h-[92vh] max-w-xl overflow-y-auto">
        <DialogHeader><DialogTitle>New request</DialogTitle><DialogDescription>Tell us what you need. Replies appear here and are emailed to you.</DialogDescription></DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5"><Label>Account</Label>
            <Select value={acc} onValueChange={setAccount}><SelectTrigger aria-label="Account"><SelectValue placeholder="Choose" /></SelectTrigger>
              <SelectContent>{accounts.map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name} ({a.csin})</SelectItem>)}</SelectContent></Select></div>
          <div className="space-y-1.5"><Label>Category</Label>
            <Select value={category} onValueChange={setCategory}><SelectTrigger aria-label="Category"><SelectValue placeholder="Choose" /></SelectTrigger>
              <SelectContent>{opts?.categories.map((c) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent></Select></div>
        </div>
        {sam && opts?.categories.find((c) => String(c.id) === category)?.to_account_manager && (
          <p className="rounded-lg bg-primary/5 p-3 text-sm">This goes to your account manager, {sam.name}.</p>
        )}
        <div className="space-y-1.5"><Label htmlFor="ts">Subject</Label><Input id="ts" maxLength={200} value={subject} onChange={(e) => setSubject(e.target.value)} /></div>
        <div className="space-y-1.5"><Label htmlFor="td">Message</Label><Textarea id="td" rows={5} maxLength={5000} value={text} onChange={(e) => setText(e.target.value)} placeholder="Include bill numbers or months if they help." /></div>
        <FilePicker files={files} setFiles={setFiles} opts={opts} setErr={setErr} />
        {err && <p role="alert" className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">{err}</p>}
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} disabled={busy}>Cancel</Button>
          <Button onClick={send} disabled={busy} data-testid="send-ticket">{busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <LifeBuoy className="mr-1.5 h-4 w-4" />}Send</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function TicketDetail({ id, onClose, opts }: { id: number | null; onClose: () => void; opts?: TicketOptions }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: t } = useQuery<Ticket>({ queryKey: [`/tickets/${id}`], enabled: id != null });
  const [text, setText] = useState(""); const [files, setFiles] = useState<File[]>([]); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);

  const reply = async () => {
    if (!text.trim() && !files.length) { setErr("Write a message or attach a file."); return; }
    setBusy(true); setErr("");
    try {
      await api(`/tickets/${id}/reply`, { method: "POST", body: { message: text.trim(), files: await Promise.all(files.map(async (f) => ({ name: f.name, data: await readB64(f) }))) } });
      setText(""); setFiles([]); await qc.invalidateQueries();
    } catch (e: any) { setErr(e.message || "The reply could not be sent."); } finally { setBusy(false); }
  };

  return (
    <Dialog open={id != null} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto">
        {t ? (
          <>
            <DialogHeader>
              <DialogTitle className="pr-6">{t.subject}</DialogTitle>
              <DialogDescription>{t.reference} · {t.category} · CSIN {t.csin} · opened {fmtDate(t.created_on)}{t.assigned_to ? ` · with ${t.assigned_to}` : ""}</DialogDescription>
            </DialogHeader>
            <div><TicketBadge status={t.status} /></div>
            <div className="space-y-3">
              {t.messages?.map((m) => (
                <div key={m.id} className={`rounded-xl p-3 text-sm ${m.staff ? "bg-primary/5" : "border border-border"}`}>
                  <div className="mb-1 flex justify-between text-xs text-muted-foreground"><span className="font-semibold">{m.staff ? `RESCo · ${m.from}` : m.from}</span><span>{fmtDate(m.at)}</span></div>
                  <p className="whitespace-pre-wrap break-words">{m.text}</p>
                  {!!m.files.length && <div className="mt-2 flex flex-wrap gap-2">{m.files.map((f) => (
                    <Button key={f.id} variant="outline" size="sm" onClick={async () => {
                      try { await download(`/tickets/${t.id}/file/${f.id}`, f.name); } catch (e: any) { toast({ title: "Download failed", description: e.message, variant: "destructive" }); }
                    }}><Download className="mr-1.5 h-3.5 w-3.5" />{f.name}</Button>))}</div>}
                </div>
              ))}
            </div>
            {t.status === "closed" ? <p className="text-sm text-muted-foreground">This request is closed. Open a new request if you still need help.</p> : (
              <div className="space-y-2">
                <Label htmlFor="tr">Your reply</Label>
                <Textarea id="tr" rows={3} maxLength={5000} value={text} onChange={(e) => setText(e.target.value)} />
                <FilePicker files={files} setFiles={setFiles} opts={opts} setErr={setErr} />
                {err && <p role="alert" className="text-sm text-destructive">{err}</p>}
                <div className="flex justify-end"><Button onClick={reply} disabled={busy}>{busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Send className="mr-1.5 h-4 w-4" />}Send reply</Button></div>
              </div>
            )}
          </>
        ) : <ListSkeleton rows={3} />}
      </DialogContent>
    </Dialog>
  );
}
