import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, ExternalLink, MapPin } from "lucide-react";
import { Empty, ErrorNote, ListSkeleton, PageHeader } from "@/components/common";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { API_ORIGIN, Updates } from "@/lib/api";
import { fmtDate } from "@/lib/format";

/** Published content from the RESCo website: bulletins, regulatory updates, advisories, events and guideline pages. Links open the site. */
export default function UpdatesPage() {
  const { data, isLoading, error } = useQuery<Updates>({ queryKey: ["/updates"] });
  const [tab, setTab] = useState("all");
  const blogs = useMemo(() => [...new Set((data?.posts || []).map((p) => p.blog))], [data]);
  const posts = (data?.posts || []).filter((p) => tab === "all" || p.blog === tab);
  const link = (u: string) => `${API_ORIGIN}${u}`;

  return (
    <div>
      <PageHeader title="Updates" subtitle="Energy bulletins, regulatory updates, advisories and events from your supplier." />
      {error ? <ErrorNote error={error} /> : isLoading ? <ListSkeleton rows={4} /> : (
        <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
          <section aria-label="Posts">
            <Tabs value={tab} onValueChange={setTab} className="mb-4">
              <TabsList className="flex-wrap h-auto"><TabsTrigger value="all">All</TabsTrigger>{blogs.map((b) => <TabsTrigger key={b} value={b}>{b}</TabsTrigger>)}</TabsList>
            </Tabs>
            {!posts.length ? <Empty title="Nothing published yet" hint="New bulletins and advisories will appear here." /> : (
              <ul className="space-y-3">
                {posts.map((p) => (
                  <li key={p.id} className="rounded-xl border border-card-border bg-card p-4 shadow-[var(--shadow-sm)]">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{p.blog} · {fmtDate(p.published)}</p>
                    <a href={link(p.url)} target="_blank" rel="noopener noreferrer" className="mt-1 flex items-start gap-1.5 font-display text-lg font-bold text-primary hover:underline">
                      {p.title}<ExternalLink className="mt-1.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                    </a>
                    {p.subtitle && <p className="mt-1 text-sm text-muted-foreground">{p.subtitle}</p>}
                  </li>
                ))}
              </ul>
            )}
          </section>
          <aside className="space-y-6">
            <section aria-label="Events">
              <h2 className="mb-2 font-display text-base font-bold">Upcoming events</h2>
              {!data?.events.length ? <p className="text-sm text-muted-foreground">No upcoming events.</p> : (
                <ul className="space-y-2">
                  {data.events.map((e) => (
                    <li key={e.id} className="rounded-xl border border-card-border bg-card p-3 text-sm">
                      <a href={link(e.url)} target="_blank" rel="noopener noreferrer" className="font-semibold text-primary hover:underline">{e.title}</a>
                      <p className="mt-1 flex items-center gap-1.5 text-muted-foreground"><CalendarDays className="h-3.5 w-3.5" />{fmtDate(e.start)}</p>
                      {e.location && <p className="flex items-center gap-1.5 text-muted-foreground"><MapPin className="h-3.5 w-3.5" />{e.location}</p>}
                    </li>
                  ))}
                </ul>
              )}
            </section>
            <section aria-label="Guides">
              <h2 className="mb-2 font-display text-base font-bold">Guides</h2>
              <ul className="space-y-1 text-sm">{data?.pages.map((p) => <li key={p.url}><a href={link(p.url)} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{p.title}</a></li>)}</ul>
            </section>
          </aside>
        </div>
      )}
    </div>
  );
}
