import { Route, Router, Switch } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { QueryClientProvider } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Empty } from "@/components/common";
import { Shell } from "@/components/shell";
import { queryClient } from "@/lib/api";
import { ScopeProvider, SessionProvider, useSession } from "@/lib/session";
import LoginPage from "@/pages/login";
import OverviewPage from "@/pages/overview";
import BillsPage from "@/pages/bills";
import UpdatesPage from "@/pages/updates";
import SupportPage from "@/pages/support";
import PaymentsPage from "@/pages/payments";
import HistoryPage from "@/pages/history";
import EnergyPage from "@/pages/energy";
import ProfilePage from "@/pages/profile";
import UsersPage from "@/pages/users";

function Gate() {
  const { me, loading } = useSession();
  if (loading) return <div className="flex min-h-dvh items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;
  if (!me) return <LoginPage />;
  return (
    <ScopeProvider>
      <Shell>
        <Switch>
          <Route path="/" component={OverviewPage} />
          <Route path="/bills" component={BillsPage} />
          <Route path="/payments" component={PaymentsPage} />
          <Route path="/support" component={SupportPage} />
          <Route path="/updates" component={UpdatesPage} />
          <Route path="/history" component={HistoryPage} />
          <Route path="/energy" component={EnergyPage} />
          <Route path="/profile" component={ProfilePage} />
          <Route path="/users" component={UsersPage} />
          <Route><Empty title="Page not found" hint="The link may be out of date." /></Route>
        </Switch>
      </Shell>
    </ScopeProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SessionProvider><Router hook={useHashLocation}><Gate /></Router></SessionProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
