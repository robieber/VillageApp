# Build plan

Estimates are developer man-days from the fit-gap workbook (RESCo-Partner-Portal-Odoo-Fit-Gap.xlsx).

| Wave | Content | Status |
|---|---|---|
| R1 | Backend: accounts and access, bills and loader (SFTP and manual), notifications, lifecycle, event log, API | In this repo |
| R1b | React account area: login, accounts, bills with PDF, profile, SAM card, company users; desktop navigation shell | Next |
| R2b | Helpdesk (tickets, routing to account manager or support team, replies, status emails), Gemini portal assistant, privacy consent, portal popups, file library, bulk user CSV, email template editor, website content (blogs, events, pages, menus, version history) | Built (this branch) |
| R2a | Proof of payment: customer form with split across accounts and bills, staff validation queue, 12-month history, emails, report | Built (this branch) |
| R2 | Website CMS (advisories, bulletins, regulatory updates, events, static pages, popups, consent), helpdesk tickets and routing, billing history and energy charts UI, CSV user batches, email template set | Planned |
| R3 | Reports (users, logins, downloads, page hits, bills loaded, payments, exceptions), Google Analytics, interval energy data if available | Planned |

## Placeholders to replace

* `lib/password_policy.py`: RESCo cybersecurity standard (FR-WEB-016).
* Reminder days (Settings > RESCo Portal), default 5 days before, 1 day before, 1 day after.
* Cost component codes and the final CMS-RES file layout.
