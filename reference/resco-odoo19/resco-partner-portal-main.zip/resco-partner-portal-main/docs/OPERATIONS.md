# Operations: patching and logging

## Patching routine
| What | How | When |
|---|---|---|
| VM operating system security fixes | Automatic (`unattended-upgrades`). Set up by `infra/poc/create_vm.sh` for new VMs, or `sudo bash deploy/ops/harden_host.sh` on an existing one. A needed reboot happens at 03:30 Philippine time; Docker restarts the containers. | Daily |
| Container images (Odoo base, PostgreSQL 16, Caddy) | `bash deploy/ops/update_images.sh`: backup, pull, rebuild, restart, health check, automatic rollback of the Odoo image if unhealthy. `bash deploy/ops/install_update_cron.sh` schedules it for the first Sunday of each month at 03:00. | Monthly, and at once for a critical advisory |
| App dependencies (npm, GitHub Actions, base image tag) | Dependabot pull requests every week. CI fails on a high-severity vulnerability in production npm packages, and the image is scanned (report only). | Weekly |
| Whole pipeline | CI also runs every Monday so new advisories and base image changes show up without a code change. | Weekly |
| Odoo major version | Planned project, tested on a staging copy first. Never done by the scripts above. | Yearly |

Response targets: critical flaw in something we run, patched within 48 hours; actively exploited, the same day.
Build tooling: CI builds the React app on Node 22. The production servers run no Node and no PHP.

## Logging
| Source | Where it goes |
|---|---|
| Odoo, PostgreSQL and Caddy containers | Local files with rotation (10 MB x 3) by default. On GCP, add `COMPOSE_FILE=docker-compose.yml:docker-compose.gcp-logging.yml` to `deploy/.env` to send them to Cloud Logging. |
| Web requests | Caddy writes one JSON line per request (client IP, path, status). |
| Portal events (sign-ins, failed sign-ins, uploads, payment actions) | Stored in the database event log and also written to the application log as `AUDIT {json}`, so a copy exists outside the database. |
| Operating system | Standard system log; update history in `/var/log/unattended-upgrades/`. |

One-time set up in Cloud Shell: `PROJECT=resco-512413 bash infra/poc/setup_logging.sh`. It creates a log bucket with 365 days retention (optionally lockable), routes the container logs to it, and creates counters for failed sign-ins, Odoo errors and web 5xx responses, which you can alert on.

On AWS the same pattern applies: container logs to CloudWatch Logs (log driver `awslogs`), the load balancer and WAF logs to S3, and an S3 bucket with Object Lock for the archive.

## Not covered yet
* Alert policies are created by hand in the console (the script prints the steps).
* Staging environment: until one exists, the monthly update relies on the backup and the automatic rollback.
* Secrets still live in `deploy/.env`; move to a secrets manager with the AWS move.
