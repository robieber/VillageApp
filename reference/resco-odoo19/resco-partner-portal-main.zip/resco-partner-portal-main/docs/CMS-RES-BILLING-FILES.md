# CMS-RES batch files (interim layout)

Interim layout agreed for the build until CMS-RES supplies its own. It is the four-file layout proposed for the
original design, with the Salesforce-only parts removed (no ContentVersion manifest, no Salesforce IDs, no load order
dependency). CMS-RES still needs to confirm it.

A batch is a set of files delivered together. File names are matched by prefix; the part after the prefix is free
(for example the month).

| Prefix | Content | Required |
|---|---|---|
| `MPWR_BILL_HDR_*.csv` | One row per bill (File 1) | for new or revised bills |
| `MPWR_BILL_COMP_*.csv` | One row per bill cost component (File 2) | with every header file |
| `<PDF_FILE_NAME>` | The bill PDFs named in File 1, e.g. `202609-CS123.pdf` | one per bill |
| `MPWR_PAY_STAT_*.csv` | Payment status updates (File 4) | optional, can be sent alone |
| `MPWR_ENERGY_HRLY_*.csv` | Hourly energy per account | optional, can be sent alone |
| `MPWR_BILL_PDF_*.csv` | File 3, the Salesforce manifest | not needed; ignored with a warning |

## File 1: bill header

Required columns: BILL_KEY, CSIN, ACCOUNT_NAME, SERVICE_ADDRESS, BILL_NUMBER, BILL_MONTH, BILL_YEAR, BILL_DATE,
BILLING_PERIOD_FROM, BILLING_PERIOD_TO, DUE_DATE, PRICING_PRODUCT, CONTRACTED_CAPACITY_KW, ENERGY_KWH,
CURRENT_CHARGES, VAT_AMOUNT, TOTAL_AMOUNT_DUE, CURRENCY, PAYMENT_STATUS, PDF_FILE_NAME, IS_REVISED.

Optional: PARENT_COMPANY_ID, MEQ_KWH, CHANGE_IN_ENERGY_KWH, PEAK_KWH, OFFPEAK_KWH, PEAK_DEMAND_KW, PREVIOUS_BALANCE,
ADJUSTMENTS, SUPERSEDES_BILL_KEY, SOURCE_SYSTEM, EXTRACT_BATCH_ID, EXTRACT_TIMESTAMP.

Rules, each rejecting that one bill:

* CSIN must exist in Odoo. ACCOUNT_NAME that differs from Odoo is only a warning.
* BILL_KEY (`CSIN-YYYYMM-BILLNO`) is unique in the file, and so are CSIN with month and year, and PDF_FILE_NAME.
* TOTAL_AMOUNT_DUE = PREVIOUS_BALANCE + CURRENT_CHARGES + VAT_AMOUNT + ADJUSTMENTS (to the centavo). CURRENT_CHARGES excludes VAT.
* BILLING_PERIOD_TO is not before BILLING_PERIOD_FROM. CURRENCY is PHP.
* IS_REVISED = Y needs SUPERSEDES_BILL_KEY.
* The PDF must be in the batch, start with `%PDF-`, and be at most 10 MB.
* The bill needs at least one component in File 2. Components not adding up to CURRENT_CHARGES (VAT excluded) is a warning.

PAYMENT_STATUS values: `UNPAID`, `PARTIALLY_PAID`, `PAID`, `OVERDUE`.

## File 2: cost components

BILL_KEY, COMPONENT_CODE, COMPONENT_NAME, AMOUNT, SORT_ORDER (required); QUANTITY, UOM (`KWH`, `KW`, `FIXED`), RATE
(optional). One row per component per bill; a code may appear once per bill. COMPONENT_NAME is the legend label in the
Billing History chart; SORT_ORDER is the stacking order.

## File 4: payment status updates

BILL_KEY, PAYMENT_STATUS, AMOUNT_PAID, OUTSTANDING_BALANCE, STATUS_AS_OF (required); LAST_PAYMENT_DATE (optional).
The bill must exist in Odoo or in the same batch. An update older than the status already held (STATUS_AS_OF) is
skipped, so a late-arriving file cannot undo a newer one.

Portal-side proof-of-payment states (For Validation, Confirmed, Rejected) are kept on the payment submission record
(Phase 2), not on the bill, so CMS-RES posting and administrator validation cannot overwrite each other.

## Hourly energy (proposed, not in the original design)

CSIN, INTERVAL_START, KWH (required); KW_DEMAND (optional). INTERVAL_START is ISO 8601 with offset, for example
`2026-09-01T13:00:00+08:00` (no offset is read as Philippine time). One row per account and interval; re-sending an
interval replaces it. The Energy Dashboard uses it for:

* daily view for one month: bars are kWh per day, line is the highest kW in the day;
* hourly view for one day: bars are kWh per hour, line is kW.

The yearly view (clustered columns per month) comes from the bills: ENERGY_KWH against MEQ_KWH.

## Conventions

UTF-8, comma-delimited, double-quoted text, header row required (Windows-1252 is also accepted). Dates `YYYY-MM-DD`,
datetimes ISO 8601 with `+08:00`. No thousands separators.

## Re-loads

A bill for the same account and month that already exists is replaced. The previous PDF and components stay in Odoo as
an archived version (Bills, filter Superseded versions). Manual upload lists every replacement and asks for
confirmation; SFTP replaces automatically and notes it in the batch result. The bill-ready email is sent only for new
bills. Re-sending the same File 1 is safe: it produces a new version rather than a duplicate.

## SFTP

```
/inbound/<BATCH_ID>/    all files of one batch, then a file ending in .done written LAST
/processed/<BATCH_ID>/  moved here after loading, with result.txt
/error/<BATCH_ID>/      moved here when nothing could be loaded, with result.txt
```

Authentication is by SSH key. The server host-key fingerprint (`SHA256:...`) is stored in Odoo and the connection is
refused if the server presents a different key. Odoo checks every 15 minutes.

## Open points for CMS-RES

* Confirm the column set, the component codes (GEN, TRANS, SYSLOSS, DIST, UC, FIT, GOVTAX, OTHER proposed) and whether
  VAT is its own column, as assumed, or a component.
* Confirm the meaning of MEQ_KWH and CHANGE_IN_ENERGY_KWH.
* Confirm the hourly file: grain (hourly or 15-minute), whether KW_DEMAND is available, and who produces it.


## Account file and control file (added with the sample data set)
* `MPWR_ACCOUNT_*.csv` creates or updates customer accounts. Columns: CSIN, ACCOUNT_NAME, PARENT_COMPANY_ID, PARENT_COMPANY_NAME,
  SERVICE_ADDRESS, PRICING_PRODUCT, CONTRACTED_CAPACITY_KW, MEQ_KWH, CONTRACT_START, CONTRACT_END, SAM_NAME, SAM_EMAIL,
  PRIMARY_CONTACT_NAME, PRIMARY_CONTACT_EMAIL, PRIMARY_CONTACT_MOBILE, ACCOUNT_STATUS (Active or anything else to archive).
  Accounts of the same parent company share one company record. The primary contact becomes a portal user with the Customer
  Administrator role on that account. Odoo is the master, so reloading a CSIN updates it.
* `MPWR_CTRL_*.csv` lists, per file, ROW_COUNT, CONTROL_FIELD and CONTROL_TOTAL. If a listed file in the batch does not match,
  nothing in the batch is loaded. Files not in the batch are ignored, and a field that is not a column (FILE_COUNT) is checked by row count only.
* `MPWR_PAYMENT_SUBMISSION_*.csv` (proof of payment) is not loaded yet; it belongs to the Phase 2 payment submission feature.
