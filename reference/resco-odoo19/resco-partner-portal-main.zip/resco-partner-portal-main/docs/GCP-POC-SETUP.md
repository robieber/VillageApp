# RESCo POC server on Google Cloud

One virtual machine runs everything in Docker: Caddy (HTTPS), Odoo 19 and PostgreSQL 16. The portal app is already built into the `resco_portal` module, so the server needs no Node.js.

## Before you start
- A Google account with billing enabled on a Google Cloud project. Create the project in the console (name it `resco-poc`) and link a billing account.
- Access to the private repository `robieber/resco-partner-portal`.

## 1. Create the server (Cloud Shell, about 5 minutes)
Open [Cloud Shell](https://shell.cloud.google.com), then:

```bash
git clone https://github.com/robieber/resco-partner-portal.git   # sign in with your GitHub token when asked
cd resco-partner-portal
git checkout wave-r1b/mpower-app          # until the pull requests are merged
PROJECT=<your-project-id> bash infra/poc/create_vm.sh
```
The script reserves a fixed IP, opens ports 80 and 443, creates an e2-standard-2 VM (2 vCPU, 8 GB, Singapore) with Docker, and sets a daily snapshot. It prints the server IP and the portal address, for example `portal.34.1.2.3.sslip.io`. That address works with automatic HTTPS and needs no domain. Use your own domain later by pointing an A record at the IP.

## 2. Connect and fetch the code
```bash
gcloud --project <your-project-id> compute ssh resco-odoo --zone asia-southeast1-b
sudo su - deploy
ssh-keygen -t ed25519 -N "" -f ~/.ssh/id_ed25519 && cat ~/.ssh/id_ed25519.pub
```
In GitHub, open the repository, Settings, Deploy keys, add the printed key (read-only). Then:
```bash
git clone -b wave-r1b/mpower-app git@github.com:robieber/resco-partner-portal.git
cd resco-partner-portal/deploy
```

## 3. Configure
```bash
cp .env.example .env
nano .env     # set DB_PASSWORD, ADMIN_PASSWORD, MASTER_PASSWORD (long random values) and PORTAL_HOST=portal.<IP>.sslip.io
nano odoo.conf   # replace CHANGE_ME_MASTER_PASSWORD with the same MASTER_PASSWORD
```
Keep these values in your password manager. Never commit `.env`.

## 4. Install and start
```bash
sudo docker compose build
sudo docker compose up -d db
sudo docker compose run --rm odoo odoo -d resco -i resco_portal,resco_leads,resco_website,l10n_ph --stop-after-init
sudo docker compose run --rm -T odoo odoo shell -d resco < bootstrap.py
sudo docker compose up -d
```
Optional demo data (36 bills and hourly readings for a sample customer):
```bash
sudo docker compose run --rm -T -e SEED_PASSWORD='<demo-user-password>' odoo odoo shell -d resco < seed_demo.py
```
Check `https://<PORTAL_HOST>/web/health`, then sign in to Odoo at `https://<PORTAL_HOST>/web` as `admin` with ADMIN_PASSWORD. Customers use `https://<PORTAL_HOST>/portal-app`. The lead form is at `/get-in-touch`.

## 5. Backups and day-to-day
- Disk snapshots run daily (step 5 of the script). For database dumps, install `deploy/wave0/install_backups.sh` (writes to `/home/deploy/backups`).
- Update: `cd ~/resco-partner-portal && git pull && cd deploy && sudo docker compose run --rm odoo odoo -d resco -u resco_portal,resco_leads,resco_website --stop-after-init && sudo docker compose up -d`
- Save money when idle: stop the VM from the console or `gcloud compute instances stop resco-odoo --zone asia-southeast1-b`. The fixed IP keeps a small charge while the VM is stopped. Check the [pricing calculator](https://cloud.google.com/products/calculator) for the running cost.
- Email: Odoo needs an outgoing mail server (Settings, Technical, Outgoing Mail Servers) for password resets, reminders and lead notices.

## 6. Bill files
- Manual: Odoo, RESCo Portal, upload wizard (ZIP or CSV plus PDF).
- SFTP: the portal collects from an SFTP server that CMS-RES writes to. Fill the SFTP settings under RESCo Portal settings (host, port, user, private key, host-key fingerprint, root folder). The POC VM does not host that SFTP server; ask CMS-RES for theirs, or add one later.

## Later: staging and tuning
The scripts in `deploy/wave0` (production tuning, a staging copy, status) are renamed for RESCo but not yet exercised on a live server. Run them after the POC works.
