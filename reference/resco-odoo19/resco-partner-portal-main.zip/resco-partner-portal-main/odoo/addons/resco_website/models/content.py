from odoo import api, fields, models, _
from odoo.exceptions import UserError


class RescoContentVersion(models.Model):
    """The content of a blog post as it was before an edit (version history with restore)."""
    _name = 'resco.content.version'
    _description = 'Content Version'
    _order = 'id desc'

    post_id = fields.Many2one('blog.post', required=True, index=True, ondelete='cascade')
    title = fields.Char(readonly=True)
    content = fields.Html(readonly=True, sanitize=False)
    user_id = fields.Many2one('res.users', 'Edited By', readonly=True)
    create_date = fields.Datetime('Saved On', readonly=True)

    def action_restore(self):
        self.ensure_one()
        if not self.env.user.has_group('resco_portal.group_resco_admin'):
            raise UserError(_('Only an Administrator can restore a version.'))
        self.post_id.write({'content': self.content, 'name': self.title or self.post_id.name})
        return {'type': 'ir.actions.act_window', 'res_model': 'blog.post', 'res_id': self.post_id.id, 'view_mode': 'form'}


class BlogPost(models.Model):
    _inherit = 'blog.post'

    version_ids = fields.One2many('resco.content.version', 'post_id', string='Versions')
    version_count = fields.Integer(compute='_compute_version_count')

    @api.depends('version_ids')
    def _compute_version_count(self):
        counts = {p.id: n for p, n in self.env['resco.content.version']._read_group([('post_id', 'in', self.ids)], ['post_id'], ['__count'])}
        for p in self:
            p.version_count = counts.get(p.id, 0)

    def write(self, vals):
        if 'content' in vals or 'name' in vals:
            for p in self:
                if ('content' in vals and (vals['content'] or '') != (p.content or '')) or ('name' in vals and vals['name'] != p.name):
                    self.env['resco.content.version'].sudo().create({
                        'post_id': p.id, 'title': p.name, 'content': p.content, 'user_id': self.env.uid})
        res = super().write(vals)
        if {'content', 'name', 'is_published', 'post_date', 'blog_id'} & set(vals):
            for p in self:
                self.env['resco.event.log'].sudo()._log('content', ref=f'blog.post {p.id}', detail=f"{p.name}: {', '.join(sorted(set(vals) & {'content', 'name', 'is_published', 'post_date', 'blog_id'}))}")
        return res

    @api.model_create_multi
    def create(self, vals_list):
        posts = super().create(vals_list)
        for p in posts:
            self.env['resco.event.log'].sudo()._log('content', ref=f'blog.post {p.id}', detail=f'created: {p.name}')
        return posts

    def action_open_versions(self):
        self.ensure_one()
        return {'type': 'ir.actions.act_window', 'name': _('Version history'), 'res_model': 'resco.content.version',
                'view_mode': 'list,form', 'domain': [('post_id', '=', self.id)]}


class WebsitePage(models.Model):
    _inherit = 'website.page'

    def write(self, vals):
        res = super().write(vals)
        watched = {'name', 'url', 'is_published', 'date_publish', 'arch', 'arch_base'} & set(vals)
        if watched:
            for p in self:
                self.env['resco.event.log'].sudo()._log('content', ref=f'page {p.url}', detail=f"{p.name}: {', '.join(sorted(watched))}")
        return res
