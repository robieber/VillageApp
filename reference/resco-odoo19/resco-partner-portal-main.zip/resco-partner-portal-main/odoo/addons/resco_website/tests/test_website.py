import json
from datetime import timedelta

from odoo import fields
from odoo.tests import HttpCase, tagged

from odoo.addons.resco_portal.tests.common import RescoCase

API = '/api/resco/v1'
HDR = {'Content-Type': 'application/json', 'X-Requested-With': 'RescoPortal'}
PWD = 'Str0ng!Portal#Pw1'


@tagged('post_install', '-at_install', 'resco_website')
class TestWebsiteContent(HttpCase, RescoCase):

    def test_seed_data(self):
        for xmlid in ('blog_energy_bulletin', 'blog_regulatory', 'blog_advisories', 'page_payment_guidelines', 'page_energy_solutions', 'menu_updates'):
            self.assertTrue(self.env.ref(f'resco_website.{xmlid}'), xmlid)
        self.assertEqual(self.url_open('/payment-guidelines').status_code, 200)
        self.assertIn(b'Payment Guidelines', self.url_open('/payment-guidelines').content)

    def test_versions_restore_and_audit(self):
        blog = self.env.ref('resco_website.blog_energy_bulletin')
        post = self.env['blog.post'].create({'name': 'Rates up', 'blog_id': blog.id, 'content': '<p>one</p>', 'is_published': True})
        post.content = '<p>two</p>'
        self.assertEqual(post.version_count, 1)
        post.version_ids.action_restore()
        self.assertIn('one', post.content)
        self.assertTrue(self.env['resco.event.log'].search([('event_type', '=', 'content'), ('ref', '=', f'blog.post {post.id}')]))

    def test_updates_api_hides_unpublished_and_scheduled(self):
        self.user_a.password = PWD
        blog = self.env.ref('resco_website.blog_regulatory')
        Post = self.env['blog.post']
        Post.create({'name': 'Live', 'blog_id': blog.id, 'is_published': True})
        Post.create({'name': 'Draft', 'blog_id': blog.id, 'is_published': False})
        Post.create({'name': 'Later', 'blog_id': blog.id, 'is_published': True, 'post_date': fields.Datetime.now() + timedelta(days=3)})
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': 'a@acme.test', 'password': PWD}), headers=HDR)
        h = dict(HDR, Authorization=f"Bearer {r.json()['token']}")
        data = self.url_open(API + '/updates', headers=h).json()
        self.assertEqual([p['title'] for p in data['posts']], ['Live'])
        self.assertEqual({p['url'] for p in data['pages']}, {'/payment-guidelines', '/energy-solutions'})
