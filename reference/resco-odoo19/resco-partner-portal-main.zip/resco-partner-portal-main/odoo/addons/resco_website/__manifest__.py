{
    'name': 'RESCo Website Content',
    'version': '19.0.0.1.0',
    'summary': 'Energy bulletins, regulatory updates, events, payment guidelines, popups and cookie consent for the Partners Portal site',
    'description': """
RESCo Website Content (Release 2)

* Blogs for the Energy Bulletin, Regulatory Updates (PDF downloads) and Advisories, and the Odoo event calendar with posters
* Payment Guidelines and Energy Solutions pages, editable with the drag-and-drop page editor
* Site menu, redirects and cookie consent bar, all configurable by administrators
* Version history for blog content with one-click restore, and an audit trail of content changes
* /api/resco/v1/updates feeds the latest content to the React account area
""",
    'author': 'RESCo',
    'category': 'Website',
    'license': 'LGPL-3',
    'depends': ['resco_portal', 'website', 'website_blog', 'website_event'],
    'data': [
        'security/ir.model.access.csv',
        'data/groups.xml',
        'data/blogs.xml',
        'data/pages.xml',
        'data/menus.xml',
        'views/content_views.xml',
    ],
    'installable': True,
    'application': False,
}
