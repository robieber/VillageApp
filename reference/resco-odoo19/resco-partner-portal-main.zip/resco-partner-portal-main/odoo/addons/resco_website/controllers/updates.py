from odoo import fields, http
from odoo.http import request

from odoo.addons.resco_portal.controllers.api import _json, endpoint, route


class RescoUpdatesApi(http.Controller):
    """Latest published content for the account area. Anything unpublished or scheduled for later is never returned."""

    @route('/updates', ['GET'])
    @endpoint()
    def updates(self, **kw):
        now = fields.Datetime.now()
        posts = request.env['blog.post'].sudo().search(
            [('is_published', '=', True), ('post_date', '<=', now)], order='post_date desc', limit=40)
        events = request.env['event.event'].sudo().search(
            [('is_published', '=', True), ('date_end', '>=', now)], order='date_begin', limit=20)
        pages = request.env['website.page'].sudo().search(
            [('is_published', '=', True), ('url', 'in', ['/payment-guidelines', '/energy-solutions'])], order='url')
        return _json({
            'posts': [{'id': p.id, 'title': p.name, 'subtitle': p.subtitle or '', 'blog': p.blog_id.name,
                       'blog_id': p.blog_id.id, 'published': fields.Datetime.to_string(p.post_date), 'url': p.website_url} for p in posts],
            'events': [{'id': e.id, 'title': e.name, 'start': fields.Datetime.to_string(e.date_begin),
                        'end': fields.Datetime.to_string(e.date_end), 'location': getattr(e, 'address_inline', '') or '', 'url': e.website_url} for e in events],
            'pages': [{'title': pg.name, 'url': pg.url} for pg in pages],
        })
