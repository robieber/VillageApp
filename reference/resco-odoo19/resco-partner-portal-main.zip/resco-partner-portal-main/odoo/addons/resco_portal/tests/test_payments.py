import base64
import json

from odoo.exceptions import UserError
from odoo.tests import HttpCase, tagged

from .common import RescoCase, bill_files

API = '/api/resco/v1'
HDR = {'Content-Type': 'application/json', 'X-Requested-With': 'RescoPortal'}
PWD = 'Str0ng!Portal#Pw1'
PNG = b'\x89PNG\r\n\x1a\n' + b'0' * 32


def b64(raw):
    return base64.b64encode(raw).decode()


@tagged('post_install', '-at_install', 'resco_portal')
class TestPayments(HttpCase, RescoCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        for u in (cls.user_a, cls.user_a2, cls.user_b):
            u.password = PWD
        files = bill_files(('CS-1', 2026, 9, 'B1'))
        cls.env['resco.upload.batch'].load('manual', files, overwrite=True, source_name='t')
        cls.bill1 = cls.env['resco.bill'].search([('account_id', '=', cls.acc1.id)], limit=1)

    def _login(self, email):
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': email, 'password': PWD}), headers=HDR)
        return r.json()['token']

    def _post(self, token, body):
        return self.url_open(API + '/payments', data=json.dumps(body),
                             headers=dict(HDR, Authorization=f'Bearer {token}'))

    def _body(self, **over):
        body = {'payment_date': str(self.env.cr.now().date()), 'bank_name': 'BDO', 'payment_mode': 'bank_transfer',
                'amount_paid': '1000.00',
                'lines': [{'account_id': self.acc1.id, 'bill_id': self.bill1.id, 'amount': '600.00'},
                          {'account_id': self.acc2.id, 'amount': '400.00'}],
                'files': [{'name': 'receipt.png', 'data': b64(PNG)}]}
        body.update(over)
        return body

    def test_submit_split_payment_and_history(self):
        t = self._login('a@acme.test')
        r = self._post(t, self._body())
        self.assertEqual(r.status_code, 201, r.text)
        data = r.json()
        self.assertEqual(data['status'], 'for_validation')
        self.assertEqual(len(data['lines']), 2)
        self.assertTrue(data['reference'].startswith('PAY/'))
        history = self.url_open(API + '/payments', headers={'Authorization': f'Bearer {t}'}).json()
        self.assertEqual([h['reference'] for h in history], [data['reference']])
        # the bill shows a pending payment, and its status is untouched
        bills = self.url_open(API + '/bills', headers={'Authorization': f'Bearer {t}'}).json()
        self.assertTrue([b for b in bills if b['id'] == self.bill1.id][0]['payment_pending'])
        self.assertEqual(self.bill1.payment_status, 'unpaid')
        # the proof downloads
        f = self.url_open(f"{API}/payments/{data['id']}/file/{data['files'][0]['id']}", headers={'Authorization': f'Bearer {t}'})
        self.assertEqual(f.content, PNG)

    def test_validation_rules(self):
        t = self._login('a@acme.test')
        for over, text in [
            ({'amount_paid': '999.00'}, 'add up'),
            ({'payment_mode': 'barter'}, 'mode of payment'),
            ({'files': []}, 'Attach the proof'),
            ({'files': [{'name': 'x.png', 'data': b64(b'<script>alert(1)</script>')}]}, 'not a PNG'),
            ({'lines': [{'account_id': self.acc3.id, 'amount': '1000.00'}]}, 'one of your accounts'),
        ]:
            r = self._post(t, self._body(**over))
            self.assertEqual(r.status_code, 400, (over, r.text))
            self.assertIn(text, r.json()['error']['message'])
        self.assertEqual(self.env['resco.payment.submission'].search_count([]), 0)

    def test_viewer_cannot_submit(self):
        t = self._login('a2@acme.test')
        self.assertEqual(self._post(t, self._body(lines=[{'account_id': self.acc2.id, 'amount': '1000.00'}])).status_code, 403)

    def test_isolation_between_customers(self):
        ta, tb = self._login('a@acme.test'), self._login('b@beta.test')
        sub = self._post(ta, self._body()).json()
        self.assertEqual(self.url_open(API + '/payments', headers={'Authorization': f'Bearer {tb}'}).json(), [])
        self.assertEqual(self.url_open(f"{API}/payments/{sub['id']}", headers={'Authorization': f'Bearer {tb}'}).status_code, 404)
        self.assertEqual(self.url_open(f"{API}/payments/{sub['id']}/file/{sub['files'][0]['id']}",
                                       headers={'Authorization': f'Bearer {tb}'}).status_code, 404)
        # a colleague who only sees account 2 gets only their line
        t2 = self._login('a2@acme.test')
        seen = self.url_open(API + '/payments', headers={'Authorization': f'Bearer {t2}'}).json()
        self.assertEqual([[l['csin'] for l in s['lines']] for s in seen], [['CS-2']])
        self.assertTrue(seen[0]['partial_view'])

    def test_staff_decision(self):
        t = self._login('a@acme.test')
        sub = self.env['resco.payment.submission'].browse(self._post(t, self._body()).json()['id'])
        billing = self.env['res.users'].create({
            'login': 'bill@resco.test', 'name': 'Biller',
            'group_ids': [(6, 0, [self.env.ref('resco_portal.group_resco_billing').id])]})
        with self.assertRaises(UserError):
            sub.with_user(billing).action_reject()          # a reason is required
        sub.with_user(billing).remarks = 'Receipt is unreadable'
        sub.with_user(billing).action_reject()
        self.assertEqual(sub.state, 'rejected')
        with self.assertRaises(UserError):
            sub.with_user(billing).action_confirm()         # already decided
        seen = self.url_open(API + '/payments', headers={'Authorization': f'Bearer {t}'}).json()[0]
        self.assertEqual((seen['status'], seen['remarks']), ('rejected', 'Receipt is unreadable'))
        # the bill's payment status still comes only from CMS-RES
        self.assertEqual(self.bill1.payment_status, 'unpaid')
        self.assertTrue(self.env['resco.event.log'].search([('event_type', '=', 'approval'), ('ref', '=', sub.name)]))
