import json

from odoo.tests import HttpCase, tagged

from .common import PDF, RescoCase, bill_files, hourly_file

API = '/api/resco/v1'
HDR = {'Content-Type': 'application/json', 'X-Requested-With': 'RescoPortal'}
PWD = 'Str0ng!Portal#Pw1'


@tagged('post_install', '-at_install', 'resco_portal')
class TestApi(HttpCase, RescoCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        for u in (cls.user_a, cls.user_a2, cls.user_b):
            u.password = PWD
        files = bill_files(('CS-1', 2026, 9, 'B1'))
        for spec in (('CS-2', 2026, 9, 'B2'), ('CS-3', 2026, 9, 'B3')):
            extra = bill_files(spec)
            files.update({k: v for k, v in extra.items() if k.endswith('.pdf')})
            for name in ('MPWR_BILL_HDR_202609.csv', 'MPWR_BILL_COMP_202609.csv'):
                files[name] += extra[name].split(b'\n', 1)[1]
        files.update(hourly_file('CS-1,2026-09-01T00:00:00+08:00,10,12', 'CS-1,2026-09-01T01:00:00+08:00,5,8',
                                 'CS-1,2026-09-02T00:00:00+08:00,3,4', 'CS-3,2026-09-01T00:00:00+08:00,99,99'))
        cls.env['resco.upload.batch'].load('manual', files, overwrite=True, source_name='t')

    def _login(self, email):
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': email, 'password': PWD}), headers=HDR)
        self.assertEqual(r.status_code, 200, r.text)
        return r.json()['token']

    def _get(self, path, token):
        return self.url_open(API + path, headers={'Authorization': f'Bearer {token}'})

    def test_login_accounts_bills(self):
        t = self._login('a@acme.test')
        accs = self._get('/accounts', t).json()
        self.assertEqual(sorted(a['csin'] for a in accs), ['CS-1', 'CS-2'])
        self.assertEqual(self._get('/accounts?q=mill 2', t).json()[0]['csin'], 'CS-2')
        bills = self._get('/bills', t).json()
        self.assertEqual(sorted(b['bill_number'] for b in bills), ['B1', 'B2'])
        self.assertEqual(self._get('/bills?account_id=%s' % self.acc2.id, t).json()[0]['bill_number'], 'B2')

    def test_cross_customer_isolation(self):
        ta = self._login('a@acme.test')
        tb = self._login('b@beta.test')
        beta_bill = self._get('/bills', tb).json()[0]
        self.assertEqual(self._get(f"/bills/{beta_bill['id']}", ta).status_code, 404)
        self.assertEqual(self._get(f"/bills/{beta_bill['id']}/pdf", ta).status_code, 404)
        self.assertEqual(self._get(f'/accounts/{self.acc3.id}', ta).status_code, 404)
        # asking for another company's account in a chart returns nothing for it
        h = self._get(f'/billing-history?account_id={self.acc3.id}', ta).json()
        self.assertEqual(h['periods'], [])

    def test_user_with_one_account_cannot_see_the_other(self):
        t = self._login('a2@acme.test')
        self.assertEqual([a['csin'] for a in self._get('/accounts', t).json()], ['CS-2'])
        b1 = self.env['resco.bill'].search([('csin', '=', 'CS-1')])
        self.assertEqual(self._get(f'/bills/{b1.id}', t).status_code, 404)

    def test_pdf_download_is_logged(self):
        t = self._login('a@acme.test')
        b = self.env['resco.bill'].search([('csin', '=', 'CS-1')])
        r = self._get(f'/bills/{b.id}/pdf', t)
        self.assertEqual((r.status_code, r.headers['Content-Type']), (200, 'application/pdf'))
        self.assertEqual(r.content, PDF)
        self.assertTrue(self.env['resco.event.log'].search([('event_type', '=', 'download'), ('ref', '=', 'B1')]))

    def test_charts(self):
        t = self._login('a@acme.test')
        h = self._get('/billing-history?months=3', t).json()
        self.assertEqual(h['periods'][-1]['period'], '2026-09')
        self.assertEqual(h['periods'][-1]['values']['Generation'], 1400.0)   # CS-1 + CS-2 stacked
        y = self._get('/energy/yearly?year=2026', t).json()
        self.assertEqual(y['months'][8], {'month': 9, 'energy_kwh': 10000.0, 'meq_kwh': 9600.0})
        d = self._get('/energy/daily?year=2026&month=9', t).json()
        self.assertEqual(d['days'][0], {'day': 1, 'kwh': 15.0, 'peak_kw': 12.0})
        self.assertEqual(d['days'][1]['kwh'], 3.0)
        hr = self._get('/energy/hourly?date=2026-09-01', t).json()
        self.assertEqual((hr['hours'][0]['kwh'], hr['hours'][1]['kw']), (10.0, 8.0))
        # Beta's reading of 99 kWh never shows for Acme
        self.assertEqual(sum(x['kwh'] for x in d['days']), 18.0)
        self.assertEqual(self._get('/energy/hourly?date=bad', t).status_code, 400)

    def test_company_users_only_for_customer_admin(self):
        ta = self._login('a@acme.test')
        users = self._get('/company/users', ta).json()
        self.assertEqual(sorted(u['email'] for u in users), ['a2@acme.test', 'a@acme.test'])
        self.assertEqual(self._get('/company/users', self._login('a2@acme.test')).status_code, 403)

    def test_login_rules(self):
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': 'a@acme.test', 'password': 'wrong'}), headers=HDR)
        self.assertEqual(r.status_code, 403)
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': 'a@acme.test', 'password': PWD}),
                          headers={'Content-Type': 'application/json'})
        self.assertEqual(r.status_code, 403)            # missing CSRF header
        staff = self.env['res.users'].create({'name': 'Staff', 'login': 'staff@resco.test', 'password': PWD})
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': 'staff@resco.test', 'password': PWD}), headers=HDR)
        self.assertEqual(r.status_code, 403)
        self.assertTrue(staff)

    def test_user_without_accounts_cannot_sign_in(self):
        u = self._portal_user('none@acme.test', self.company_a, 'viewer')
        u.password = PWD
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': 'none@acme.test', 'password': PWD}), headers=HDR)
        self.assertEqual(r.json()['error']['code'], 'no_accounts')

    def test_password_policy_enforced(self):
        t = self._login('a@acme.test')
        r = self.url_open(API + '/me/password', data=json.dumps({'old_password': PWD, 'new_password': 'weak'}),
                          headers=dict(HDR, Authorization=f'Bearer {t}'))
        self.assertEqual(r.status_code, 400)

    def test_profile_update_and_company_rules(self):
        ta = self._login('a@acme.test')
        r = self.url_open(API + '/me', method='PATCH', data=json.dumps({'designation': 'Plant Manager', 'mobile': '0917 000 0000'}),
                          headers=dict(HDR, Authorization=f'Bearer {ta}'))
        self.assertEqual(r.json()['designation'], 'Plant Manager')
        tv = self._login('a2@acme.test')
        r = self.url_open(API + '/me', method='PATCH', data=json.dumps({'company_website': 'https://x.test'}),
                          headers=dict(HDR, Authorization=f'Bearer {tv}'))
        self.assertEqual(r.status_code, 403)
