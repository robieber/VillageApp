import json

from odoo.tests import TransactionCase, tagged


@tagged('post_install', '-at_install', 'resco_portal')
class TestAuditLog(TransactionCase):

    def test_event_is_also_written_to_the_application_log(self):
        with self.assertLogs('resco.audit', level='INFO') as cm:
            self.env['resco.event.log']._log('login_failed', login='x@example.com', detail='bad credentials', ip='203.0.113.9')
        line = cm.records[0].getMessage()
        self.assertTrue(line.startswith('AUDIT '))
        data = json.loads(line[len('AUDIT '):])
        self.assertEqual((data['event'], data['user'], data['ip']), ('login_failed', 'x@example.com', '203.0.113.9'))
        self.assertNotIn('password', line.lower())
