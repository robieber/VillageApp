import base64

from odoo.tests import tagged

from .common import PDF, RescoCase, bill_files, hourly_file, pay_file


@tagged('post_install', '-at_install', 'resco_portal')
class TestLoader(RescoCase):

    def load(self, files, overwrite=True, channel='manual'):
        return self.env['resco.upload.batch'].load(channel, files, overwrite=overwrite, source_name='t')

    def test_load_new_bill_with_components(self):
        batch = self.load(bill_files(('CS-1', 2026, 9, 'B1')))
        self.assertEqual((batch.state, batch.n_loaded, batch.n_rejected), ('done', 1, 0))
        bill = self.env['resco.bill'].search([('csin', '=', 'CS-1')])
        self.assertEqual((bill.year, bill.month, bill.version, bill.payment_status), (2026, 9, 1, 'unpaid'))
        self.assertEqual(bill.bill_key, 'CS-1-202609-B1')
        self.assertEqual(sorted(bill.line_ids.mapped('code')), ['GEN', 'TRANS'])
        self.assertEqual((bill.energy_kwh, bill.meq_kwh, bill.vat_amount), (5000.0, 4800.0, 120.0))
        self.assertEqual(base64.b64decode(bill.pdf), PDF)
        self.assertTrue(self.env['resco.event.log'].search([('event_type', '=', 'bill_loaded'), ('ref', '=', 'B1')]))
        self.assertTrue(self.env['ir.attachment'].search([('res_model', '=', 'resco.upload.batch'), ('res_id', '=', batch.id)]))

    def test_reload_replaces_and_archives_old_version(self):
        self.load(bill_files(('CS-1', 2026, 9, 'B1')))
        batch = self.load(bill_files(('CS-1', 2026, 9, 'B1R', {'status': 'PAID', 'revised': 'Y', 'supersedes': 'CS-1-202609-B1',
                                                               'pdf_bytes': PDF + b'2'})))
        self.assertEqual((batch.n_loaded, batch.n_replaced), (0, 1))
        active = self.env['resco.bill'].search([('csin', '=', 'CS-1')])
        self.assertEqual((active.bill_number, active.version, active.payment_status), ('B1R', 2, 'paid'))
        old = self.env['resco.bill'].with_context(active_test=False).search([('csin', '=', 'CS-1'), ('active', '=', False)])
        self.assertEqual((old.bill_number, old.version), ('B1', 1))
        self.assertEqual(active.replaces_id, old)
        self.assertTrue(old.pdf and old.line_ids.with_context(active_test=False))
        lines = self.env['resco.bill.line'].search([('account_id', '=', self.acc1.id)])
        self.assertEqual(sum(lines.mapped('amount')), 1000.0)      # only the active version feeds the charts

    def test_replace_notifies_nobody_but_new_bill_does(self):
        Mail = self.env['mail.mail']
        before = Mail.search_count([])
        self.load(bill_files(('CS-1', 2026, 9, 'B1')))
        after_new = Mail.search_count([])
        self.assertEqual(after_new - before, 1)
        self.load(bill_files(('CS-1', 2026, 9, 'B1R')))
        self.assertEqual(Mail.search_count([]), after_new)

    def test_unconfirmed_overwrite_is_skipped(self):
        self.load(bill_files(('CS-1', 2026, 9, 'B1')))
        batch = self.load(bill_files(('CS-1', 2026, 9, 'B9')), overwrite=False)
        self.assertEqual((batch.n_skipped, batch.n_replaced, batch.state), (1, 0, 'failed'))
        self.assertEqual(self.env['resco.bill'].search([('csin', '=', 'CS-1')]).bill_number, 'B1')

    def test_bad_bill_does_not_block_good_one(self):
        a = bill_files(('CS-1', 2026, 9, 'B1'))
        b = bill_files(('CS-2', 2026, 9, 'B2', {'no_pdf': True}))
        files = {k: a[k] for k in a if k.endswith('.pdf')}
        hdr = a['MPWR_BILL_HDR_202609.csv'] + b['MPWR_BILL_HDR_202609.csv'].split(b'\n', 1)[1]
        comp = a['MPWR_BILL_COMP_202609.csv'] + b['MPWR_BILL_COMP_202609.csv'].split(b'\n', 1)[1]
        files.update({'MPWR_BILL_HDR_202609.csv': hdr, 'MPWR_BILL_COMP_202609.csv': comp})
        batch = self.load(files)
        self.assertEqual((batch.state, batch.n_loaded, batch.n_rejected), ('partial', 1, 1))
        self.assertFalse(self.env['resco.bill'].search([('csin', '=', 'CS-2')]))

    def test_non_pdf_content_rejected(self):
        batch = self.load(bill_files(('CS-1', 2026, 9, 'B1', {'pdf_bytes': b'<html>not a pdf</html>'})))
        self.assertEqual(batch.n_loaded, 0)
        self.assertTrue(batch.result_ids.filtered(lambda r: r.status == 'rejected'))

    def test_unbalanced_total_rejected(self):
        batch = self.load(bill_files(('CS-1', 2026, 9, 'B1', {'total': '999.00'})))
        self.assertEqual((batch.n_loaded, batch.state), (0, 'failed'))

    def test_payment_status_feed_updates_and_ignores_stale(self):
        self.load(bill_files(('CS-1', 2026, 9, 'B1')))
        key = 'CS-1-202609-B1'
        b = self.load(pay_file(f'{key},PARTIALLY_PAID,500.00,620.00,2026-10-01,2026-10-01T09:00:00+08:00'))
        bill = self.env['resco.bill'].search([('csin', '=', 'CS-1')])
        self.assertEqual((b.n_payments, bill.payment_status, bill.amount_paid, bill.outstanding_balance), (1, 'partial', 500.0, 620.0))
        b = self.load(pay_file(f'{key},UNPAID,0,1120.00,,2026-09-20T09:00:00+08:00'))     # older than what we hold
        self.assertEqual((b.n_payments, b.n_skipped, bill.payment_status), (0, 1, 'partial'))
        self.load(pay_file(f'{key},OVERDUE,500.00,620.00,2026-10-01,2026-11-20T09:00:00+08:00'))
        self.assertEqual(bill.payment_status, 'overdue')
        b = self.load(pay_file('NOPE,PAID,1,0,,2026-10-05T09:00:00+08:00'))
        self.assertEqual(b.n_payments, 0)

    def test_hourly_energy_upserts(self):
        b = self.load(hourly_file('CS-1,2026-09-01T00:00:00+08:00,10.5,12', 'CS-1,2026-09-01T01:00:00+08:00,9,'))
        self.assertEqual((b.n_intervals, b.state), (2, 'done'))
        first = self.env['resco.energy.interval'].search([('account_id', '=', self.acc1.id)], order='interval_start')
        self.assertEqual((first[0].kwh, first[0].kw_demand, str(first[0].interval_start)), (10.5, 12.0, '2026-08-31 16:00:00'))
        self.load(hourly_file('CS-1,2026-09-01T00:00:00+08:00,11,13'))      # corrected reading replaces, no duplicate
        rows = self.env['resco.energy.interval'].search([('account_id', '=', self.acc1.id)], order='interval_start')
        self.assertEqual((len(rows), rows[0].kwh), (2, 11.0))

    def test_preview_writes_nothing(self):
        self.load(bill_files(('CS-1', 2026, 9, 'B1')))
        n = self.env['resco.upload.batch'].search_count([])
        files = bill_files(('CS-1', 2026, 9, 'B2'), ('CS-2', 2026, 9, 'B3'))
        files.update(hourly_file('CS-1,2026-09-01T00:00:00+08:00,1,'))
        pv = self.env['resco.upload.batch'].preview(files)
        self.assertEqual((len(pv['new']), len(pv['replace']), pv['intervals']), (1, 1, 1))
        self.assertEqual(self.env['resco.upload.batch'].search_count([]), n)
        self.assertFalse(self.env['resco.energy.interval'].search_count([]))

    def test_manual_wizard_two_steps(self):
        files = bill_files(('CS-1', 2026, 9, 'B1'))
        atts = self.env['ir.attachment'].create([{'name': n, 'datas': base64.b64encode(d)} for n, d in files.items()])
        w = self.env['resco.bill.upload.wizard'].create({'file_ids': [(6, 0, atts.ids)]})
        w.action_check()
        self.assertEqual((w.state, w.n_new, w.n_replace), ('confirm', 1, 0))
        self.assertFalse(self.env['resco.bill'].search([('csin', '=', 'CS-1')]))
        w.action_load()
        self.assertTrue(self.env['resco.bill'].search([('csin', '=', 'CS-1')]))
        files2 = bill_files(('CS-1', 2026, 9, 'B2'))
        atts2 = self.env['ir.attachment'].create([{'name': n, 'datas': base64.b64encode(d)} for n, d in files2.items()])
        w2 = self.env['resco.bill.upload.wizard'].create({'file_ids': [(6, 0, atts2.ids)]})
        w2.action_check()
        self.assertEqual(w2.n_replace, 1)
        self.assertIn('will be replaced', w2.preview_html)

    def test_only_one_active_bill_per_account_month(self):
        from odoo.tools import mute_logger
        self.load(bill_files(('CS-1', 2026, 9, 'B1')))
        with mute_logger('odoo.sql_db'), self.assertRaises(Exception):
            with self.env.cr.savepoint():
                self.env['resco.bill'].create({'account_id': self.acc1.id, 'year': 2026, 'month': 9, 'bill_number': 'DUP',
                                               'due_date': '2026-10-15', 'total_amount': 1})


ACCT_HEAD = ('CSIN,ACCOUNT_NAME,PARENT_COMPANY_ID,PARENT_COMPANY_NAME,SERVICE_ADDRESS,PRICING_PRODUCT,CONTRACTED_CAPACITY_KW,'
             'MEQ_KWH,CONTRACT_START,CONTRACT_END,SAM_NAME,SAM_EMAIL,PRIMARY_CONTACT_NAME,PRIMARY_CONTACT_EMAIL,'
             'PRIMARY_CONTACT_MOBILE,ACCOUNT_STATUS')


@tagged('post_install', '-at_install', 'resco_portal')
class TestAccountLoader(RescoCase):

    def acct_file(self, *rows):
        return {'MPWR_ACCOUNT_SAMPLE.csv': (ACCT_HEAD + '\n' + '\n'.join(rows) + '\n').encode()}

    def test_accounts_company_and_primary_contact_are_created(self):
        files = self.acct_file(
            'CS-77,Seven Mall,PC7,Seven Holdings,Pasig,Load Factor,3500,1200,2024-01-26,2027-01-25,Sam One,sam@example.com,'
            'Ana Cruz,ana@seven.test,0917,Active',
            'CS-78,Seven Annex,PC7,Seven Holdings,Pasig,Load Factor,900,300,2024-01-26,2027-01-25,Sam One,sam@example.com,'
            'Ben Cruz,ben@seven.test,0918,Active')
        batch = self.env['resco.upload.batch'].load('manual', files, overwrite=True, initial_password='Str0ng-Pass-123!')
        self.assertEqual((batch.state, batch.n_accounts), ('done', 2))
        a = self.env['resco.account'].search([('csin', '=', 'CS-77')])
        b = self.env['resco.account'].search([('csin', '=', 'CS-78')])
        self.assertEqual(a.partner_id, b.partner_id)                         # one company for both accounts
        self.assertEqual((a.partner_id.name, a.partner_id.ref, a.meq_kwh, a.sam_name), ('Seven Holdings', 'PC7', 1200.0, 'Sam One'))
        ana = self.env['res.users'].search([('login', '=', 'ana@seven.test')])
        self.assertEqual((ana.resco_company_role, ana.share, ana.resco_account_count), ('admin', True, 1))
        self.assertEqual(self.env['resco.account.access'].search([('user_id', '=', ana.id)]).account_id, a)

    def test_reload_updates_instead_of_duplicating_and_can_archive(self):
        row = 'CS-77,Seven Mall,PC7,Seven Holdings,Pasig,Load Factor,3500,1200,,,Sam One,,Ana Cruz,ana@seven.test,0917,%s'
        self.env['resco.upload.batch'].load('manual', self.acct_file(row % 'Active'), overwrite=True)
        batch = self.env['resco.upload.batch'].load('manual', self.acct_file(row % 'Inactive'), overwrite=True)
        accounts = self.env['resco.account'].with_context(active_test=False).search([('csin', '=', 'CS-77')])
        self.assertEqual((len(accounts), accounts.active, batch.n_accounts), (1, False, 1))
        self.assertEqual(self.env['res.users'].search_count([('login', '=', 'ana@seven.test')]), 1)

    def test_accounts_and_their_bills_in_one_batch(self):
        files = self.acct_file('CS-9,Nine Plant,PC9,Nine Co,Laguna,Fixed,500,100,,,,,Pia,pia@nine.test,,Active')
        files.update(bill_files(('CS-9', 2026, 9, 'B9')))
        # the helper only knows three account names; the account name in the account file is what Odoo will hold
        files['MPWR_BILL_HDR_202609.csv'] = files['MPWR_BILL_HDR_202609.csv'].replace(b'Acme Mill 1', b'Nine Plant')
        pv = self.env['resco.upload.batch'].preview(files)
        self.assertEqual((pv['accounts'], len(pv['new'])), (1, 1))
