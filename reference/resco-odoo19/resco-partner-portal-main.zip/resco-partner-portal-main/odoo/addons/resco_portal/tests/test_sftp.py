from odoo.tests import tagged

from ..lib import sftp_inbox
from .common import RescoCase, bill_files


class FakeTransport(sftp_inbox.Transport):
    def __init__(self, files):
        self.files = dict(files)

    def isdir(self, path):
        p = path.rstrip('/') + '/'
        return any(f.startswith(p) for f in self.files)

    def listdir(self, path):
        p = path.rstrip('/') + '/'
        return sorted({f[len(p):].split('/')[0] for f in self.files if f.startswith(p)})

    def read(self, path):
        return self.files[path]

    def write(self, path, data):
        self.files[path] = data

    def move(self, src, dst):
        self.files[dst] = self.files.pop(src)

    def makedirs(self, path):
        pass

    def close(self):
        pass


def inbox(batch, files, done=True):
    out = {f'/inbound/{batch}/{n}': d for n, d in files.items()}
    if done:
        out[f'/inbound/{batch}/{batch}.done'] = b''
    return out


@tagged('post_install', '-at_install', 'resco_portal')
class TestSftp(RescoCase):

    def test_poll_loads_overwrites_and_archives(self):
        t = FakeTransport(inbox('B1', bill_files(('CS-1', 2026, 9, 'B1'))))
        self.assertEqual(self.env['resco.upload.batch']._cron_poll_sftp(transport=t), 1)
        self.assertEqual(self.env['resco.bill'].search([('csin', '=', 'CS-1')]).bill_number, 'B1')
        self.assertIn('/processed/B1/result.txt', t.files)
        self.assertFalse([p for p in t.files if p.startswith('/inbound/')])
        # CMS-RES sends a corrected bill for the same month: SFTP overwrites and keeps the old version
        t2 = FakeTransport(inbox('B2', bill_files(('CS-1', 2026, 9, 'B1R', {'revised': 'Y', 'supersedes': 'CS-1-202609-B1'}))))
        self.env['resco.upload.batch']._cron_poll_sftp(transport=t2)
        self.assertEqual(self.env['resco.bill'].search([('csin', '=', 'CS-1')]).bill_number, 'B1R')
        self.assertEqual(self.env['resco.bill'].with_context(active_test=False).search_count([('csin', '=', 'CS-1')]), 2)

    def test_batch_without_marker_is_left_alone(self):
        t = FakeTransport(inbox('B1', bill_files(('CS-1', 2026, 9, 'B1')), done=False))
        self.assertEqual(self.env['resco.upload.batch']._cron_poll_sftp(transport=t), 0)
        self.assertFalse(self.env['resco.bill'].search([('csin', '=', 'CS-1')]))

    def test_failed_batch_goes_to_error_folder(self):
        t = FakeTransport(inbox('B1', bill_files(('CS-1', 2026, 9, 'B1', {'total': '1.00'}))))
        self.env['resco.upload.batch']._cron_poll_sftp(transport=t)
        self.assertTrue([p for p in t.files if p.startswith('/error/B1/')])

    def test_disabled_by_default(self):
        self.assertEqual(self.env['resco.upload.batch']._cron_poll_sftp(), 0)
