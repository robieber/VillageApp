import io
from odoo.tests import TransactionCase

HDR = ('BILL_KEY,CSIN,ACCOUNT_NAME,SERVICE_ADDRESS,BILL_NUMBER,BILL_MONTH,BILL_YEAR,BILL_DATE,BILLING_PERIOD_FROM,'
       'BILLING_PERIOD_TO,DUE_DATE,PRICING_PRODUCT,CONTRACTED_CAPACITY_KW,ENERGY_KWH,MEQ_KWH,CURRENT_CHARGES,VAT_AMOUNT,'
       'PREVIOUS_BALANCE,ADJUSTMENTS,TOTAL_AMOUNT_DUE,CURRENCY,PAYMENT_STATUS,PDF_FILE_NAME,IS_REVISED,'
       'SUPERSEDES_BILL_KEY,SOURCE_SYSTEM,EXTRACT_BATCH_ID,EXTRACT_TIMESTAMP')
COMP = 'BILL_KEY,COMPONENT_CODE,COMPONENT_NAME,QUANTITY,UOM,RATE,AMOUNT,SORT_ORDER'
PAY = 'BILL_KEY,PAYMENT_STATUS,AMOUNT_PAID,OUTSTANDING_BALANCE,LAST_PAYMENT_DATE,STATUS_AS_OF'
HRLY = 'CSIN,INTERVAL_START,KWH,KW_DEMAND'
PDF = b'%PDF-1.7\n%test\n'
NAMES = {'CS-1': 'Acme Mill 1', 'CS-2': 'Acme Mill 2', 'CS-3': 'Beta Plant', 'CS-9': 'Acme Mill 1'}


def _csv(head, rows):
    return (head + '\n' + '\n'.join(rows) + '\n').encode()


def bill_files(*specs, **kw):
    """Files of one batch. Each spec: (csin, year, month, bill number[, dict of overrides]).
    Generation 700 + Transmission 300 = current charges 1000; VAT 120; total 1120 unless overridden."""
    hdr, comp, files = [], [], {}
    for spec in specs:
        csin, y, m, num = spec[:4]
        o = spec[4] if len(spec) > 4 else {}
        key = o.get('key', f'{csin}-{y}{m:02d}-{num}')
        pdf = o.get('pdf', f'{y}{m:02d}-{csin}.pdf')
        status = o.get('status', 'UNPAID')
        hdr.append(','.join(str(x) for x in [
            key, csin, NAMES[csin], 'Laguna', num, m, y, f'{y}-{m:02d}-28', f'{y}-{m:02d}-01', f'{y}-{m:02d}-30',
            o.get('due', f'{y + (m == 12)}-{m % 12 + 1:02d}-15'), 'Fixed', 500, o.get('kwh', 5000), 4800, 1000, 120, 0, 0,
            o.get('total', '1120.00'), 'PHP', status, pdf, o.get('revised', 'N'), o.get('supersedes', ''), 'CMS-RES', 'X1',
            f'{y}-{m:02d}-28T10:00:00+08:00']))
        comp += [f'{key},GEN,Generation,5000,KWH,0.14,{o.get("gen", "700.00")},10', f'{key},TRANS,Transmission,5000,KWH,0.06,300.00,20']
        if not o.get('no_pdf'):
            files[pdf] = o.get('pdf_bytes', PDF)
    files['MPWR_BILL_HDR_202609.csv'] = _csv(HDR, hdr)
    files['MPWR_BILL_COMP_202609.csv'] = _csv(COMP, comp)
    return files


def pay_file(*rows):
    return {'MPWR_PAY_STAT_202610.csv': _csv(PAY, rows)}


def hourly_file(*rows):
    return {'MPWR_ENERGY_HRLY_202609.csv': _csv(HRLY, rows)}


class RescoCase(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company_a = cls.env['res.partner'].create({'name': 'Acme Mills Corp', 'is_company': True})
        cls.company_b = cls.env['res.partner'].create({'name': 'Beta Foods Inc', 'is_company': True})
        Account = cls.env['resco.account']
        cls.acc1 = Account.create({'name': 'Acme Mill 1', 'csin': 'CS-1', 'partner_id': cls.company_a.id,
                                   'contracted_capacity_kw': 500})
        cls.acc2 = Account.create({'name': 'Acme Mill 2', 'csin': 'CS-2', 'partner_id': cls.company_a.id})
        cls.acc3 = Account.create({'name': 'Beta Plant', 'csin': 'CS-3', 'partner_id': cls.company_b.id})
        cls.user_a = cls._portal_user('a@acme.test', cls.company_a, 'admin')
        cls.user_a2 = cls._portal_user('a2@acme.test', cls.company_a, 'viewer')
        cls.user_b = cls._portal_user('b@beta.test', cls.company_b, 'admin')
        Access = cls.env['resco.account.access']
        Access.create([{'user_id': cls.user_a.id, 'account_id': cls.acc1.id},
                       {'user_id': cls.user_a.id, 'account_id': cls.acc2.id},
                       {'user_id': cls.user_a2.id, 'account_id': cls.acc2.id},
                       {'user_id': cls.user_b.id, 'account_id': cls.acc3.id}])

    @classmethod
    def _portal_user(cls, login, company, role):
        partner = cls.env['res.partner'].create({'name': login.split('@')[0], 'email': login, 'parent_id': company.id})
        portal = cls.env.ref('base.group_portal')
        user = cls.env['res.users'].with_context(no_reset_password=True).create({
            'login': login, 'partner_id': partner.id, 'group_ids': [(6, 0, portal.ids)], 'resco_company_role': role})
        return user
