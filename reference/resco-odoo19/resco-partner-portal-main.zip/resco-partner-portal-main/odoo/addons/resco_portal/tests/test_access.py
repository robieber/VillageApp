from odoo.exceptions import ValidationError
from odoo.tests import tagged
from odoo.tools import mute_logger

from .common import RescoCase


@tagged('post_install', '-at_install', 'resco_portal')
class TestAccess(RescoCase):

    def test_user_sees_only_granted_accounts(self):
        self.assertEqual(self.user_a._resco_accounts(), self.acc1 | self.acc2)
        self.assertEqual(self.user_a2._resco_accounts(), self.acc2)
        self.assertEqual(self.user_b._resco_accounts(), self.acc3)

    def test_cannot_grant_account_of_another_company(self):
        with self.assertRaises(ValidationError):
            self.env['resco.account.access'].create({'user_id': self.user_b.id, 'account_id': self.acc1.id})

    def test_duplicate_access_rejected(self):
        with mute_logger('odoo.sql_db'), self.assertRaises(Exception):
            with self.env.cr.savepoint():
                self.env['resco.account.access'].create({'user_id': self.user_a.id, 'account_id': self.acc1.id})

    def test_revoked_or_archived_access_hides_account(self):
        self.env['resco.account.access'].search([('user_id', '=', self.user_a2.id)]).active = False
        self.assertFalse(self.user_a2._resco_accounts())
        self.acc1.active = False
        self.assertEqual(self.user_a._resco_accounts(), self.acc2)

    def test_csin_unique_and_search_by_csin(self):
        with mute_logger('odoo.sql_db'), self.assertRaises(Exception):
            with self.env.cr.savepoint():
                self.env['resco.account'].create({'name': 'Dup', 'csin': 'CS-1', 'partner_id': self.company_a.id})
        self.assertEqual(self.env['resco.account'].name_search('CS-3')[0][0], self.acc3.id)

    def test_portal_record_rules(self):
        Bill = self.env['resco.bill']
        for acc, num in ((self.acc2, 'X-2'), (self.acc3, 'X-3')):
            Bill.create({'account_id': acc.id, 'year': 2026, 'month': 9, 'bill_number': num, 'due_date': '2026-10-15',
                         'total_amount': 1})
        seen = Bill.with_user(self.user_a2).search([])
        self.assertEqual(seen.mapped('bill_number'), ['X-2'])
        self.assertEqual(self.env['resco.account'].with_user(self.user_a2).search([]), self.acc2)
