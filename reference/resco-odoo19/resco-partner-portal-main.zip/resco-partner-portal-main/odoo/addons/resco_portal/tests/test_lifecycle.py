from datetime import date, timedelta

from odoo import fields
from odoo.tests import tagged

from .common import RescoCase, bill_files


@tagged('post_install', '-at_install', 'resco_portal')
class TestLifecycle(RescoCase):

    def test_warn_then_deactivate_for_inactivity(self):
        Users = self.env['res.users']
        u = self.user_a2
        u.resco_last_activity = fields.Datetime.now() - timedelta(days=80)   # rule B date is ~10 days away
        u.resco_deactivation_warned_on = False
        warned, deactivated = Users._cron_resco_lifecycle(today=fields.Date.context_today(u))
        self.assertTrue(u.active)
        self.assertEqual(u.resco_deactivation_warned_on, fields.Date.context_today(u))
        self.assertTrue(self.env['resco.event.log'].search([('event_type', '=', 'user_warned'), ('user_id', '=', u.id)]))
        later = fields.Date.context_today(u) + timedelta(days=40)
        Users._cron_resco_lifecycle(today=later)
        self.assertFalse(u.active)
        self.assertTrue(self.env['resco.event.log'].search([('event_type', '=', 'user_deactivated'), ('user_id', '=', u.id)]))

    def test_active_user_with_recent_bill_and_activity_is_untouched(self):
        self.env['resco.upload.batch'].load('manual', bill_files(('CS-2', 2026, 9, 'B1')), overwrite=True, source_name='t')
        self.user_a2.resco_last_activity = fields.Datetime.now()
        self.env['res.users']._cron_resco_lifecycle()
        self.assertTrue(self.user_a2.active)

    def test_due_reminders_sent_once_per_day(self):
        self.env['resco.upload.batch'].load('manual', bill_files(('CS-1', 2026, 9, 'B1', {'due': '2026-10-15'})),
                                            overwrite=True, source_name='t')
        Bill = self.env['resco.bill']
        self.assertEqual(Bill._cron_due_reminders(today=date(2026, 10, 10)), 1)     # 5 days before
        self.assertEqual(Bill._cron_due_reminders(today=date(2026, 10, 10)), 0)     # same day again
        self.assertEqual(Bill._cron_due_reminders(today=date(2026, 10, 12)), 0)     # not a reminder day
        self.assertEqual(Bill._cron_due_reminders(today=date(2026, 10, 16)), 1)     # 1 day after

    def test_unsubscribed_user_gets_no_bill_email(self):
        self.user_a.resco_email_optout = True
        before = self.env['mail.mail'].search_count([])
        self.env['resco.upload.batch'].load('manual', bill_files(('CS-1', 2026, 9, 'B1')), overwrite=True, source_name='t')
        self.assertEqual(self.env['mail.mail'].search_count([]), before)
