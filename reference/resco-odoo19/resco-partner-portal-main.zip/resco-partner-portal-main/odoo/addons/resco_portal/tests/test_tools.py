import base64
import json

from odoo.exceptions import UserError
from odoo.tests import HttpCase, tagged

from .common import RescoCase

API = '/api/resco/v1'
HDR = {'Content-Type': 'application/json', 'X-Requested-With': 'RescoPortal'}
PWD = 'Str0ng!Portal#Pw1'


@tagged('post_install', '-at_install', 'resco_portal')
class TestLibrary(RescoCase):

    def test_versions_and_blocked_types(self):
        folder = self.env['resco.file.folder'].create({'name': 'Advisories'})
        File = self.env['resco.file']
        a = File._store('notice.pdf', b'%PDF-1.4 one', folder)
        b = File._store('notice.pdf', b'%PDF-1.4 two', folder)
        self.assertEqual((b.version, b.replaces_id), (2, a))
        self.assertFalse(a.active)
        with self.assertRaises(UserError):
            File._store('notice.pdf', b'x', folder, overwrite=False)
        with self.assertRaises(UserError):
            File._store('run.exe', b'MZ', folder)
        with self.assertRaises(UserError):
            File._store('empty.pdf', b'', folder)

    def test_wizard_reports_each_file(self):
        att = self.env['ir.attachment'].create([
            {'name': 'ok.txt', 'datas': base64.b64encode(b'hello')}, {'name': 'bad.sh', 'datas': base64.b64encode(b'rm -rf')}])
        w = self.env['resco.file.upload.wizard'].create({'attachment_ids': [(6, 0, att.ids)]})
        w.action_upload()
        self.assertIn('OK    ok.txt', w.result)
        self.assertIn('FAIL', w.result)
        self.assertEqual(self.env['resco.file'].search_count([('name', '=', 'ok.txt')]), 1)


@tagged('post_install', '-at_install', 'resco_portal')
class TestUserImport(RescoCase):

    def _wizard(self, text):
        return self.env['resco.user.import.wizard'].create({'csv_file': base64.b64encode(text.encode()), 'send_invitation': False})

    def test_check_saves_nothing_import_does(self):
        text = f'EMAIL,NAME,ROLE,CSINS\nnew.user@acme.test,New User,billing,{self.acc1.csin};{self.acc2.csin}\nnobody@acme.test,X,viewer,NOPE-1\n'
        w = self._wizard(text)
        w.action_check()
        self.assertEqual((w.n_ok, w.n_problem), (1, 1))
        self.assertFalse(self.env['res.users'].with_context(active_test=False).search([('login', '=', 'new.user@acme.test')]))
        w.action_import()
        u = self.env['res.users'].search([('login', '=', 'new.user@acme.test')])
        self.assertEqual((u.resco_company_role, u.share), ('billing', True))
        self.assertEqual(set(u._resco_accounts().ids), {self.acc1.id, self.acc2.id})
        self.assertEqual(u.partner_id.parent_id, self.acc1.partner_id)

    def test_other_company_and_deactivate(self):
        w = self._wizard(f'EMAIL,CSINS\n{self.user_b.login},{self.acc1.csin}\n')
        w.action_import()
        self.assertEqual(w.n_problem, 1)                                  # belongs to another company
        self.assertFalse(self.acc1 in self.user_b._resco_accounts())
        w = self._wizard(f'EMAIL,ACTION\n{self.user_a2.login},deactivate\n')
        w.action_import()
        self.assertFalse(self.env['res.users'].search([('id', '=', self.user_a2.id)]))
        w = self._wizard(f'EMAIL,CSINS\n{self.user_a.login},{self.acc1.csin};{self.acc3.csin}\n')
        w.action_import()
        self.assertEqual(w.n_problem, 1)                                  # CSINs of two companies


@tagged('post_install', '-at_install', 'resco_portal')
class TestPrivacyAndPopups(HttpCase, RescoCase):

    def _auth(self, email):
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': email, 'password': PWD}), headers=HDR)
        return dict(HDR, Authorization=f"Bearer {r.json()['token']}")

    def test_consent_cycle(self):
        self.user_a.password = PWD
        h = self._auth('a@acme.test')
        n = self.env['resco.privacy.notice'].search([('active', '=', True)])
        self.assertTrue(n)
        me = self.url_open(API + '/me', headers=h).json()
        self.assertTrue(me['privacy_pending'])
        notice = self.url_open(API + '/privacy', headers=h).json()
        self.assertEqual(self.url_open(API + '/privacy/accept', data=json.dumps({'version': notice['version'] + 5}), headers=h).status_code, 400)
        self.assertEqual(self.url_open(API + '/privacy/accept', data=json.dumps({'version': notice['version']}), headers=h).status_code, 200)
        self.assertFalse(self.url_open(API + '/me', headers=h).json()['privacy_pending'])
        # a new version asks again; the published one cannot be edited
        with self.assertRaises(UserError):
            n.body = 'changed'
        new = n.copy({'body': 'New text'})
        new.action_publish()
        self.assertTrue(self.url_open(API + '/me', headers=h).json()['privacy_pending'])
        self.assertEqual(self.env['resco.privacy.consent'].search_count([('user_id', '=', self.user_a.id)]), 1)

    def test_popup_shows_once(self):
        self.user_a.password = PWD
        h = self._auth('a@acme.test')
        self.env['resco.popup'].create({'name': 'Holiday', 'title': 'Office closed', 'body': 'We are closed on Dec 25.\n\nSee you.'})
        shown = self.url_open(API + '/popups', headers=h).json()
        self.assertEqual([p['title'] for p in shown], ['Office closed'])
        self.assertEqual(len(shown[0]['paragraphs']), 2)
        self.url_open(f"{API}/popups/{shown[0]['id']}/dismiss", data=json.dumps({}), headers=h)
        self.assertEqual(self.url_open(API + '/popups', headers=h).json(), [])
