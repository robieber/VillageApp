import base64
import json
from unittest.mock import patch

from odoo.tests import HttpCase, tagged

from .common import RescoCase

API = '/api/resco/v1'
HDR = {'Content-Type': 'application/json', 'X-Requested-With': 'RescoPortal'}
PWD = 'Str0ng!Portal#Pw1'
PNG = b'\x89PNG\r\n\x1a\n' + b'0' * 32


@tagged('post_install', '-at_install', 'resco_portal')
class TestTickets(HttpCase, RescoCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        for u in (cls.user_a, cls.user_a2, cls.user_b):
            u.password = PWD
        cls.staff = cls.env['res.users'].create({
            'login': 'agent@resco.test', 'name': 'Agent', 'email': 'agent@resco.test',
            'group_ids': [(6, 0, [cls.env.ref('resco_portal.group_resco_support').id])]})
        cls.cat = cls.env.ref('resco_portal.ticket_cat_billing')
        cls.cat.default_user_id = cls.staff
        cls.cat_sam = cls.env.ref('resco_portal.ticket_cat_sam')

    def _token(self, email):
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': email, 'password': PWD}), headers=HDR)
        return r.json()['token']

    def _call(self, token, path, body=None):
        h = dict(HDR, Authorization=f'Bearer {token}')
        if body is None:
            return self.url_open(API + path, headers=h)
        return self.url_open(API + path, data=json.dumps(body), headers=h)

    def _new(self, token, **over):
        body = {'account_id': self.acc1.id, 'category_id': self.cat.id, 'subject': 'Wrong rate',
                'description': 'The rate on my September bill looks wrong.',
                'files': [{'name': 'shot.png', 'data': base64.b64encode(PNG).decode()}]}
        body.update(over)
        return self._call(token, '/tickets', body)

    def test_create_route_and_reply_cycle(self):
        t = self._token('a@acme.test')
        r = self._new(t)
        self.assertEqual(r.status_code, 201, r.text)
        data = r.json()
        ticket = self.env['resco.ticket'].browse(data['id'])
        self.assertEqual(ticket.assigned_user_id, self.staff)               # routed by category
        self.assertEqual(data['status'], 'new')
        self.assertEqual(len(data['messages']), 1)
        self.assertEqual(data['messages'][0]['files'][0]['name'], 'shot.png')
        # staff replies in the thread: visible to the customer, status waits for the customer
        ticket.with_user(self.staff).message_post(body='Checking now', message_type='comment', subtype_xmlid='mail.mt_comment')
        ticket.with_user(self.staff).message_post(body='Internal: ask finance', message_type='comment', subtype_xmlid='mail.mt_note')
        got = self._call(t, f"/tickets/{data['id']}").json()
        self.assertEqual([m['text'] for m in got['messages']][-1], 'Checking now')
        self.assertNotIn('Internal', json.dumps(got))
        self.assertEqual(got['status'], 'waiting_customer')
        # customer answers: back to work
        r = self._call(t, f"/tickets/{data['id']}/reply", {'message': 'Thanks, see the PDF'})
        self.assertEqual(r.json()['status'], 'in_progress')
        # closed tickets accept no reply
        ticket.action_close()
        self.assertEqual(self._call(t, f"/tickets/{data['id']}/reply", {'message': 'hello?'}).status_code, 400)

    def test_message_to_account_manager_goes_to_sam(self):
        self.acc1.sam_id = self.staff
        t = self._token('a@acme.test')
        data = self._new(t, category_id=self.cat_sam.id).json()
        ticket = self.env['resco.ticket'].browse(data['id'])
        self.assertEqual(ticket.assigned_user_id, self.staff)
        self.assertEqual(ticket.source, 'sam_message')

    def test_rules_and_isolation(self):
        ta, tb, t2 = self._token('a@acme.test'), self._token('b@beta.test'), self._token('a2@acme.test')
        self.assertEqual(self._new(ta, account_id=self.acc3.id).status_code, 400)           # not their account
        self.assertEqual(self._new(ta, subject=' ').status_code, 400)
        self.assertEqual(self._new(ta, files=[{'name': 'x.png', 'data': base64.b64encode(b'<b>hi</b>').decode()}]).status_code, 400)
        tid = self._new(ta).json()['id']
        self.assertEqual(self._call(tb, f'/tickets/{tid}').status_code, 404)
        self.assertEqual(self._call(tb, '/tickets').json(), [])
        self.assertEqual(self._call(tb, f'/tickets/{tid}/reply', {'message': 'x'}).status_code, 404)
        # a colleague with access to account 1 sees it too
        self.assertEqual([x['id'] for x in self._call(t2, '/tickets').json()], [tid] if self.acc1 in self.user_a2._resco_accounts() else [])
        # attachment of an internal note is never served
        ticket = self.env['resco.ticket'].browse(tid)
        att = self.env['ir.attachment'].create({'name': 'internal.pdf', 'datas': base64.b64encode(b'%PDF-1.4'), 'res_model': 'resco.ticket', 'res_id': tid})
        ticket.message_post(body='note', message_type='comment', subtype_xmlid='mail.mt_note', attachment_ids=att.ids)
        self.assertEqual(self._call(ta, f'/tickets/{tid}/file/{att.id}').status_code, 404)


@tagged('post_install', '-at_install', 'resco_portal')
class TestChat(HttpCase, RescoCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.user_a.password = PWD
        params = cls.env['ir.config_parameter'].sudo()
        params.set_param('resco_portal.ai_enabled', 'True')
        params.set_param('resco_portal.gemini_api_key', 'test-key')
        cls.cat = cls.env.ref('resco_portal.ticket_cat_billing')

    def _fake_gemini(self, script):
        calls = iter(script)

        def post(url, headers, body):
            self.sent = body
            return next(calls)
        return post

    @staticmethod
    def _text(t):
        return 200, {'candidates': [{'content': {'role': 'model', 'parts': [{'text': t}]}}]}

    @staticmethod
    def _call(name, args):
        return 200, {'candidates': [{'content': {'role': 'model', 'parts': [{'functionCall': {'name': name, 'args': args}}]}}]}

    def test_disabled_without_key(self):
        self.env['ir.config_parameter'].sudo().set_param('resco_portal.gemini_api_key', '')
        self.assertFalse(self.env['resco.chat']._available())

    def test_tools_see_only_own_accounts(self):
        from ..models.resco_chat import _Tools
        session = self.env['resco.chat.session'].create({'user_id': self.user_a.id})
        tools = _Tools(self.env, self.user_a, session)
        ids = {a['id'] for a in tools.execute('list_accounts', {})['accounts']}
        self.assertNotIn(self.acc3.id, ids)
        self.assertEqual(tools.execute('list_bills', {'account_id': self.acc3.id}), {'bills': []})
        self.assertEqual(tools.execute('get_bill', {'bill_id': 0}), {'error': 'bill not found'})
        self.assertEqual(tools.execute('does_not_exist', {}), {'error': 'unknown tool'})

    def test_ticket_needs_confirmation_then_is_created(self):
        from ..models.resco_chat import _Tools
        session = self.env['resco.chat.session'].create({'user_id': self.user_a.id})
        self.env['resco.chat.message'].create({'session_id': session.id, 'role': 'user', 'content': 'my bill is wrong'})
        tools = _Tools(self.env, self.user_a, session)
        args = {'subject': 'Bill query', 'description': 'Check September', 'category_id': self.cat.id, 'account_id': self.acc1.id}
        self.assertIn('error', tools.execute('create_support_ticket', dict(args, confirmed=False)))
        self.assertEqual(self.env['resco.ticket'].search_count([]), 0)
        self.assertIn('error', tools.execute('create_support_ticket', dict(args, account_id=self.acc3.id, confirmed=True)))
        out = tools.execute('create_support_ticket', dict(args, confirmed=True))
        self.assertTrue(out['created'])
        t = self.env['resco.ticket'].browse(out['id'])
        self.assertEqual((t.source, t.chat_session_id), ('ai_chat', session))
        self.assertIn('my bill is wrong', t.description)

    def test_reply_runs_tool_loop_and_stores_messages(self):
        session = self.env['resco.chat.session'].create({'user_id': self.user_a.id})
        post = self._fake_gemini([self._call('list_accounts', {}), self._text('You have accounts.')])
        text, tickets = self.env['resco.chat'].reply(self.user_a, session, 'What accounts do I have?', post=post)
        self.assertEqual(text, 'You have accounts.')
        self.assertEqual(session.message_ids.mapped('role'), ['user', 'model'])
        self.assertEqual(session.message_ids[-1].tools_used, 'list_accounts')
        self.assertIn('Acme', self.sent['systemInstruction']['parts'][0]['text'] + str(self.sent['contents']))

    def test_api_flow_and_limits(self):
        r = self.url_open(API + '/auth/login', data=json.dumps({'email': 'a@acme.test', 'password': PWD}), headers=HDR)
        h = dict(HDR, Authorization=f"Bearer {r.json()['token']}")
        self.assertTrue(json.loads(self.url_open(API + '/chat/status', headers=h).content)['enabled'])
        with patch.object(type(self.env['resco.chat']), '_http_post', staticmethod(lambda u, hd, b: self._text('Hi there'))):
            out = self.url_open(API + '/chat', data=json.dumps({'message': 'hello'}), headers=h).json()
            self.assertEqual(out['reply'], 'Hi there')
            too_long = self.url_open(API + '/chat', data=json.dumps({'message': 'x' * 2000}), headers=h)
            self.assertEqual(too_long.status_code, 400)
            # another user's session id is not found
            other = self.env['resco.chat.session'].create({'user_id': self.user_b.id})
            self.assertEqual(self.url_open(API + '/chat', data=json.dumps({'session_id': other.id, 'message': 'hi'}), headers=h).status_code, 404)
            self.env['ir.config_parameter'].sudo().set_param('resco_portal.ai_messages_per_hour', '1')
            self.assertEqual(self.url_open(API + '/chat', data=json.dumps({'session_id': out['session_id'], 'message': 'again'}), headers=h).status_code, 400)
            # hand-over to a person
            t = self.url_open(f"{API}/chat/sessions/{out['session_id']}/ticket",
                              data=json.dumps({'account_id': self.acc1.id, 'category_id': self.cat.id}), headers=h)
            self.assertEqual(t.status_code, 201, t.text)
