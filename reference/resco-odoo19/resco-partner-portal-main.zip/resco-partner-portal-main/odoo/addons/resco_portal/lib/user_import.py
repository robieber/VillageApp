"""CSV batches of portal users (FR-WEB-069). Pure parsing and checking; the wizard applies the rows.

Columns (any order, header names are case-insensitive):
  EMAIL (required), NAME, ROLE (admin | billing | viewer), MOBILE, DESIGNATION, CSINS (separated by ; or |), ACTION (add | update | deactivate)
ACTION defaults to add. add creates the user if missing and grants the listed accounts; update changes details and
replaces nothing, it only adds the listed accounts; deactivate archives the user.
"""
import csv
import io
import re

MAX_ROWS = 500
ROLES = {'admin', 'billing', 'viewer'}
ACTIONS = {'add', 'update', 'deactivate'}
EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
TEMPLATE = 'EMAIL,NAME,ROLE,MOBILE,DESIGNATION,CSINS,ACTION\njuan@example.com,Juan Dela Cruz,billing,+639171234567,Finance Manager,CS-100234;CS-100235,add\n'


def parse(text: str):
    """Returns (rows, errors). rows: list of dicts with keys row, email, name, role, mobile, designation, csins, action.
    errors: list of (row number, message); a row with an error is not in rows."""
    text = (text or '').lstrip('\ufeff')
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        return [], [(0, 'The file is empty.')]
    names = {(h or '').strip().lower(): h for h in reader.fieldnames}
    if 'email' not in names:
        return [], [(0, 'The first row must have an EMAIL column.')]
    rows, errors, seen = [], [], set()
    for i, raw in enumerate(reader, start=2):
        if i - 1 > MAX_ROWS:
            errors.append((i, f'More than {MAX_ROWS} rows. Split the file.'))
            break
        get = lambda k: (raw.get(names[k]) or '').strip() if k in names else ''  # noqa: E731
        if not any((v or '').strip() for v in raw.values() if isinstance(v, str)):
            continue
        email = get('email').lower()
        action = (get('action') or 'add').lower()
        role = (get('role') or 'viewer').lower()
        csins = [c.strip() for c in re.split(r'[;|]', get('csins')) if c.strip()]
        problem = None
        if not EMAIL_RE.match(email):
            problem = 'Not a valid email address.'
        elif email in seen:
            problem = 'This email appears twice in the file.'
        elif action not in ACTIONS:
            problem = f'ACTION must be one of {", ".join(sorted(ACTIONS))}.'
        elif role not in ROLES:
            problem = f'ROLE must be one of {", ".join(sorted(ROLES))}.'
        elif action == 'add' and not csins:
            problem = 'List at least one CSIN so the user can see an account.'
        seen.add(email)
        if problem:
            errors.append((i, f'{email or "(blank)"}: {problem}'))
            continue
        rows.append({'row': i, 'email': email, 'name': get('name'), 'role': role, 'mobile': get('mobile'),
                     'designation': get('designation'), 'csins': csins, 'action': action})
    return rows, errors
