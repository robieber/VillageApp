"""User deactivation and reminder date rules (FR-WEB-066, NOT-002). Pure functions."""
from datetime import date, timedelta

from dateutil.relativedelta import relativedelta

WARNING_DAYS = 14


def deactivation_date(last_bill_date, last_activity_date, created_date=None):
    """Earliest date on which the user should be deactivated, or None if neither rule applies.

    Rule A: 2 months after the last bill released on any of the user's accounts.
    Rule B: 3 months after the last activity (login). A user who never logged in counts from creation.
    The earlier of the two wins.
    """
    candidates = []
    if last_bill_date:
        candidates.append(last_bill_date + relativedelta(months=2))
    base = last_activity_date or created_date
    if base:
        candidates.append(base + relativedelta(months=3))
    return min(candidates) if candidates else None


def deactivation_state(today, dd, warned_on):
    """Return 'deactivate', 'warn' or None."""
    if dd is None:
        return None
    if today >= dd:
        return 'deactivate'
    if today >= dd - timedelta(days=WARNING_DAYS) and not (warned_on and warned_on >= dd - timedelta(days=WARNING_DAYS)):
        return 'warn'
    return None


def parse_offsets(text):
    """'5,1,-1' -> [5, 1, -1]: days before (+) or after (-) the due date. Bad tokens are dropped."""
    out = []
    for tok in (text or '').split(','):
        tok = tok.strip()
        try:
            out.append(int(tok))
        except ValueError:
            continue
    return sorted(set(out), reverse=True)


def reminder_due(today, due_date, offsets):
    """True if today is exactly one of the configured reminder days for this due date."""
    return any(due_date - timedelta(days=o) == today for o in offsets)
