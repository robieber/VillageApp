"""Chart data from bill lines. Pure functions; amounts are summed across the selected accounts so a multi-account
selection gives the cumulative, stacked series required by FR-WEB-026 and FR-WEB-036."""
from collections import OrderedDict
from datetime import date, timedelta


def _period(y, m):
    return y * 12 + (m - 1)


def _label(p):
    return f'{p // 12}-{p % 12 + 1:02d}'


def billing_history(rows, months=12):
    """rows: iterable of (year, month, component, value) for CHARGE lines.

    Returns the last `months` calendar months ending at the latest month present, with zero-filled gaps:
    {'components': [...], 'periods': [{'period': '2026-09', 'total': 12.0, 'values': {component: value}}]}
    """
    data = {}
    comps = OrderedDict()
    for y, m, comp, val in rows:
        p = _period(y, m)
        data.setdefault(p, {})
        data[p][comp] = round(data[p].get(comp, 0.0) + float(val), 2)
        comps.setdefault(comp, None)
    if not data:
        return {'components': [], 'periods': []}
    last = max(data)
    periods = []
    for p in range(last - months + 1, last + 1):
        values = data.get(p, {})
        periods.append({'period': _label(p), 'total': round(sum(values.values()), 2), 'values': values})
    used = [c for c in comps if any(c in pr['values'] for pr in periods)]
    return {'components': used, 'periods': periods}


def _local(dt):
    """Stored as naive UTC; Philippine time is UTC+8 all year."""
    return dt + timedelta(hours=8)


def energy_yearly(rows, year):
    """rows: (bill_year, bill_month, energy_kwh, meq_kwh or None). Clustered columns, one cluster per month."""
    months = {m: {'energy_kwh': 0.0, 'meq_kwh': None} for m in range(1, 13)}
    for y, m, kwh, meq in rows:
        if y != year:
            continue
        months[m]['energy_kwh'] = round(months[m]['energy_kwh'] + float(kwh or 0), 2)
        if meq is not None:
            months[m]['meq_kwh'] = round((months[m]['meq_kwh'] or 0.0) + float(meq), 2)
    return {'year': year, 'months': [dict(month=m, **months[m]) for m in range(1, 13)]}


def energy_daily(rows, year, month):
    """rows: (interval_start naive UTC, kwh, kw or None). Bars = kWh per day, line = highest kW in the day."""
    last = (date(year + (month == 12), month % 12 + 1, 1) - timedelta(days=1)).day
    days = {d: {'kwh': 0.0, 'peak_kw': None} for d in range(1, last + 1)}
    for start, kwh, kw in rows:
        t = _local(start)
        if (t.year, t.month) != (year, month):
            continue
        d = days[t.day]
        d['kwh'] = round(d['kwh'] + float(kwh), 2)
        if kw is not None:
            d['peak_kw'] = max(float(kw), d['peak_kw'] or 0.0)
    return {'year': year, 'month': month, 'days': [dict(day=d, **days[d]) for d in range(1, last + 1)]}


def energy_hourly(rows, day):
    """One day, 24 points: kWh per hour (bars) and kW demand (line)."""
    hours = {h: {'kwh': 0.0, 'kw': None} for h in range(24)}
    for start, kwh, kw in rows:
        t = _local(start)
        if t.date() != day:
            continue
        h = hours[t.hour]
        h['kwh'] = round(h['kwh'] + float(kwh), 2)
        if kw is not None:
            h['kw'] = max(float(kw), h['kw'] or 0.0)
    return {'date': day.isoformat(), 'hours': [dict(hour=h, **hours[h]) for h in range(24)]}
