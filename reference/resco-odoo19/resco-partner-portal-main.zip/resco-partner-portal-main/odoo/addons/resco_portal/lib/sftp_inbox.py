"""Finds complete CMS-RES batches in an SFTP inbox. Transport-agnostic so it can be tested with a fake.

Layout:
    /inbound/<BATCH_ID>/   the CSV files and PDFs of one batch, then a file ending in .done written LAST
After processing the whole folder moves to /processed/<BATCH_ID>/ or /error/<BATCH_ID>/ together with
result.txt describing each outcome.
"""
from dataclasses import dataclass, field


class Transport:
    """Minimal interface; the paramiko adapter in models/resco_sftp.py implements it."""
    def listdir(self, path): ...
    def read(self, path): ...
    def write(self, path, data): ...
    def move(self, src, dst): ...
    def makedirs(self, path): ...
    def isdir(self, path): ...


@dataclass
class InboxBatch:
    folder: str                 # /inbound/<BATCH_ID>
    name: str                   # BATCH_ID
    paths: dict = field(default_factory=dict)   # file name -> path (CSV and PDF only)
    marker_paths: list = field(default_factory=list)


def find_ready_batches(t, inbound='/inbound'):
    batches = []
    if not t.isdir(inbound):
        return batches
    for sub in sorted(t.listdir(inbound)):
        folder = f'{inbound}/{sub}'
        if not t.isdir(folder):
            continue
        names = t.listdir(folder)
        markers = [n for n in names if n.lower().endswith('.done')]
        if not markers:
            continue
        b = InboxBatch(folder=folder, name=sub, marker_paths=[f'{folder}/{m}' for m in markers])
        b.paths = {n: f'{folder}/{n}' for n in names if n.lower().endswith(('.csv', '.pdf'))}
        batches.append(b)
    return batches


def archive_batch(t, batch, ok, result_text, root='/'):
    """Move the batch's files to /processed or /error and write result.txt next to them."""
    top = 'processed' if ok else 'error'
    dest = f'{root.rstrip("/")}/{top}/{batch.name}'
    t.makedirs(dest)
    t.write(f'{dest}/result.txt', result_text.encode('utf-8'))
    for path in [*batch.paths.values(), *batch.marker_paths]:
        t.move(path, f'{dest}/{path.rsplit("/", 1)[-1]}')
    return dest
