"""Proof-of-payment rules (PAY-001, FR-WEB-027/028/040). No Odoo imports, so it is unit-testable on its own.

A submission is one payment (date, bank, mode, total) with allocation lines: each line assigns a peso amount to one
account and, optionally, one bill of that account. The lines must add up to the amount paid.
"""
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

MAX_PROOF_BYTES = 5 * 1024 * 1024
MAX_PROOF_FILES = 5
MAX_LINES = 50
MODES = [('bank_deposit', 'Bank deposit'), ('bank_transfer', 'Bank transfer / online banking'), ('check', 'Check'),
         ('over_the_counter', 'Over-the-counter payment center'), ('ewallet', 'E-wallet'), ('other', 'Other')]
MODE_KEYS = {k for k, _ in MODES}
# Magic bytes decide the type, never the file name or the type the browser claims.
SIGNATURES = [(b'\x89PNG\r\n\x1a\n', 'image/png', 'png'), (b'\xff\xd8\xff', 'image/jpeg', 'jpg'), (b'%PDF-', 'application/pdf', 'pdf')]
HISTORY_DAYS = 366


def money(value) -> Decimal:
    """Parse a peso amount; raises ValueError for anything that is not a plain number with at most 2 decimals."""
    if isinstance(value, bool):
        raise ValueError('not an amount')
    try:
        d = Decimal(str(value).strip().replace(',', ''))
    except (InvalidOperation, AttributeError):
        raise ValueError('not an amount')
    if not d.is_finite() or d != d.quantize(Decimal('0.01')):
        raise ValueError('not an amount with centavos')
    return d


def sniff(raw: bytes):
    """Return (mimetype, extension) from the file content, or None if it is not a PNG, JPEG or PDF."""
    for magic, mime, ext in SIGNATURES:
        if raw.startswith(magic):
            return mime, ext
    return None


def safe_name(name: str, ext: str) -> str:
    base = ''.join(c if c.isalnum() or c in '._-' else '_' for c in (name or 'proof').rsplit('/', 1)[-1].rsplit('\\', 1)[-1])
    base = base.rsplit('.', 1)[0].strip('._') or 'proof'
    return f'{base[:80]}.{ext}'


def check_file(name: str, raw: bytes):
    """Returns (clean file name, mimetype). Raises ValueError with a message safe to show the customer."""
    if not raw:
        raise ValueError('The file is empty.')
    if len(raw) > MAX_PROOF_BYTES:
        raise ValueError(f'"{name}" is larger than {MAX_PROOF_BYTES // (1024 * 1024)} MB.')
    kind = sniff(raw)
    if not kind:
        raise ValueError(f'"{name}" is not a PNG, JPEG or PDF file.')
    return safe_name(name, kind[1]), kind[0]


def check_header(payment_date, bank, mode, amount, today: date):
    """Returns (date, bank, mode, amount) normalised, or raises ValueError."""
    if not isinstance(payment_date, date):
        raise ValueError('Enter the date of payment.')
    if payment_date > today:
        raise ValueError('The date of payment cannot be in the future.')
    if payment_date < today - timedelta(days=HISTORY_DAYS):
        raise ValueError('The date of payment is more than a year ago.')
    bank = (bank or '').strip()
    if not bank:
        raise ValueError('Enter the bank name.')
    if len(bank) > 100:
        raise ValueError('The bank name is too long.')
    if mode not in MODE_KEYS:
        raise ValueError('Choose the mode of payment.')
    try:
        amount = money(amount)
    except ValueError:
        raise ValueError('Enter the amount paid in pesos, for example 12500.50.')
    if amount <= 0:
        raise ValueError('The amount paid must be more than zero.')
    return payment_date, bank, mode, amount


def check_allocations(lines, amount: Decimal, allowed_accounts, bill_account):
    """lines: [{'account_id': int, 'bill_id': int|None, 'amount': ...}].
    allowed_accounts: set of account ids the user may use. bill_account: {bill_id: account_id} for bills the user may see.
    Returns the lines normalised, or raises ValueError."""
    if not lines:
        raise ValueError('Add at least one account and amount.')
    if len(lines) > MAX_LINES:
        raise ValueError(f'A payment can be split over at most {MAX_LINES} lines.')
    out, total, seen = [], Decimal('0'), set()
    for i, ln in enumerate(lines, 1):
        acc = ln.get('account_id')
        bill = ln.get('bill_id') or None
        if acc not in allowed_accounts:
            raise ValueError(f'Line {i}: choose one of your accounts.')
        if bill is not None and bill_account.get(bill) != acc:
            raise ValueError(f'Line {i}: the bill does not belong to that account.')
        try:
            amt = money(ln.get('amount'))
        except ValueError:
            raise ValueError(f'Line {i}: enter the amount in pesos.')
        if amt <= 0:
            raise ValueError(f'Line {i}: the amount must be more than zero.')
        if (acc, bill) in seen:
            raise ValueError(f'Line {i}: the same account and bill is listed twice.')
        seen.add((acc, bill))
        total += amt
        out.append({'account_id': acc, 'bill_id': bill, 'amount': amt})
    if total != amount:
        raise ValueError(f'The amounts on the lines add up to PHP {total:,.2f}, but the amount paid is PHP {amount:,.2f}.')
    return out
