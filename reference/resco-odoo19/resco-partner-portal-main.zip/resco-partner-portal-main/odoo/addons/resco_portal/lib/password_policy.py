"""Password rules for portal users. Placeholder values until RESCo's cybersecurity team supplies its standard
(FR-WEB-016): change MIN_LENGTH and the character classes here, nothing else depends on them."""
import re

MIN_LENGTH = 12


def check(password, login=''):
    """Return a list of problems; empty means acceptable."""
    problems = []
    if len(password or '') < MIN_LENGTH:
        problems.append(f'at least {MIN_LENGTH} characters')
    if not re.search(r'[a-z]', password or ''):
        problems.append('a lowercase letter')
    if not re.search(r'[A-Z]', password or ''):
        problems.append('an uppercase letter')
    if not re.search(r'\d', password or ''):
        problems.append('a number')
    if not re.search(r'[^A-Za-z0-9]', password or ''):
        problems.append('a symbol')
    local = (login or '').split('@')[0].lower()
    if len(local) >= 4 and local in (password or '').lower():
        problems.append('no part of your email address')
    return problems


def message(problems):
    return 'The password needs ' + ', '.join(problems) + '.' if problems else ''
