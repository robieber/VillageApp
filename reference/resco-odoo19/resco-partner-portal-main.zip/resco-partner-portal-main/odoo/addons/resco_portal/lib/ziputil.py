"""Safe extraction of PDFs from an uploaded ZIP. No Odoo imports."""
import io
import zipfile

try:
    from cms_files import safe_file_name  # tests import the lib directory directly
except ImportError:  # pragma: no cover - inside Odoo
    from .cms_files import safe_file_name

MAX_TOTAL_BYTES = 200 * 1024 * 1024
MAX_FILES = 2000


def extract_batch(zip_bytes):
    """Return ({name: bytes} of every CSV and PDF, [messages]); files is None if the ZIP is unusable.
    Nested folders are flattened."""
    msgs, files = [], {}
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile:
        return None, ['The upload is not a valid ZIP file.']
    infos = [i for i in zf.infolist() if not i.is_dir() and not i.filename.startswith('__MACOSX')]
    if len(infos) > MAX_FILES:
        return None, [f'The ZIP has more than {MAX_FILES} files.']
    if sum(i.file_size for i in infos) > MAX_TOTAL_BYTES:
        return None, ['The ZIP expands to more than 200 MB.']
    for i in infos:
        try:
            name = safe_file_name(i.filename)
        except ValueError as e:
            msgs.append(str(e))
            continue
        if not name.lower().endswith(('.pdf', '.csv')):
            msgs.append(f'{name}: ignored (only .pdf and .csv are used).')
            continue
        if name in files:
            msgs.append(f'{name}: appears more than once in the ZIP; the first one is used.')
            continue
        files[name] = zf.read(i)
    if not any(n.lower().endswith('.csv') for n in files):
        msgs.append('The ZIP contains no CSV file.')
        return None, msgs
    return files, msgs
