"""CMS-RES batch files: classification, parsing and validation. No Odoo imports, so it is unit-testable on its own.

A batch is a set of files delivered together (SFTP folder or manual upload):

    MPWR_BILL_HDR_*.csv      one row per bill                      (File 1)
    MPWR_BILL_COMP_*.csv     one row per bill cost component       (File 2)
    MPWR_PAY_STAT_*.csv      payment status updates                (File 4)
    MPWR_ENERGY_HRLY_*.csv   interval (hourly) energy per account  (proposed, for the Energy Dashboard)
    MPWR_ACCOUNT_*.csv       customer accounts, parent companies and portal contacts (initial load / changes)
    MPWR_CTRL_*.csv          control totals: row count and amount total per file, checked before loading
    <PDF_FILE_NAME>.pdf      the bill PDFs named in File 1
    MPWR_BILL_PDF_*.csv      Salesforce ContentVersion manifest (File 3): not needed by Odoo, ignored

Bills are loaded all-or-nothing: an error in a bill's header row or any of its component rows rejects that bill only.
"""
import csv
import io
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation

MAX_PDF_BYTES = 10 * 1024 * 1024
PH_TZ = timezone(timedelta(hours=8))
TOLERANCE = Decimal('0.01')

PAYMENT_STATUS = {'UNPAID': 'unpaid', 'PARTIALLY_PAID': 'partial', 'PAID': 'paid', 'OVERDUE': 'overdue'}
KINDS = [('MPWR_BILL_HDR', 'header'), ('MPWR_BILL_COMP', 'components'), ('MPWR_PAY_STAT', 'payment'),
         ('MPWR_ENERGY_HRLY', 'hourly'), ('MPWR_BILL_PDF', 'manifest'), ('MPWR_ACCOUNT', 'account'),
         ('MPWR_CTRL', 'control')]

HEADER_REQUIRED = ['BILL_KEY', 'CSIN', 'ACCOUNT_NAME', 'SERVICE_ADDRESS', 'BILL_NUMBER', 'BILL_MONTH', 'BILL_YEAR',
                   'BILL_DATE', 'BILLING_PERIOD_FROM', 'BILLING_PERIOD_TO', 'DUE_DATE', 'PRICING_PRODUCT',
                   'CONTRACTED_CAPACITY_KW', 'ENERGY_KWH', 'CURRENT_CHARGES', 'VAT_AMOUNT', 'TOTAL_AMOUNT_DUE',
                   'CURRENCY', 'PAYMENT_STATUS', 'PDF_FILE_NAME', 'IS_REVISED']
COMP_REQUIRED = ['BILL_KEY', 'COMPONENT_CODE', 'COMPONENT_NAME', 'AMOUNT', 'SORT_ORDER']
PAY_REQUIRED = ['BILL_KEY', 'PAYMENT_STATUS', 'AMOUNT_PAID', 'OUTSTANDING_BALANCE', 'STATUS_AS_OF']
HOURLY_REQUIRED = ['CSIN', 'INTERVAL_START', 'KWH']
ACCOUNT_REQUIRED = ['CSIN', 'ACCOUNT_NAME', 'PARENT_COMPANY_NAME']
CTRL_REQUIRED = ['FILE_NAME', 'ROW_COUNT', 'CONTROL_FIELD', 'CONTROL_TOTAL']


@dataclass
class Issue:
    row: int          # 1-based CSV row incl. header; 0 = file level
    key: str          # bill key / CSIN or ''
    message: str
    file: str = ''


@dataclass
class Component:
    code: str
    name: str
    amount: Decimal
    sort_order: int
    quantity: Decimal = None
    uom: str = ''
    rate: Decimal = None


@dataclass
class BillData:
    bill_key: str
    csin: str
    year: int
    month: int
    fields: dict
    pdf_file_name: str
    components: list = field(default_factory=list)
    row: int = 0

    @property
    def key(self):
        return (self.csin, self.year, self.month)

    @property
    def bill_number(self):
        return self.fields['bill_number']


@dataclass
class Parsed:
    bills: list = field(default_factory=list)
    payments: list = field(default_factory=list)     # dicts, see parse_payment
    intervals: list = field(default_factory=list)    # (csin, naive UTC datetime, kwh, kw_or_None)
    accounts: list = field(default_factory=list)     # dicts, see parse_accounts
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    ignored: list = field(default_factory=list)


# ---------------------------------------------------------------- primitives
def _c(v):
    return (v or '').strip()


def _dec(raw, label, required=True):
    s = _c(raw).replace(',', '').replace('₱', '').strip()
    if not s:
        if required:
            raise ValueError(f'{label} is empty')
        return None
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise ValueError(f'{label} "{raw}" is not a number')
    if not d.is_finite():
        raise ValueError(f'{label} "{raw}" is not a number')
    return d


def _date(raw, label, required=True):
    s = _c(raw)
    if not s and not required:
        return None
    for fmt in ('%Y-%m-%d', '%m/%d/%Y'):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise ValueError(f'{label} "{raw}" must be YYYY-MM-DD')


def _int(raw, label, lo, hi):
    try:
        n = int(_c(raw))
    except ValueError:
        raise ValueError(f'{label} "{raw}" must be a whole number')
    if not lo <= n <= hi:
        raise ValueError(f'{label} {n} must be between {lo} and {hi}')
    return n


def _datetime_utc(raw, label):
    """ISO 8601 (+08:00 expected). A value without an offset is taken as Philippine time. Returns naive UTC."""
    s = _c(raw).replace('Z', '+00:00').replace(' ', 'T', 1)
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        raise ValueError(f'{label} "{raw}" must be ISO 8601, e.g. 2026-09-01T00:00:00+08:00')
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=PH_TZ)
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def _bool_yn(raw, label):
    v = _c(raw).upper()
    if v in ('Y', 'YES', 'TRUE', '1'):
        return True
    if v in ('N', 'NO', 'FALSE', '0', ''):
        return False
    raise ValueError(f'{label} "{raw}" must be Y or N')


def _status(raw):
    s = _c(raw).upper().replace(' ', '_')
    if s not in PAYMENT_STATUS:
        raise ValueError(f'PAYMENT_STATUS "{raw}" must be UNPAID, PARTIALLY_PAID, PAID or OVERDUE')
    return PAYMENT_STATUS[s]


def decode_csv(raw):
    if isinstance(raw, str):
        return raw
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return raw.decode('cp1252')


def classify(name):
    """File name to kind: header, components, payment, hourly, account, control, manifest, pdf or None."""
    up = name.upper()
    if up.endswith('.PDF'):
        return 'pdf'
    if up.endswith('.CSV'):
        for prefix, kind in KINDS:
            if up.startswith(prefix):
                return kind
    return None


def validate_pdf(name, data):
    if not name.lower().endswith('.pdf'):
        return f'{name}: not a .pdf file'
    if len(data) > MAX_PDF_BYTES:
        return f'{name}: larger than {MAX_PDF_BYTES // (1024 * 1024)} MB'
    if data[:5] != b'%PDF-':
        return f'{name}: content is not a PDF'
    return None


def safe_file_name(name):
    base = re.split(r'[\\/]', name)[-1].strip()
    if not base or base in ('.', '..'):
        raise ValueError(f'Unsafe file name "{name}"')
    return base


def _read(text, required, fname, errors):
    """Yield (row number, upper-cased dict). Appends file-level issues to errors and yields nothing if unusable."""
    reader = csv.DictReader(io.StringIO(text))
    if reader.fieldnames is None:
        errors.append(Issue(0, '', 'The file is empty.', fname))
        return []
    reader.fieldnames = [_c(h).upper() for h in reader.fieldnames]
    missing = [c for c in required if c not in reader.fieldnames]
    if missing:
        errors.append(Issue(0, '', 'Missing column(s): ' + ', '.join(missing), fname))
        return []
    out = []
    for n, row in enumerate(reader, start=2):
        if any(_c(v) for v in row.values() if isinstance(v, str)):
            out.append((n, row))
    return out


# ---------------------------------------------------------------- File 1
def parse_header(text, fname, known_accounts, errors, warnings):
    bills, seen_keys, seen_period, seen_pdf = {}, set(), {}, {}
    for n, r in _read(text, HEADER_REQUIRED, fname, errors):
        key = _c(r['BILL_KEY'])
        label = key or _c(r['CSIN']) or '?'
        try:
            if not key:
                raise ValueError('BILL_KEY is empty')
            csin = _c(r['CSIN'])
            if csin not in known_accounts:
                raise ValueError(f'Account {csin or "(blank)"} does not exist in Odoo')
            year = _int(r['BILL_YEAR'], 'BILL_YEAR', 2000, 2100)
            month = _int(r['BILL_MONTH'], 'BILL_MONTH', 1, 12)
            bill_number = _c(r['BILL_NUMBER'])
            pdf = _c(r['PDF_FILE_NAME'])
            if not bill_number:
                raise ValueError('BILL_NUMBER is empty')
            if not pdf:
                raise ValueError('PDF_FILE_NAME is empty')
            if _c(r['CURRENCY']).upper() != 'PHP':
                raise ValueError(f'CURRENCY "{r["CURRENCY"]}" must be PHP')
            f = {
                'bill_number': bill_number,
                'bill_date': _date(r['BILL_DATE'], 'BILL_DATE'),
                'period_from': _date(r['BILLING_PERIOD_FROM'], 'BILLING_PERIOD_FROM'),
                'period_to': _date(r['BILLING_PERIOD_TO'], 'BILLING_PERIOD_TO'),
                'due_date': _date(r['DUE_DATE'], 'DUE_DATE'),
                'service_address': _c(r['SERVICE_ADDRESS']),
                'pricing_product': _c(r['PRICING_PRODUCT']),
                'contracted_capacity_kw': _dec(r['CONTRACTED_CAPACITY_KW'], 'CONTRACTED_CAPACITY_KW'),
                'energy_kwh': _dec(r['ENERGY_KWH'], 'ENERGY_KWH'),
                'meq_kwh': _dec(r.get('MEQ_KWH'), 'MEQ_KWH', False),
                'change_in_energy_kwh': _dec(r.get('CHANGE_IN_ENERGY_KWH'), 'CHANGE_IN_ENERGY_KWH', False),
                'peak_kwh': _dec(r.get('PEAK_KWH'), 'PEAK_KWH', False),
                'offpeak_kwh': _dec(r.get('OFFPEAK_KWH'), 'OFFPEAK_KWH', False),
                'peak_demand_kw': _dec(r.get('PEAK_DEMAND_KW'), 'PEAK_DEMAND_KW', False),
                'current_charges': _dec(r['CURRENT_CHARGES'], 'CURRENT_CHARGES'),
                'vat_amount': _dec(r['VAT_AMOUNT'], 'VAT_AMOUNT'),
                'previous_balance': _dec(r.get('PREVIOUS_BALANCE'), 'PREVIOUS_BALANCE', False) or Decimal(0),
                'adjustments': _dec(r.get('ADJUSTMENTS'), 'ADJUSTMENTS', False) or Decimal(0),
                'total_amount': _dec(r['TOTAL_AMOUNT_DUE'], 'TOTAL_AMOUNT_DUE'),
                'payment_status': _status(r['PAYMENT_STATUS']),
                'is_revised': _bool_yn(r['IS_REVISED'], 'IS_REVISED'),
                'supersedes_key': _c(r.get('SUPERSEDES_BILL_KEY')),
                'source_system': _c(r.get('SOURCE_SYSTEM')),
                'extract_batch_id': _c(r.get('EXTRACT_BATCH_ID')),
                'extract_timestamp': _datetime_utc(r['EXTRACT_TIMESTAMP'], 'EXTRACT_TIMESTAMP')
                if _c(r.get('EXTRACT_TIMESTAMP')) else None,
            }
            if f['period_to'] < f['period_from']:
                raise ValueError('BILLING_PERIOD_TO is before BILLING_PERIOD_FROM')
            if f['is_revised'] and not f['supersedes_key']:
                raise ValueError('SUPERSEDES_BILL_KEY is required when IS_REVISED is Y')
            expected = f['previous_balance'] + f['current_charges'] + f['vat_amount'] + f['adjustments']
            if abs(expected - f['total_amount']) > TOLERANCE:
                raise ValueError(f'TOTAL_AMOUNT_DUE {f["total_amount"]} must equal PREVIOUS_BALANCE + CURRENT_CHARGES '
                                 f'+ VAT_AMOUNT + ADJUSTMENTS ({expected})')
            if f['total_amount'] < 0:
                raise ValueError('TOTAL_AMOUNT_DUE cannot be negative')
            if key in seen_keys:
                raise ValueError(f'BILL_KEY {key} appears twice in this file')
            if (csin, year, month) in seen_period:
                raise ValueError(f'A second bill for {csin} {year}-{month:02d} (first is {seen_period[(csin, year, month)]})')
            if pdf in seen_pdf:
                raise ValueError(f'PDF "{pdf}" is already used by bill {seen_pdf[pdf]}')
        except ValueError as e:
            errors.append(Issue(n, label, str(e), fname))
            continue
        name = _c(r['ACCOUNT_NAME'])
        if name and known_accounts[csin] and name.lower() != known_accounts[csin].lower():
            warnings.append(Issue(n, key, f'ACCOUNT_NAME "{name}" differs from the account in Odoo ("{known_accounts[csin]}")', fname))
        seen_keys.add(key)
        seen_period[(csin, year, month)] = key
        seen_pdf[pdf] = key
        bills[key] = BillData(key, csin, year, month, f, pdf, row=n)
    return bills


# ---------------------------------------------------------------- File 2
def parse_components(text, fname, bills, errors, bad_keys):
    seen = {}
    for n, r in _read(text, COMP_REQUIRED, fname, errors):
        key = _c(r['BILL_KEY'])
        try:
            if key not in bills:
                if key not in bad_keys:
                    raise ValueError(f'BILL_KEY {key or "(blank)"} is not in the bill header file of this batch')
                continue   # its header was already rejected; that error is reported once
            code = _c(r['COMPONENT_CODE']).upper()
            if not code:
                raise ValueError('COMPONENT_CODE is empty')
            name = _c(r['COMPONENT_NAME'])
            if not name:
                raise ValueError('COMPONENT_NAME is empty')
            uom = _c(r.get('UOM')).upper()
            if uom and uom not in ('KWH', 'KW', 'FIXED'):
                raise ValueError(f'UOM "{uom}" must be KWH, KW or FIXED')
            comp = Component(code, name, _dec(r['AMOUNT'], 'AMOUNT'), _int(r['SORT_ORDER'], 'SORT_ORDER', 0, 999),
                             _dec(r.get('QUANTITY'), 'QUANTITY', False), uom, _dec(r.get('RATE'), 'RATE', False))
            if code in seen.setdefault(key, set()):
                raise ValueError(f'COMPONENT_CODE {code} appears twice for this bill')
            seen[key].add(code)
            bills[key].components.append(comp)
        except ValueError as e:
            errors.append(Issue(n, key, str(e), fname))
            bad_keys.add(key)
            bills.pop(key, None)


# ---------------------------------------------------------------- File 4
def parse_payment(text, fname, errors):
    out = []
    for n, r in _read(text, PAY_REQUIRED, fname, errors):
        key = _c(r['BILL_KEY'])
        try:
            if not key:
                raise ValueError('BILL_KEY is empty')
            out.append({
                'row': n, 'bill_key': key, 'payment_status': _status(r['PAYMENT_STATUS']),
                'amount_paid': _dec(r['AMOUNT_PAID'], 'AMOUNT_PAID'),
                'outstanding': _dec(r['OUTSTANDING_BALANCE'], 'OUTSTANDING_BALANCE'),
                'last_payment_date': _date(r.get('LAST_PAYMENT_DATE'), 'LAST_PAYMENT_DATE', False),
                'status_as_of': _datetime_utc(r['STATUS_AS_OF'], 'STATUS_AS_OF'), 'file': fname,
            })
        except ValueError as e:
            errors.append(Issue(n, key, str(e), fname))
    return out


# ---------------------------------------------------------------- hourly energy
def parse_hourly(text, fname, known_accounts, errors):
    out, seen = [], set()
    for n, r in _read(text, HOURLY_REQUIRED, fname, errors):
        csin = _c(r['CSIN'])
        try:
            if csin not in known_accounts:
                raise ValueError(f'Account {csin or "(blank)"} does not exist in Odoo')
            start = _datetime_utc(r['INTERVAL_START'], 'INTERVAL_START')
            kwh = _dec(r['KWH'], 'KWH')
            kw = _dec(r.get('KW_DEMAND'), 'KW_DEMAND', False)
            if kwh < 0:
                raise ValueError('KWH cannot be negative')
            if (csin, start) in seen:
                raise ValueError(f'Interval {r["INTERVAL_START"]} appears twice for {csin}')
            seen.add((csin, start))
            out.append((csin, start, kwh, kw))
        except ValueError as e:
            errors.append(Issue(n, csin, str(e), fname))
    return out


# ---------------------------------------------------------------- accounts
def parse_accounts(text, fname, errors, warnings):
    """Customer accounts. Returns dicts; one bad row rejects only that account."""
    out, seen = [], set()
    for n, r in _read(text, ACCOUNT_REQUIRED, fname, errors):
        csin = _c(r['CSIN'])
        try:
            if not csin:
                raise ValueError('CSIN is empty')
            if csin in seen:
                raise ValueError(f'CSIN {csin} appears twice in this file')
            seen.add(csin)
            name, company = _c(r['ACCOUNT_NAME']), _c(r['PARENT_COMPANY_NAME'])
            if not name or not company:
                raise ValueError('ACCOUNT_NAME and PARENT_COMPANY_NAME are required')
            email = _c(r.get('PRIMARY_CONTACT_EMAIL')).lower()
            if email and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', email):
                raise ValueError(f'PRIMARY_CONTACT_EMAIL "{email}" is not an email address')
            sam_email = _c(r.get('SAM_EMAIL')).lower()
            cap = _dec(r.get('CONTRACTED_CAPACITY_KW'), 'CONTRACTED_CAPACITY_KW', False)
            if cap is not None and cap < 0:
                raise ValueError('CONTRACTED_CAPACITY_KW cannot be negative')
            status = _c(r.get('ACCOUNT_STATUS')).lower() or 'active'
            out.append({
                'row': n, 'csin': csin, 'name': name, 'company': company, 'company_ref': _c(r.get('PARENT_COMPANY_ID')),
                'address': _c(r.get('SERVICE_ADDRESS')), 'product': _c(r.get('PRICING_PRODUCT')),
                'capacity': cap, 'meq': _dec(r.get('MEQ_KWH'), 'MEQ_KWH', False),
                'start': _date(r.get('CONTRACT_START'), 'CONTRACT_START', False),
                'end': _date(r.get('CONTRACT_END'), 'CONTRACT_END', False),
                'sam_name': _c(r.get('SAM_NAME')), 'sam_email': sam_email,
                'contact_name': _c(r.get('PRIMARY_CONTACT_NAME')), 'contact_email': email,
                'contact_mobile': _c(r.get('PRIMARY_CONTACT_MOBILE')), 'active': status in ('active', 'a', 'y'),
                'file': fname,
            })
            if not email:
                warnings.append(Issue(n, csin, 'No PRIMARY_CONTACT_EMAIL: nobody will be able to sign in for this account yet.', fname))
        except ValueError as e:
            errors.append(Issue(n, csin, str(e), fname))
    return out


# ---------------------------------------------------------------- control totals
def check_control(text, fname, files, errors):
    """MPWR_CTRL_*: for every file it lists that is in the batch, compare the row count and the control total.
    A mismatch usually means a truncated or edited file, so the problem is reported against that file."""
    for n, r in _read(text, CTRL_REQUIRED, fname, errors):
        target = _c(r['FILE_NAME'])
        data = next((files[k] for k in files if k.lower() == target.lower()), None)
        if data is None:
            continue                                  # the listed file is not part of this batch
        try:
            want_rows = int(_c(r['ROW_COUNT']))
            want_total = _dec(r['CONTROL_TOTAL'], 'CONTROL_TOTAL')
        except ValueError as e:
            errors.append(Issue(n, '', f'Control row is not readable: {e}', fname))
            continue
        scratch = []
        rows = _read(decode_csv(data), [], target, scratch)
        field_name = _c(r['CONTROL_FIELD']).upper()
        if rows and field_name not in rows[0][1]:
            if len(rows) != want_rows:
                errors.append(Issue(0, '', f'Control file says {want_rows} rows but {target} has {len(rows)}.', fname))
            continue                                  # e.g. FILE_COUNT: only the row count can be checked
        if len(rows) != want_rows:
            errors.append(Issue(0, '', f'Control file says {want_rows} rows but {target} has {len(rows)}. '
                                       'The file may be incomplete.', fname))
            continue
        try:
            total = sum((_dec(row.get(field_name), field_name) for _n, row in rows), Decimal(0))
        except ValueError as e:
            errors.append(Issue(0, '', f'{target}: control field {field_name} cannot be summed: {e}', fname))
            continue
        if abs(total - want_total) > TOLERANCE:
            errors.append(Issue(0, '', f'Control total for {field_name} in {target} is {want_total} but the file adds up '
                                       f'to {total}.', fname))


# ---------------------------------------------------------------- whole batch
def parse_batch(files, known_accounts, existing_keys=()):
    """files: {name: bytes}. existing_keys: anything supporting `in` that tells whether a BILL_KEY is already in Odoo
    (payment updates may arrive in their own batch)."""
    res = Parsed()
    by_kind = {}
    pdfs = {}
    for name, data in files.items():
        kind = classify(name)
        if kind == 'pdf':
            err = validate_pdf(name, data)
            if err:
                res.errors.append(Issue(0, '', err, name))
            else:
                pdfs[name] = data
        elif kind == 'manifest':
            res.warnings.append(Issue(0, '', 'Salesforce PDF manifest ignored; PDFs are matched by PDF_FILE_NAME.', name))
        elif kind:
            by_kind.setdefault(kind, []).append(name)
        else:
            res.ignored.append(name)
            res.warnings.append(Issue(0, '', 'File name not recognised (expected MPWR_BILL_HDR_*, MPWR_BILL_COMP_*, '
                                              'MPWR_PAY_STAT_*, MPWR_ENERGY_HRLY_* or a .pdf); ignored.', name))
    if not by_kind:
        res.errors.append(Issue(0, '', 'The batch has no CSV files.'))
        return res, pdfs

    # Accounts first, so bills and hourly files in the same batch can refer to accounts that are about to be created.
    known_accounts = dict(known_accounts)
    for name in by_kind.get('account', []):
        for a in parse_accounts(decode_csv(files[name]), name, res.errors, res.warnings):
            res.accounts.append(a)
            known_accounts.setdefault(a['csin'], a['name'])

    bills, header_errors_before = {}, len(res.errors)
    bad_keys = set()
    for name in by_kind.get('header', []):
        bills.update(parse_header(decode_csv(files[name]), name, known_accounts, res.errors, res.warnings))
    # keys whose header failed are not in `bills`; remember them so component rows do not add noise
    for iss in res.errors[header_errors_before:]:
        if iss.key:
            bad_keys.add(iss.key)
    for name in by_kind.get('components', []):
        parse_components(decode_csv(files[name]), name, bills, res.errors, bad_keys)

    final, used_numbers = [], {}
    for key, b in bills.items():
        if b.pdf_file_name not in pdfs:
            res.errors.append(Issue(b.row, key, f'PDF "{b.pdf_file_name}" was not supplied with the batch', 'header'))
            continue
        if not b.components:
            res.errors.append(Issue(b.row, key, 'The bill has no cost components in the components file', 'header'))
            continue
        total = sum(c.amount for c in b.components)
        if abs(total - b.fields['current_charges']) > TOLERANCE:
            res.warnings.append(Issue(b.row, key, f'The components add up to {total}, which differs from CURRENT_CHARGES '
                                                  f'{b.fields["current_charges"]} (VAT is a separate column).', 'header'))
        final.append(b)
    res.bills = final
    referenced = {b.pdf_file_name for b in bills.values()}
    for name in sorted(set(pdfs) - referenced):
        res.warnings.append(Issue(0, '', 'PDF not referenced by any bill row; ignored.', name))

    known_keys = {b.bill_key for b in final}
    for name in by_kind.get('payment', []):
        for p in parse_payment(decode_csv(files[name]), name, res.errors):
            if p['bill_key'] not in known_keys and p['bill_key'] not in existing_keys:
                res.errors.append(Issue(p['row'], p['bill_key'], 'No bill with this BILL_KEY in this batch or in Odoo', name))
            else:
                res.payments.append(p)
    for name in by_kind.get('hourly', []):
        res.intervals.extend(parse_hourly(decode_csv(files[name]), name, known_accounts, res.errors))
    control_errors_before = len(res.errors)
    for name in by_kind.get('control', []):
        check_control(decode_csv(files[name]), name, files, res.errors)
    if len(res.errors) > control_errors_before:
        # A file does not match its control totals: load nothing from this batch rather than part of it.
        res.errors.append(Issue(0, '', 'Nothing was loaded from this batch because a file does not match its control '
                                       'totals. Ask CMS-RES to resend it.', 'control'))
        res.bills, res.payments, res.intervals, res.accounts = [], [], [], []
    control_errors_before = len(res.errors)
    for name in by_kind.get('control', []):
        check_control(decode_csv(files[name]), name, files, res.errors)
    if len(res.errors) > control_errors_before:
        # A file does not match its control totals: load nothing from this batch rather than part of it.
        res.errors.append(Issue(0, '', 'Nothing was loaded from this batch because a file does not match its control '
                                       'totals. Ask CMS-RES to resend it.', 'control'))
        res.bills, res.payments, res.intervals, res.accounts = [], [], [], []
    return res, pdfs
