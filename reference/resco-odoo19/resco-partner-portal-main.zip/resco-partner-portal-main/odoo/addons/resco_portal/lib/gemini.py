"""Minimal Gemini REST client for the portal assistant. No Odoo imports; the HTTP call is injected so it can be tested.

Flow: send the conversation and the tool declarations; when the model answers with functionCall parts, run each tool
here, send back functionResponse parts, and repeat until it answers with text (at most MAX_STEPS rounds).
"""
import json

ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'
MAX_STEPS = 5
MAX_TOOL_CHARS = 12000
MAX_REPLY_CHARS = 6000


class GeminiError(Exception):
    """Message is safe to show to the customer."""


def request_body(system, contents, declarations, temperature=0.3):
    body = {
        'systemInstruction': {'parts': [{'text': system}]},
        'contents': contents,
        'generationConfig': {'temperature': temperature, 'maxOutputTokens': 1500},
    }
    if declarations:
        body['tools'] = [{'functionDeclarations': declarations}]
        body['toolConfig'] = {'functionCallingConfig': {'mode': 'AUTO'}}
    return body


def clip(result):
    text = json.dumps(result, default=str, ensure_ascii=False)
    if len(text) > MAX_TOOL_CHARS:
        return {'truncated': True, 'data': text[:MAX_TOOL_CHARS]}
    return result


def run_turn(post, model, api_key, system, history, declarations, execute):
    """history: [{'role': 'user'|'model', 'parts': [{'text': ...}]}] ending with the new user message.
    post(url, headers, body) -> (status, dict). execute(name, args) -> JSON-serialisable dict.
    Returns (reply_text, [tool names called])."""
    contents = list(history)
    called = []
    url = ENDPOINT.format(model=model)
    headers = {'x-goog-api-key': api_key, 'Content-Type': 'application/json'}
    for _ in range(MAX_STEPS):
        status, data = post(url, headers, request_body(system, contents, declarations))
        if status == 429:
            raise GeminiError('The assistant is busy right now. Please try again in a minute.')
        if status in (400, 401, 403) and 'API key' in json.dumps(data):
            raise GeminiError('The assistant is not set up correctly. Please contact RESCo support.')
        if status != 200:
            raise GeminiError('The assistant could not answer just now. Please try again.')
        cands = data.get('candidates') or []
        if not cands:
            block = (data.get('promptFeedback') or {}).get('blockReason')
            raise GeminiError('I cannot help with that request.' if block else 'The assistant gave no answer. Please rephrase.')
        content = cands[0].get('content') or {}
        parts = content.get('parts') or []
        calls = [p['functionCall'] for p in parts if 'functionCall' in p]
        if not calls:
            text = ''.join(p.get('text', '') for p in parts if not p.get('thought')).strip()
            if not text:
                raise GeminiError('The assistant gave no answer. Please rephrase.')
            return text[:MAX_REPLY_CHARS], called
        contents.append({'role': 'model', 'parts': parts})   # keep the model turn exactly as sent (thought signatures)
        responses = []
        for c in calls:
            name = c.get('name', '')
            called.append(name)
            try:
                out = execute(name, c.get('args') or {})
            except Exception as e:  # noqa: BLE001 - tool errors go back to the model, not to the customer
                out = {'error': str(e)[:300]}
            responses.append({'functionResponse': {'name': name, 'response': {'result': clip(out)}}})
        contents.append({'role': 'user', 'parts': responses})
    raise GeminiError('That took too many steps. Please ask a simpler question.')
