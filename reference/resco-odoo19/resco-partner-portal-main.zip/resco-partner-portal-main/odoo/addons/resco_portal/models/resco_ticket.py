from markupsafe import Markup

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import plaintext2html

TICKET_STATES = [('new', 'New'), ('in_progress', 'In Progress'), ('waiting_customer', 'Waiting for Customer'),
                 ('resolved', 'Resolved'), ('closed', 'Closed')]
SOURCES = [('portal', 'Portal form'), ('sam_message', 'Message to account manager'), ('ai_chat', 'AI chat')]


class RescoTicketCategory(models.Model):
    """Concern topic chosen by the customer (FR-WEB-018). It decides who receives the ticket (HLP-002)."""
    _name = 'resco.ticket.category'
    _description = 'Support Ticket Category'
    _order = 'sequence, name'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    route_to_sam = fields.Boolean('Send to the account manager', default=False,
                                  help="The ticket goes to the account's Strategic Account Manager when there is one.")
    default_user_id = fields.Many2one('res.users', 'Support Owner', domain=[('share', '=', False)],
                                      help='Receives the ticket when no account manager applies.')
    notify_emails = fields.Char('Also Notify', help='Comma-separated addresses, for a shared support mailbox.')
    sam_message = fields.Boolean('Is the message to account manager', default=False)


class RescoTicket(models.Model):
    _name = 'resco.ticket'
    _description = 'Support Ticket'
    _inherit = ['mail.thread']
    _order = 'id desc'

    name = fields.Char('Reference', readonly=True, copy=False, default='/', index=True)
    subject = fields.Char(required=True)
    description = fields.Text(readonly=True)
    account_id = fields.Many2one('resco.account', 'Account', required=True, index=True, ondelete='restrict')
    csin = fields.Char(related='account_id.csin', store=True)
    company_partner_id = fields.Many2one('res.partner', 'Company', index=True)
    user_id = fields.Many2one('res.users', 'Raised By', readonly=True, index=True, ondelete='restrict')
    category_id = fields.Many2one('resco.ticket.category', 'Category', required=True, tracking=True)
    state = fields.Selection(TICKET_STATES, default='new', required=True, tracking=True, index=True)
    assigned_user_id = fields.Many2one('res.users', 'Assigned To', tracking=True, domain=[('share', '=', False)], index=True)
    source = fields.Selection(SOURCES, default='portal', required=True)
    chat_session_id = fields.Many2one('resco.chat.session', 'From Chat', readonly=True, ondelete='set null')
    last_activity = fields.Datetime(default=fields.Datetime.now, index=True)
    closed_on = fields.Datetime(readonly=True)
    state_label = fields.Char(compute='_compute_state_label')

    @api.depends('state')
    def _compute_state_label(self):
        labels = dict(TICKET_STATES)
        for t in self:
            t.state_label = labels.get(t.state, '')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('name') or vals['name'] == '/':
                vals['name'] = self.env['ir.sequence'].sudo().next_by_code('resco.ticket') or '/'
        return super().create(vals_list)

    # ------------------------------------------------------------------ routing (HLP-002)
    def _route(self):
        """Pick the assignee: the account manager for categories that ask for it, else the category owner."""
        self.ensure_one()
        cat, acc = self.category_id, self.account_id
        if (cat.route_to_sam or cat.sam_message) and acc.sam_id:
            return acc.sam_id
        return cat.default_user_id

    def _notify_emails(self):
        self.ensure_one()
        emails = []
        for raw in (self.category_id.notify_emails,
                    self.env['ir.config_parameter'].sudo().get_param('resco_portal.support_notify_emails')):
            emails += [e.strip() for e in (raw or '').replace(';', ',').split(',') if e.strip()]
        sam = self.account_id.sam_email
        if not self.assigned_user_id and sam and (self.category_id.route_to_sam or self.category_id.sam_message):
            emails.append(sam)
        return ','.join(dict.fromkeys(emails))

    @api.model
    def _open_from_portal(self, user, account, category, subject, description, files=None, source='portal', chat=None):
        """Create a ticket for a portal user. The caller has checked that the user may use the account."""
        subject = (subject or '').strip()[:200]
        description = (description or '').strip()[:5000]
        if not subject or not description:
            raise UserError(_('Please give the ticket a subject and describe your concern.'))
        if category.sam_message:
            source = 'sam_message'
        ticket = self.sudo().create({
            'subject': subject, 'description': description, 'account_id': account.id,
            'company_partner_id': user.partner_id.commercial_partner_id.id, 'user_id': user.id,
            'category_id': category.id, 'source': source, 'chat_session_id': chat.id if chat else False})
        owner = ticket._route()
        if owner:
            ticket.assigned_user_id = owner
            ticket.message_subscribe(partner_ids=owner.partner_id.ids)
        ticket.message_post(body=plaintext2html(description), author_id=user.partner_id.id, message_type='comment',
                            subtype_xmlid='mail.mt_comment', attachment_ids=ticket._attach(files or []).ids)
        self.env['resco.event.log']._log('ticket', user=user, account=account, ref=ticket.name, detail=f'{category.name}: {subject}')
        ticket._send_template('mail_template_ticket_received', partner=user.partner_id)
        staff = ticket._notify_emails()
        if staff:
            ticket._send_template('mail_template_ticket_staff', email_to=staff)
        return ticket

    def _attach(self, files):
        """files: [{'name', 'mimetype', 'data'(base64 bytes)}] already checked by lib.payment_rules."""
        self.ensure_one()
        return self.env['ir.attachment'].sudo().create([{
            'name': f['name'], 'mimetype': f['mimetype'], 'datas': f['data'], 'res_model': self._name,
            'res_id': self.id} for f in files])

    def _send_template(self, xmlid, partner=None, email_to=None):
        template = self.env.ref(f'resco_portal.{xmlid}', raise_if_not_found=False)
        if not template:
            return
        values = {'email_to': email_to} if email_to else {'recipient_ids': [(6, 0, partner.ids)], 'email_to': False}
        for t in self:
            template.sudo().send_mail(t.id, force_send=False, email_values=values, email_layout_xmlid='mail.mail_notification_light')

    # ------------------------------------------------------------------ conversation
    def _public_messages(self):
        """What the customer may see: customer and staff replies, never internal notes or tracking changes."""
        self.ensure_one()
        note = self.env.ref('mail.mt_note')
        return self.sudo().message_ids.filtered(
            lambda m: m.message_type == 'comment' and m.subtype_id and m.subtype_id != note).sorted('id')

    def _customer_reply(self, user, text, files=None):
        self.ensure_one()
        if self.state == 'closed':
            raise UserError(_('This ticket is closed. Please open a new ticket.'))
        text = (text or '').strip()[:5000]
        if not text and not files:
            raise UserError(_('Write a message or attach a file.'))
        msg = self.sudo().message_post(body=plaintext2html(text or '-'), author_id=user.partner_id.id, message_type='comment',
                                       subtype_xmlid='mail.mt_comment', attachment_ids=self._attach(files or []).ids)
        vals = {'last_activity': fields.Datetime.now()}
        if self.state in ('waiting_customer', 'resolved', 'new'):
            vals['state'] = 'in_progress' if self.assigned_user_id else 'new'
        self.sudo().write(vals)
        return msg

    def message_post(self, **kwargs):
        msg = super().message_post(**kwargs)
        author = msg.author_id
        is_staff_reply = (msg.message_type == 'comment' and msg.subtype_id == self.env.ref('mail.mt_comment')
                          and author and not author.user_ids.filtered('share') and author.user_ids)
        for t in self:
            t.sudo().last_activity = fields.Datetime.now()
            if is_staff_reply and t.user_id:
                t.with_context(reply_body=msg.body, reply_author=author.name)._send_template(
                    'mail_template_ticket_reply', partner=t.user_id.partner_id)
                if t.state in ('new', 'in_progress'):
                    t.sudo().state = 'waiting_customer'
        return msg

    def write(self, vals):
        res = super().write(vals)
        if 'state' in vals:
            for t in self:
                if vals['state'] in ('resolved', 'closed'):
                    t.sudo().closed_on = fields.Datetime.now() if vals['state'] == 'closed' else False
                    if t.user_id:
                        t._send_template('mail_template_ticket_status', partner=t.user_id.partner_id)
        return res

    # staff buttons
    def action_take(self):
        self.write({'assigned_user_id': self.env.user.id, 'state': 'in_progress'})

    def action_resolve(self):
        self.write({'state': 'resolved'})

    def action_close(self):
        self.write({'state': 'closed'})

    def action_reopen(self):
        self.write({'state': 'in_progress'})

    @api.model
    def _cron_close_resolved(self, days=7):
        """Resolved tickets with no reply from the customer for a week are closed."""
        limit = fields.Datetime.subtract(fields.Datetime.now(), days=days)
        old = self.search([('state', '=', 'resolved'), ('last_activity', '<', limit)])
        old.write({'state': 'closed'})
        return len(old)
