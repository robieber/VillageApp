from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

from ..lib.lifecycle import parse_offsets, reminder_due

PAYMENT_STATUS = [('unpaid', 'Unpaid'), ('partial', 'Partially Paid'), ('paid', 'Paid'), ('overdue', 'Overdue')]


class RescoBill(models.Model):
    """A bill loaded from CMS-RES. Key: account + year + month. A re-load replaces it and archives the old version."""
    _name = 'resco.bill'
    _description = 'RESCo Bill'
    _inherit = ['mail.thread']
    _order = 'year desc, month desc, account_id'

    account_id = fields.Many2one('resco.account', required=True, index=True, ondelete='restrict')
    csin = fields.Char(related='account_id.csin', store=True, index=True)
    customer_name = fields.Char(related='account_id.name', string='Customer')
    year = fields.Integer('Bill Year', required=True, index=True)
    month = fields.Integer('Bill Month', required=True, index=True)
    period_label = fields.Char(compute='_compute_period_label', store=True)
    bill_number = fields.Char(required=True, index=True)
    due_date = fields.Date(required=True)
    total_amount = fields.Float(digits=(14, 2), required=True)
    payment_status = fields.Selection(PAYMENT_STATUS, required=True, default='unpaid', tracking=True)
    pdf = fields.Binary('Bill PDF', attachment=True)
    pdf_name = fields.Char('PDF File Name')
    line_ids = fields.One2many('resco.bill.line', 'bill_id', string='Lines')
    version = fields.Integer(default=1, readonly=True)
    active = fields.Boolean(default=True, help='Superseded versions are archived, not deleted, for audit.')
    replaces_id = fields.Many2one('resco.bill', 'Replaces', readonly=True, index=True)
    superseded_on = fields.Datetime(readonly=True)
    batch_id = fields.Many2one('resco.upload.batch', 'Loaded By Batch', readonly=True, index=True)
    released_on = fields.Datetime('Released On', default=fields.Datetime.now, readonly=True)
    reminder_sent_on = fields.Date(copy=False)

    # Snapshot of what CMS-RES sent with this bill (File 1)
    bill_key = fields.Char(index=True, help='CSIN-YYYYMM-BILLNO from CMS-RES; payment status updates refer to it.')
    bill_date = fields.Date()
    period_from = fields.Date('Billing Period From')
    period_to = fields.Date('Billing Period To')
    service_address = fields.Char()
    pricing_product = fields.Char()
    contracted_capacity_kw = fields.Float(digits=(12, 2))
    energy_kwh = fields.Float('Energy (kWh)', digits=(14, 2))
    meq_kwh = fields.Float('MEQ (kWh)', digits=(14, 2))
    change_in_energy_kwh = fields.Float('Change in Energy (kWh)', digits=(14, 2))
    peak_kwh = fields.Float(digits=(14, 2))
    offpeak_kwh = fields.Float(digits=(14, 2))
    peak_demand_kw = fields.Float(digits=(12, 2))
    current_charges = fields.Float(digits=(16, 2))
    vat_amount = fields.Float('VAT', digits=(16, 2))
    previous_balance = fields.Float(digits=(16, 2))
    adjustments = fields.Float(digits=(16, 2))
    is_revised = fields.Boolean('Revised Bill')
    supersedes_key = fields.Char('Supersedes Bill Key')
    source_system = fields.Char()
    extract_batch_id = fields.Char('CMS-RES Batch')
    extract_timestamp = fields.Datetime('CMS-RES Extract Time')
    # Payment status feed (File 4)
    amount_paid = fields.Float(digits=(16, 2))
    outstanding_balance = fields.Float(digits=(16, 2))
    last_payment_date = fields.Date()
    status_as_of = fields.Datetime('Status As Of')

    _month_range = models.Constraint('CHECK(month BETWEEN 1 AND 12)', 'Bill month must be 1 to 12.')
    _amount_positive = models.Constraint('CHECK(total_amount >= 0)', 'Bill total cannot be negative.')

    def init(self):
        # One active bill per account and month; archived versions are exempt.
        self.env.cr.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS resco_bill_active_key
            ON resco_bill (account_id, year, month) WHERE active
        """)

    @api.depends('year', 'month')
    def _compute_period_label(self):
        for b in self:
            b.period_label = f'{b.year}-{b.month:02d}' if b.year and b.month else False

    @api.depends('bill_number', 'period_label', 'version')
    def _compute_display_name(self):
        for b in self:
            b.display_name = f'{b.bill_number} ({b.period_label})' + (f' v{b.version}' if b.version > 1 else '')

    def _recipients(self):
        """Portal users of the account who have not unsubscribed."""
        self.ensure_one()
        access = self.env['resco.account.access'].sudo().search([('account_id', '=', self.account_id.id), ('active', '=', True)])
        return access.user_id.filtered(lambda u: u.active and not u.resco_email_optout)

    def _notify_released(self):
        """NOT-001. Called only for newly loaded bills, not for replacements."""
        template = self.env.ref('resco_portal.mail_template_bill_released', raise_if_not_found=False)
        if not template:
            return
        today = fields.Date.context_today(self)
        for bill in self:
            if bill.bill_date and (today - bill.bill_date).days > 45:
                continue            # back-loaded history: do not email customers about old bills
            for user in bill._recipients():
                template.sudo().send_mail(bill.id, force_send=False, email_values={
                    'recipient_ids': [(6, 0, user.partner_id.ids)], 'email_to': False},
                    email_layout_xmlid='mail.mail_notification_light')

    @api.model
    def _cron_due_reminders(self, today=None):
        """NOT-002. Offsets come from the system parameter resco_portal.reminder_offsets, e.g. "5,1,-1"."""
        today = today or fields.Date.context_today(self)
        offsets = parse_offsets(self.env['ir.config_parameter'].sudo().get_param('resco_portal.reminder_offsets', '5,1,-1'))
        template = self.env.ref('resco_portal.mail_template_due_reminder', raise_if_not_found=False)
        if not offsets or not template:
            return 0
        sent = 0
        for bill in self.search([('payment_status', '!=', 'paid')]):
            if bill.reminder_sent_on == today or not reminder_due(today, bill.due_date, offsets):
                continue
            for user in bill._recipients():
                template.sudo().send_mail(bill.id, force_send=False, email_values={
                    'recipient_ids': [(6, 0, user.partner_id.ids)], 'email_to': False},
                    email_layout_xmlid='mail.mail_notification_light')
                sent += 1
            bill.reminder_sent_on = today
        return sent

    def write(self, vals):
        protected = {'account_id', 'year', 'month', 'bill_number', 'total_amount', 'due_date', 'pdf', 'line_ids'}
        if protected & set(vals) and not self.env.context.get('resco_loader') and not self.env.user.has_group('resco_portal.group_resco_admin'):
            raise ValidationError(_('Bills are loaded from CMS-RES. Re-load the bill instead of editing it.'))
        return super().write(vals)


class RescoBillLine(models.Model):
    """A cost component of a bill (File 2). Feeds the billing history chart."""
    _name = 'resco.bill.line'
    _description = 'RESCo Bill Cost Component'
    _order = 'bill_id, sequence, id'

    bill_id = fields.Many2one('resco.bill', required=True, index=True, ondelete='cascade')
    account_id = fields.Many2one(related='bill_id.account_id', store=True, index=True)
    year = fields.Integer(related='bill_id.year', store=True, index=True)
    month = fields.Integer(related='bill_id.month', store=True, index=True)
    active = fields.Boolean(related='bill_id.active', store=True, index=True)
    sequence = fields.Integer('Sort Order', default=10)
    code = fields.Char('Component Code', required=True)
    component = fields.Char('Component', required=True, help='Label shown in the chart legend.')
    quantity = fields.Float(digits=(14, 2))
    uom = fields.Selection([('KWH', 'kWh'), ('KW', 'kW'), ('FIXED', 'Fixed')], string='Unit')
    rate = fields.Float(digits=(12, 6))
    amount = fields.Float(digits=(16, 2), required=True)
