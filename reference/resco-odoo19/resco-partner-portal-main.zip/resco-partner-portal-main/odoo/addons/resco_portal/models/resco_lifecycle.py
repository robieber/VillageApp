import logging

from odoo import api, fields, models, _

from ..lib.lifecycle import deactivation_date, deactivation_state

_logger = logging.getLogger(__name__)


class ResUsersLifecycle(models.Model):
    _inherit = 'res.users'

    resco_deactivation_date = fields.Date(compute='_compute_resco_deactivation_date', string='Scheduled Deactivation')

    def _resco_last_bill_date(self):
        self.ensure_one()
        accounts = self._resco_accounts()
        if not accounts:
            return None
        bill = self.env['resco.bill'].sudo().search([('account_id', 'in', accounts.ids)], order='released_on desc', limit=1)
        return bill.released_on.date() if bill else None

    def _compute_resco_deactivation_date(self):
        for u in self:
            if not u.share or not u.resco_access_ids:
                u.resco_deactivation_date = False
                continue
            last = u.resco_last_activity.date() if u.resco_last_activity else None
            u.resco_deactivation_date = deactivation_date(u._resco_last_bill_date(), last, u.create_date.date())

    @api.model
    def _cron_resco_lifecycle(self, today=None):
        """FR-WEB-066. Warn 2 weeks ahead, then deactivate: 2 months after the last bill, or 3 months of inactivity."""
        today = today or fields.Date.context_today(self)
        template = self.env.ref('resco_portal.mail_template_deactivation_warning', raise_if_not_found=False)
        users = self.sudo().search([('share', '=', True), ('active', '=', True), ('resco_access_ids', '!=', False)])
        warned = deactivated = 0
        for u in users:
            dd = u.resco_deactivation_date or None
            action = deactivation_state(today, dd, u.resco_deactivation_warned_on)
            if action == 'deactivate':
                u.write({'active': False, 'resco_deactivation_reason': f'Auto-deactivated on {today}'})
                self.env['resco.event.log']._log('user_deactivated', user=u, detail=f'scheduled date {dd}')
                deactivated += 1
            elif action == 'warn' and template:
                template.with_context(deactivation_date=dd).send_mail(u.id, force_send=False)
                u.resco_deactivation_warned_on = today
                self.env['resco.event.log']._log('user_warned', user=u, detail=f'deactivation date {dd}')
                warned += 1
        _logger.info('RESCo lifecycle: %s warned, %s deactivated', warned, deactivated)
        return warned, deactivated
