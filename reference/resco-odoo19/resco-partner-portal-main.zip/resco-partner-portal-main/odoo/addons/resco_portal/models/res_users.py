from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class ResUsers(models.Model):
    _inherit = 'res.users'

    resco_company_role = fields.Selection([
        ('admin', 'Customer Administrator'),
        ('billing', 'Billing / Payments'),
        ('viewer', 'Viewer'),
    ], string='Portal Role', default='viewer',
        help='Customer Administrators can see the other users of their company and the accounts each can access.')
    resco_designation = fields.Char('Designation')
    resco_landline = fields.Char('Landline Number')
    resco_gender = fields.Selection([('female', 'Female'), ('male', 'Male'), ('other', 'Other / prefer not to say')], string='Gender')
    resco_birthday = fields.Date('Birthday')
    resco_access_ids = fields.One2many('resco.account.access', 'user_id', string='Account Access')
    resco_account_count = fields.Integer(compute='_compute_resco_account_count', string='Accounts')
    resco_last_activity = fields.Datetime('Last Portal Activity', copy=False)
    resco_deactivation_warned_on = fields.Date(copy=False)
    resco_deactivation_reason = fields.Char(copy=False)

    # Email preferences (FR-WEB-047). Security and bill notices are always sent.
    resco_email_optout = fields.Boolean('Unsubscribed from optional emails', copy=False)
    resco_email_optout_reason = fields.Char('Reason for unsubscribing', copy=False)

    @api.depends('resco_access_ids.active')
    def _compute_resco_account_count(self):
        for u in self:
            u.resco_account_count = len(u.resco_access_ids.filtered('active'))

    def _resco_accounts(self):
        """Accounts this user may see. The only place that decides it; the API and record rules both follow it."""
        self.ensure_one()
        return self.env['resco.account.access'].sudo().search([
            ('user_id', '=', self.id), ('active', '=', True), ('account_id.active', '=', True),
        ]).account_id

    def _resco_touch_activity(self):
        """Record portal activity at most once per hour to avoid write storms."""
        now = fields.Datetime.now()
        for u in self.sudo():
            if not u.resco_last_activity or (now - u.resco_last_activity).total_seconds() > 3600:
                u.resco_last_activity = now
