import json
import logging

from odoo import api, fields, models

# Every portal event is also written to the application log as one JSON line, so it reaches the central log store and
# cannot be changed by someone who gains access to the database.
_audit = logging.getLogger('resco.audit')

EVENT_TYPES = [
    ('login', 'Login'), ('login_failed', 'Login failed'), ('logout', 'Logout'),
    ('download', 'Download'), ('upload', 'Upload'), ('bill_loaded', 'Bill loaded'), ('bill_replaced', 'Bill replaced'),
    ('submission', 'Submission'), ('approval', 'Approval'), ('content', 'Content change'),
    ('access_granted', 'Access granted'), ('access_changed', 'Access changed'), ('access_revoked', 'Access revoked'),
    ('user_deactivated', 'User deactivated'), ('user_warned', 'Deactivation warning'),
    ('ticket', 'Support ticket'), ('chat', 'AI chat'), ('integration', 'Integration'), ('error', 'Error'),
]


class RescoEventLog(models.Model):
    """Append-only trail for AUD-001 and the user-activity reports (FR-WEB-086 to 088)."""
    _name = 'resco.event.log'
    _description = 'Portal Event Log'
    _order = 'id desc'

    event_type = fields.Selection(EVENT_TYPES, required=True, index=True)
    user_id = fields.Many2one('res.users', index=True, ondelete='set null')
    user_login = fields.Char(index=True)
    account_id = fields.Many2one('resco.account', index=True, ondelete='set null')
    ref = fields.Char('Reference')
    detail = fields.Text()
    ip = fields.Char('IP Address')
    create_date = fields.Datetime('When', readonly=True, index=True)

    @api.model
    def _log(self, event_type, user=None, account=None, detail='', ref='', ip=None, login=None):
        user = user or (self.env.user if not self.env.user._is_public() else None)
        rec = self.sudo().create({
            'event_type': event_type, 'user_id': user.id if user else False,
            'user_login': login or (user.login if user else False),
            'account_id': account.id if account else False, 'ref': ref or False,
            'detail': detail or False, 'ip': ip or False,
        })
        _audit.info('AUDIT %s', json.dumps({
            'event': event_type, 'user': rec.user_login or '', 'account': account.csin if account else '',
            'ref': ref or '', 'ip': ip or '', 'detail': (detail or '')[:300]}, ensure_ascii=False))
        return rec
