from odoo import fields, models


class RescoEnergyInterval(models.Model):
    """Interval energy from the CMS-RES hourly file. Feeds the daily and hourly Energy Dashboard charts.

    Rows are written by the loader with a bulk upsert; one row per account and interval start.
    """
    _name = 'resco.energy.interval'
    _description = 'RESCo Interval Energy'
    _order = 'account_id, interval_start'

    account_id = fields.Many2one('resco.account', required=True, index=True, ondelete='cascade')
    interval_start = fields.Datetime(required=True, index=True, help='Stored in UTC; Philippine time is UTC+8.')
    kwh = fields.Float('kWh', digits=(14, 4), required=True)
    kw_demand = fields.Float('kW Demand', digits=(12, 4))
    batch_id = fields.Many2one('resco.upload.batch', ondelete='set null', index=True)

    _account_interval = models.Constraint('UNIQUE(account_id, interval_start)', 'One reading per account and interval.')
