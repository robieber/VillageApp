import base64
import logging

from odoo import api, fields, models, _
from odoo.exceptions import UserError

from ..lib import cms_files

_logger = logging.getLogger(__name__)


class RescoUploadBatch(models.Model):
    """One load of CMS-RES billing files, from SFTP or a manual upload."""
    _name = 'resco.upload.batch'
    _description = 'Billing Upload Batch'
    _inherit = ['mail.thread']
    _order = 'id desc'

    name = fields.Char(readonly=True, copy=False, default=lambda s: _('New'))
    channel = fields.Selection([('sftp', 'SFTP'), ('manual', 'Manual upload')], required=True, readonly=True)
    source_name = fields.Char('Source', readonly=True, help='Batch name on the SFTP server or the uploaded file name.')
    user_id = fields.Many2one('res.users', 'Loaded By', readonly=True, default=lambda s: s.env.user)
    state = fields.Selection([('done', 'Loaded'), ('partial', 'Loaded with errors'), ('failed', 'Failed')],
                             readonly=True, default='failed', tracking=True)
    file_names = fields.Text('Files', readonly=True)
    result_ids = fields.One2many('resco.upload.result', 'batch_id', string='Results', readonly=True)
    bill_ids = fields.One2many('resco.bill', 'batch_id', string='Bills', readonly=True)
    n_loaded = fields.Integer('New bills', readonly=True)
    n_replaced = fields.Integer('Replaced', readonly=True)
    n_rejected = fields.Integer('Rejected', readonly=True)
    n_skipped = fields.Integer('Skipped', readonly=True)
    n_payments = fields.Integer('Payment updates', readonly=True)
    n_intervals = fields.Integer('Hourly readings', readonly=True)
    n_accounts = fields.Integer('Accounts created or updated', readonly=True)
    summary = fields.Text(readonly=True)

    # ------------------------------------------------------------------
    # Preview and processing
    # ------------------------------------------------------------------
    @api.model
    def _known_accounts(self):
        return {a.csin: a.name for a in self.env['resco.account'].sudo().search([])}

    @api.model
    def _analyse(self, files):
        """Validate without writing anything. Returns (Parsed, pdfs, {(csin, year, month): active bill})."""
        Bill = self.env['resco.bill'].sudo()

        class _Keys:
            def __contains__(self, key):
                return bool(Bill.search_count([('bill_key', '=', key), ('active', '=', True)]))

        parsed, pdfs = cms_files.parse_batch(files, self._known_accounts(), existing_keys=_Keys())
        existing = {}
        for b in parsed.bills:
            old = Bill.search([('csin', '=', b.csin), ('year', '=', b.year), ('month', '=', b.month)], limit=1)
            if old:
                existing[b.key] = old
        return parsed, pdfs, existing

    @api.model
    def preview(self, files):
        parsed, _pdfs, existing = self._analyse(files)
        return {
            'new': [b for b in parsed.bills if b.key not in existing],
            'replace': [(b, existing[b.key]) for b in parsed.bills if b.key in existing],
            'payments': len(parsed.payments), 'intervals': len(parsed.intervals), 'accounts': len(parsed.accounts),
            'errors': parsed.errors, 'warnings': parsed.warnings,
        }

    @staticmethod
    def _f(v):
        return float(v) if v is not None else 0.0

    def _bill_vals(self, b, account, pdf, old, batch):
        f = b.fields
        vals = {k: v for k, v in f.items() if k in (
            'bill_number', 'bill_date', 'period_from', 'period_to', 'due_date', 'service_address', 'pricing_product',
            'payment_status', 'is_revised', 'supersedes_key', 'source_system', 'extract_batch_id', 'extract_timestamp')}
        for k in ('contracted_capacity_kw', 'energy_kwh', 'meq_kwh', 'change_in_energy_kwh', 'peak_kwh', 'offpeak_kwh',
                  'peak_demand_kw', 'current_charges', 'vat_amount', 'previous_balance', 'adjustments'):
            vals[k] = self._f(f.get(k))
        vals.update({
            'account_id': account.id, 'year': b.year, 'month': b.month, 'bill_key': b.bill_key,
            'total_amount': float(f['total_amount']), 'pdf': base64.b64encode(pdf), 'pdf_name': b.pdf_file_name,
            'version': old.version + 1 if old else 1, 'replaces_id': old.id if old else False, 'batch_id': batch.id,
            'line_ids': [(0, 0, {'code': c.code, 'component': c.name, 'amount': float(c.amount), 'sequence': c.sort_order,
                                 'quantity': self._f(c.quantity), 'uom': c.uom or False, 'rate': self._f(c.rate)})
                         for c in b.components],
        })
        return vals

    def _upsert_intervals(self, intervals, accounts_by_csin, batch):
        """Bulk insert or update of hourly readings; returns (rows, accounts)."""
        uid = self.env.uid
        rows = [(accounts_by_csin[csin].id, start, float(kwh), float(kw) if kw is not None else None)
                for csin, start, kwh, kw in intervals]
        cr = self.env.cr
        for i in range(0, len(rows), 1000):
            chunk = rows[i:i + 1000]
            values = ','.join(["(%s,%s,%s,%s,%s,%s,now() at time zone 'utc',%s,now() at time zone 'utc')"] * len(chunk))
            params = []
            for acc, start, kwh, kw in chunk:
                params += [acc, start, kwh, kw, batch.id, uid, uid]
            cr.execute(
                'INSERT INTO resco_energy_interval (account_id, interval_start, kwh, kw_demand, batch_id, create_uid, '
                'create_date, write_uid, write_date) VALUES ' + values +
                ' ON CONFLICT (account_id, interval_start) DO UPDATE SET kwh = EXCLUDED.kwh, kw_demand = EXCLUDED.kw_demand, '
                'batch_id = EXCLUDED.batch_id, write_uid = EXCLUDED.write_uid, write_date = EXCLUDED.write_date', params)
        self.env['resco.energy.interval'].invalidate_model()
        return len(rows), len({r[0] for r in rows})

    @api.model
    def load(self, channel, files, overwrite, source_name='', user=None, initial_password=None):
        """Load a batch. files: {name: bytes} of the CSVs and PDFs.
        overwrite=False skips bills that already exist (manual flow before the user confirms replacements)."""
        user = user or self.env.user
        parsed, pdfs, existing = self._analyse(files)
        batch = self.sudo().create({
            'channel': channel, 'source_name': source_name, 'user_id': user.id,
            'file_names': '\n'.join(sorted(files)),
            'name': self.env['ir.sequence'].sudo().next_by_code('resco.upload.batch'),
        })
        for name, data in files.items():
            if name.lower().endswith('.csv'):
                self.env['ir.attachment'].sudo().create({'name': name, 'datas': base64.b64encode(data),
                                                         'res_model': self._name, 'res_id': batch.id})
        Result = self.env['resco.upload.result'].sudo()
        Bill = self.env['resco.bill'].sudo().with_context(resco_loader=True)
        Account = self.env['resco.account'].sudo()
        counts = {'loaded': 0, 'replaced': 0, 'rejected': 0, 'skipped': 0, 'payments': 0, 'intervals': 0, 'accounts': 0}

        for issue in parsed.errors:
            Result.create({'batch_id': batch.id, 'status': 'rejected', 'row': issue.row, 'file': issue.file,
                           'bill_key': issue.key, 'message': issue.message})
            counts['rejected'] += 1
        for issue in parsed.warnings:
            Result.create({'batch_id': batch.id, 'status': 'warning', 'row': issue.row, 'file': issue.file,
                           'bill_key': issue.key, 'message': issue.message})

        if parsed.accounts:
            counts['accounts'] = self._apply_accounts(parsed.accounts, batch, initial_password)

        new_bills = Bill
        for b in parsed.bills:
            key_label = f'{b.csin} {b.year}-{b.month:02d}'
            old = existing.get(b.key)
            if old and not overwrite:
                counts['skipped'] += 1
                Result.create({'batch_id': batch.id, 'status': 'skipped', 'bill_key': key_label,
                               'message': _('Bill %s already exists. Not replaced because the replacement was not confirmed.', old.bill_number)})
                continue
            try:
                with self.env.cr.savepoint():
                    account = Account.search([('csin', '=', b.csin)], limit=1)
                    if old:
                        old.with_context(resco_loader=True).write({'active': False, 'superseded_on': fields.Datetime.now()})
                        old.flush_recordset()   # free the unique slot before the new row is inserted
                    bill = Bill.create(self._bill_vals(b, account, pdfs[b.pdf_file_name], old, batch))
            except Exception as e:  # noqa: BLE001 - one failing bill must not stop the batch
                _logger.exception('Bill load failed for %s', key_label)
                counts['rejected'] += 1
                Result.create({'batch_id': batch.id, 'status': 'rejected', 'bill_key': key_label, 'message': str(e)})
                continue
            if old:
                counts['replaced'] += 1
                Result.create({'batch_id': batch.id, 'status': 'replaced', 'bill_key': key_label, 'bill_id': bill.id,
                               'message': _('Replaced bill %(old)s (v%(v)s) with %(new)s. The previous version is archived.',
                                            old=old.bill_number, v=old.version, new=bill.bill_number)})
                self.env['resco.event.log']._log('bill_replaced', user=user, account=account, ref=bill.bill_number,
                                                 detail=f'{key_label} v{bill.version} via {channel}')
            else:
                counts['loaded'] += 1
                new_bills |= bill
                Result.create({'batch_id': batch.id, 'status': 'loaded', 'bill_key': key_label, 'bill_id': bill.id,
                               'message': _('Loaded bill %s.', bill.bill_number)})
                self.env['resco.event.log']._log('bill_loaded', user=user, account=account, ref=bill.bill_number,
                                                 detail=f'{key_label} via {channel}')

        # Payment status feed (File 4): CMS-RES is the authority; an older status never overwrites a newer one.
        for p in sorted(parsed.payments, key=lambda x: x['status_as_of']):
            bill = Bill.search([('bill_key', '=', p['bill_key']), ('active', '=', True)], limit=1)
            if not bill:
                counts['rejected'] += 1
                Result.create({'batch_id': batch.id, 'status': 'rejected', 'row': p['row'], 'file': p['file'],
                               'bill_key': p['bill_key'], 'message': _('The bill is not loaded in Odoo.')})
                continue
            if bill.status_as_of and p['status_as_of'] < bill.status_as_of:
                counts['skipped'] += 1
                Result.create({'batch_id': batch.id, 'status': 'skipped', 'row': p['row'], 'file': p['file'],
                               'bill_key': p['bill_key'], 'bill_id': bill.id,
                               'message': _('Older than the status already held (as of %s).', bill.status_as_of)})
                continue
            bill.write({'payment_status': p['payment_status'], 'amount_paid': float(p['amount_paid']),
                        'outstanding_balance': float(p['outstanding']), 'last_payment_date': p['last_payment_date'],
                        'status_as_of': p['status_as_of']})
            counts['payments'] += 1
            Result.create({'batch_id': batch.id, 'status': 'updated', 'row': p['row'], 'file': p['file'],
                           'bill_key': p['bill_key'], 'bill_id': bill.id,
                           'message': _('Payment status set to %s.', bill.payment_status)})

        # Interval energy (hourly file)
        if parsed.intervals:
            accounts = {a.csin: a for a in Account.search([('csin', 'in', list({i[0] for i in parsed.intervals}))])}
            n_rows, n_acc = self._upsert_intervals(parsed.intervals, accounts, batch)
            counts['intervals'] = n_rows
            Result.create({'batch_id': batch.id, 'status': 'updated',
                           'message': _('%(n)s hourly readings loaded for %(a)s account(s).', n=n_rows, a=n_acc)})

        ok = sum(counts[k] for k in ('loaded', 'replaced', 'payments', 'intervals', 'accounts'))
        state = 'failed' if not ok else ('partial' if counts['rejected'] or counts['skipped'] else 'done')
        batch.write({'n_loaded': counts['loaded'], 'n_replaced': counts['replaced'], 'n_rejected': counts['rejected'],
                     'n_skipped': counts['skipped'], 'n_payments': counts['payments'], 'n_intervals': counts['intervals'],
                     'n_accounts': counts['accounts'],
                     'state': state,
                     'summary': _('%(l)s new bills, %(r)s replaced, %(p)s payment updates, %(i)s hourly readings, '
                                  '%(x)s rejected, %(s)s skipped, %(a)s accounts created or updated.', l=counts['loaded'],
                                  r=counts['replaced'], p=counts['payments'], i=counts['intervals'], x=counts['rejected'],
                                  s=counts['skipped'], a=counts['accounts'])})
        self.env['resco.event.log']._log('upload', user=user, ref=batch.name, detail=batch.summary)
        new_bills._notify_released()
        if state != 'done':
            batch._notify_admins()
        return batch

    def _apply_accounts(self, accounts, batch, initial_password=None):
        """Create or update companies, accounts, account manager details and the primary portal contact.
        Odoo is the master for these records, so a file that names an existing CSIN updates it. One bad row never
        stops the others. Returns the number of accounts created or updated."""
        Partner = self.env['res.partner'].sudo()
        Account = self.env['resco.account'].sudo().with_context(active_test=False)
        Users = self.env['res.users'].sudo().with_context(active_test=False, no_reset_password=True)
        Access = self.env['resco.account.access'].sudo().with_context(active_test=False)
        Result = self.env['resco.upload.result'].sudo()
        portal = self.env.ref('base.group_portal')
        done = 0
        for a in accounts:
            try:
                with self.env.cr.savepoint():
                    company = Partner.browse()
                    if a['company_ref']:
                        company = Partner.search([('is_company', '=', True), ('ref', '=', a['company_ref'])], limit=1)
                    if not company:
                        company = Partner.search([('is_company', '=', True), ('name', '=ilike', a['company'])], limit=1)
                    if not company:
                        company = Partner.create({'name': a['company'], 'is_company': True, 'ref': a['company_ref'] or False})
                    elif a['company_ref'] and not company.ref:
                        company.ref = a['company_ref']
                    sam = Users.browse()
                    if a['sam_email']:
                        sam = Users.search([('login', '=', a['sam_email']), ('share', '=', False)], limit=1)
                    vals = {'name': a['name'], 'partner_id': company.id, 'service_address': a['address'],
                            'pricing_product': a['product'], 'active': a['active'], 'sam_id': sam.id or False,
                            'sam_name': a['sam_name'], 'sam_email': a['sam_email'],
                            'contract_start': a['start'] or False, 'contract_end': a['end'] or False}
                    if a['capacity'] is not None:
                        vals['contracted_capacity_kw'] = float(a['capacity'])
                    if a['meq'] is not None:
                        vals['meq_kwh'] = float(a['meq'])
                    account = Account.search([('csin', '=', a['csin'])], limit=1)
                    verb = 'Updated'
                    if account:
                        account.write(vals)
                    else:
                        account = Account.create(dict(vals, csin=a['csin']))
                        verb = 'Created'
                    note = ''
                    email = a['contact_email']
                    if email:
                        user = Users.search([('login', '=', email)], limit=1)
                        if user and user.partner_id.commercial_partner_id != company.commercial_partner_id:
                            note = _(' The contact %s already belongs to another company, so no access was granted.', email)
                        else:
                            if not user:
                                contact = Partner.create({'name': a['contact_name'] or email, 'email': email,
                                                          'phone': a['contact_mobile'] or False, 'parent_id': company.id})
                                user = Users.create({'login': email, 'partner_id': contact.id,
                                                     'group_ids': [(6, 0, portal.ids)], 'resco_company_role': 'admin'})
                                if initial_password:
                                    user.password = initial_password
                                note = _(' Portal user %s created.', email)
                            if not Access.search([('user_id', '=', user.id), ('account_id', '=', account.id)]):
                                Access.create({'user_id': user.id, 'account_id': account.id})
                    Result.create({'batch_id': batch.id, 'status': 'updated', 'file': a['file'], 'row': a['row'],
                                   'bill_key': a['csin'],
                                   'message': _('%(verb)s account %(name)s.', verb=verb, name=account.name) + note})
                    done += 1
            except Exception as e:  # noqa: BLE001 - one failing account must not stop the batch
                _logger.exception('Account load failed for %s', a['csin'])
                Result.create({'batch_id': batch.id, 'status': 'rejected', 'file': a['file'], 'row': a['row'],
                               'bill_key': a['csin'], 'message': str(e)})
        return done

    def _notify_admins(self):
        """FR-WEB-046: tell administrators when a batch finished with problems."""
        admins = self.env.ref('resco_portal.group_resco_admin').sudo().user_ids.filtered(lambda u: u.active and u.email)
        if not admins:
            return
        for batch in self:
            body = '<p>%s</p><ul>%s</ul>' % (
                _('Billing batch %(n)s (%(c)s) finished: %(s)s', n=batch.name, c=batch.channel, s=batch.summary),
                ''.join('<li>%s %s: %s</li>' % (r.status, r.bill_key or '', r.message or '')
                        for r in batch.result_ids.filtered(lambda r: r.status in ('rejected', 'skipped'))[:20]))
            self.env['mail.mail'].sudo().create({
                'subject': _('Billing batch %(n)s: %(s)s', n=batch.name, s=batch.summary),
                'body_html': body, 'recipient_ids': [(6, 0, admins.partner_id.ids)], 'auto_delete': True,
            })

    def result_text(self):
        """Plain-text result file written back to the SFTP server."""
        self.ensure_one()
        lines = [f'Batch {self.name} ({self.channel}): {self.summary}', '']
        for r in self.result_ids:
            row = (f'{r.file} ' if r.file else '') + (f'row {r.row} ' if r.row else '')
            lines.append(f'{r.status.upper():9} {r.bill_key or "-":22} {row}{r.message or ""}')
        return '\n'.join(lines) + '\n'


class RescoUploadResult(models.Model):
    _name = 'resco.upload.result'
    _description = 'Billing Upload Result Line'
    _order = 'id'

    batch_id = fields.Many2one('resco.upload.batch', required=True, ondelete='cascade', index=True)
    status = fields.Selection([('loaded', 'Loaded'), ('replaced', 'Replaced'), ('rejected', 'Rejected'),
                               ('skipped', 'Skipped'), ('updated', 'Updated'), ('warning', 'Warning')], required=True)
    row = fields.Integer('CSV Row')
    file = fields.Char('File')
    bill_key = fields.Char('Bill (CSIN and period)')
    bill_id = fields.Many2one('resco.bill', ondelete='set null')
    message = fields.Text()
