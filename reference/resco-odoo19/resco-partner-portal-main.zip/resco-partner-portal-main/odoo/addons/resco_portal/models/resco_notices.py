from odoo import api, fields, models, _
from odoo.exceptions import UserError


class RescoPrivacyNotice(models.Model):
    """The privacy notice customers accept (FR-WEB-064/065). A new version asks everyone again."""
    _name = 'resco.privacy.notice'
    _description = 'Privacy Notice'
    _order = 'version desc'

    title = fields.Char(required=True, default='Privacy Notice')
    version = fields.Integer(required=True, copy=False, readonly=True)
    body = fields.Text('Text', required=True, help='Blank lines separate paragraphs. Plain text only.')
    active = fields.Boolean('In force', default=False, copy=False)
    published_on = fields.Datetime(readonly=True, copy=False)
    consent_count = fields.Integer(compute='_compute_consent_count')

    @api.depends()
    def _compute_consent_count(self):
        counts = {n.id: c for n, c in self.env['resco.privacy.consent']._read_group([('notice_id', 'in', self.ids)], ['notice_id'], ['__count'])}
        for n in self:
            n.consent_count = counts.get(n.id, 0)

    @api.model_create_multi
    def create(self, vals_list):
        top = self.with_context(active_test=False).search([], order='version desc', limit=1).version or 0
        for vals in vals_list:
            top += 1
            vals['version'] = top
        return super().create(vals_list)

    def action_publish(self):
        self.ensure_one()
        self.with_context(active_test=False).search([('active', '=', True)]).write({'active': False})
        self.write({'active': True, 'published_on': fields.Datetime.now()})

    def write(self, vals):
        if {'body', 'title'} & set(vals) and any(n.published_on for n in self):
            raise UserError(_('A published notice cannot be edited. Duplicate it, change the copy and publish that as a new version.'))
        return super().write(vals)

    @api.model
    def _current(self):
        return self.search([('active', '=', True)], limit=1)


class RescoPrivacyConsent(models.Model):
    """Append-only record of who accepted which version, when and from where."""
    _name = 'resco.privacy.consent'
    _description = 'Privacy Consent'
    _order = 'id desc'

    user_id = fields.Many2one('res.users', required=True, index=True, ondelete='cascade')
    user_login = fields.Char(readonly=True)
    notice_id = fields.Many2one('resco.privacy.notice', required=True, index=True, ondelete='restrict')
    version = fields.Integer(related='notice_id.version', store=True)
    accepted_on = fields.Datetime(default=fields.Datetime.now, readonly=True)
    ip = fields.Char('IP Address', readonly=True)

    _once = models.Constraint('UNIQUE(user_id, notice_id)', 'Already accepted.')

    @api.model
    def _accepted(self, user):
        notice = self.env['resco.privacy.notice'].sudo()._current()
        return not notice or bool(self.sudo().search_count([('user_id', '=', user.id), ('notice_id', '=', notice.id)]))

    @api.model
    def _accept(self, user, version, ip=None):
        notice = self.env['resco.privacy.notice'].sudo()._current()
        if not notice or notice.version != version:
            raise UserError(_('This notice was replaced. Please read the current one.'))
        if not self.sudo().search_count([('user_id', '=', user.id), ('notice_id', '=', notice.id)]):
            self.sudo().create({'user_id': user.id, 'user_login': user.login, 'notice_id': notice.id, 'ip': ip})
        return True


class RescoPopup(models.Model):
    """A notice shown to customers after they sign in (FR-WEB-062/063). The public site uses the website popup snippet."""
    _name = 'resco.popup'
    _description = 'Portal Popup'
    _order = 'sequence, id'

    name = fields.Char('Internal Name', required=True)
    title = fields.Char(required=True)
    body = fields.Text(required=True)
    link_url = fields.Char('Button Link')
    link_label = fields.Char('Button Label')
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    date_from = fields.Datetime('Show From')
    date_to = fields.Datetime('Show Until')
    show_once = fields.Boolean('Show once per user', default=True)
    dismissal_ids = fields.One2many('resco.popup.dismissal', 'popup_id')

    @api.model
    def _for_user(self, user):
        now = fields.Datetime.now()
        popups = self.search(['&', '|', ('date_from', '=', False), ('date_from', '<=', now), '|', ('date_to', '=', False), ('date_to', '>=', now)])
        seen = self.env['resco.popup.dismissal'].sudo().search([('user_id', '=', user.id)]).popup_id
        return popups.filtered(lambda p: not (p.show_once and p in seen))


class RescoPopupDismissal(models.Model):
    _name = 'resco.popup.dismissal'
    _description = 'Portal Popup Dismissal'

    popup_id = fields.Many2one('resco.popup', required=True, index=True, ondelete='cascade')
    user_id = fields.Many2one('res.users', required=True, index=True, ondelete='cascade')

    _once = models.Constraint('UNIQUE(popup_id, user_id)', 'Already dismissed.')
