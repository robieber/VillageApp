from odoo import api, fields, models, _
from odoo.exceptions import UserError

from ..lib import payment_rules

STATES = [('for_validation', 'For Validation'), ('confirmed', 'Confirmed'), ('rejected', 'Rejected')]


class RescoPaymentSubmission(models.Model):
    """A proof of payment submitted by a customer (PAY-001). Its validation state lives here, not on the bill:
    the bill's payment status keeps coming only from CMS-RES, so the two can never overwrite each other."""
    _name = 'resco.payment.submission'
    _description = 'Payment Submission'
    _inherit = ['mail.thread']
    _order = 'id desc'

    name = fields.Char('Reference', readonly=True, copy=False, default='/', index=True)
    user_id = fields.Many2one('res.users', 'Submitted By', readonly=True, index=True, ondelete='restrict')
    company_partner_id = fields.Many2one('res.partner', 'Company', readonly=True, index=True)
    submitted_on = fields.Datetime('Submitted On', readonly=True, default=fields.Datetime.now, index=True)
    payment_date = fields.Date('Date of Payment', required=True, index=True)
    bank_name = fields.Char('Bank Name', required=True)
    payment_mode = fields.Selection(payment_rules.MODES, 'Mode of Payment', required=True)
    amount_paid = fields.Float('Amount Paid', digits=(16, 2), required=True)
    state = fields.Selection(STATES, 'Validation Status', required=True, default='for_validation', tracking=True, index=True)
    remarks = fields.Text('Remarks to Customer', tracking=True,
                          help='Shown to the customer with the decision. Required when rejecting.')
    validated_by_id = fields.Many2one('res.users', 'Validated By', readonly=True)
    validated_on = fields.Datetime('Validated On', readonly=True)
    line_ids = fields.One2many('resco.payment.line', 'submission_id', 'Allocations')
    proof_ids = fields.One2many('resco.payment.proof', 'submission_id', 'Proof of Payment')
    csins = fields.Char('Accounts', compute='_compute_csins', store=True)
    allocated_total = fields.Float(compute='_compute_allocated_total', digits=(16, 2))
    proof_count = fields.Integer(compute='_compute_proof_count')

    _amount_positive = models.Constraint('CHECK(amount_paid > 0)', 'The amount paid must be more than zero.')

    @api.depends('line_ids.account_id.csin')
    def _compute_csins(self):
        for s in self:
            s.csins = ', '.join(sorted({l.account_id.csin for l in s.line_ids if l.account_id.csin}))

    @api.depends('line_ids.amount')
    def _compute_allocated_total(self):
        for s in self:
            s.allocated_total = sum(s.line_ids.mapped('amount'))

    @api.depends('proof_ids')
    def _compute_proof_count(self):
        for s in self:
            s.proof_count = len(s.proof_ids)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('name') or vals['name'] == '/':
                vals['name'] = self.env['ir.sequence'].sudo().next_by_code('resco.payment.submission') or '/'
        return super().create(vals_list)

    # ------------------------------------------------------------------
    # Customer side
    # ------------------------------------------------------------------
    @api.model
    def _submit_from_portal(self, user, header, lines, files):
        """Create a submission for a portal user. header, lines and files come from lib.payment_rules and are already
        validated by the caller. Returns the new record. Sends the received and staff notices."""
        sub = self.sudo().create({
            'user_id': user.id, 'company_partner_id': user.partner_id.commercial_partner_id.id,
            'payment_date': header['payment_date'], 'bank_name': header['bank_name'],
            'payment_mode': header['payment_mode'], 'amount_paid': float(header['amount_paid']),
            'line_ids': [(0, 0, {'account_id': l['account_id'], 'bill_id': l['bill_id'], 'amount': float(l['amount'])})
                         for l in lines],
            'proof_ids': [(0, 0, {'name': f['name'], 'mimetype': f['mimetype'], 'file': f['data']}) for f in files],
        })
        accounts = sub.line_ids.account_id
        self.env['resco.event.log']._log('submission', user=user, account=accounts[:1], ref=sub.name,
                                         detail=f'PHP {sub.amount_paid:,.2f} over {len(sub.line_ids)} line(s)')
        sub._notify_received()
        return sub

    def _notify_received(self):
        received = self.env.ref('resco_portal.mail_template_payment_received', raise_if_not_found=False)
        staff = self.env.ref('resco_portal.mail_template_payment_staff', raise_if_not_found=False)
        for s in self:
            if received and s.user_id.partner_id:
                received.sudo().send_mail(s.id, force_send=False, email_values={
                    'recipient_ids': [(6, 0, s.user_id.partner_id.ids)], 'email_to': False},
                    email_layout_xmlid='mail.mail_notification_light')
            to = s._staff_recipients()
            if staff and to:
                staff.sudo().send_mail(s.id, force_send=False, email_values={'email_to': to},
                                       email_layout_xmlid='mail.mail_notification_light')

    def _staff_recipients(self):
        """FR-WEB-046. The addresses in Settings, otherwise the account managers of the accounts paid."""
        self.ensure_one()
        configured = self.env['ir.config_parameter'].sudo().get_param('resco_portal.payment_notify_emails') or ''
        emails = [e.strip() for e in configured.replace(';', ',').split(',') if e.strip()]
        if not emails:
            emails = [a.sam_id.email or a.sam_email for a in self.line_ids.account_id if (a.sam_id.email or a.sam_email)]
        return ','.join(dict.fromkeys(emails))

    # ------------------------------------------------------------------
    # Staff side (PAY-002)
    # ------------------------------------------------------------------
    def _check_can_decide(self):
        if not self.env.user.has_group('resco_portal.group_resco_billing'):
            raise UserError(_('Only Billing Operations can validate payments.'))
        for s in self:
            if s.state != 'for_validation':
                raise UserError(_('%(ref)s was already decided. Return it to validation first to change the decision.', ref=s.name))

    def _decide(self, state):
        now = fields.Datetime.now()
        for s in self:
            s.write({'state': state, 'validated_by_id': self.env.user.id, 'validated_on': now})
            self.env['resco.event.log'].sudo()._log('approval', user=self.env.user, account=s.line_ids.account_id[:1], ref=s.name,
                                                    detail=f'{state} by {self.env.user.login}')
            s._notify_decision()

    def action_confirm(self):
        self._check_can_decide()
        self._decide('confirmed')
        return True

    def action_reject(self):
        self._check_can_decide()
        for s in self:
            if not (s.remarks or '').strip():
                raise UserError(_('Write the reason in "Remarks to Customer" before rejecting %(ref)s.', ref=s.name))
        self._decide('rejected')
        return True

    def action_return_to_validation(self):
        if not self.env.user.has_group('resco_portal.group_resco_admin'):
            raise UserError(_('Only an Administrator can change a decision.'))
        self.write({'state': 'for_validation', 'validated_by_id': False, 'validated_on': False})
        for s in self:
            self.env['resco.event.log'].sudo()._log('approval', user=self.env.user, ref=s.name,
                                                    detail=f'returned to validation by {self.env.user.login}')
        return True

    def _notify_decision(self):
        template = self.env.ref('resco_portal.mail_template_payment_decision', raise_if_not_found=False)
        for s in self:
            if template and s.user_id.partner_id:
                template.sudo().send_mail(s.id, force_send=False, email_values={
                    'recipient_ids': [(6, 0, s.user_id.partner_id.ids)], 'email_to': False},
                    email_layout_xmlid='mail.mail_notification_light')

    def write(self, vals):
        locked = {'payment_date', 'bank_name', 'payment_mode', 'amount_paid', 'line_ids', 'proof_ids', 'user_id'}
        if locked & set(vals) and not self.env.user.has_group('resco_portal.group_resco_admin') and not self.env.su:
            raise UserError(_('The details of a submission cannot be edited. Ask the customer to submit again.'))
        return super().write(vals)


class RescoPaymentLine(models.Model):
    """How a payment is split: a peso amount for one account, and optionally one of its bills (FR-WEB-028)."""
    _name = 'resco.payment.line'
    _description = 'Payment Allocation'
    _order = 'submission_id, id'

    submission_id = fields.Many2one('resco.payment.submission', required=True, index=True, ondelete='cascade')
    account_id = fields.Many2one('resco.account', required=True, index=True, ondelete='restrict')
    csin = fields.Char(related='account_id.csin', store=True)
    bill_id = fields.Many2one('resco.bill', 'Bill', index=True, ondelete='set null',
                              domain="[('account_id', '=', account_id)]")
    bill_number = fields.Char(related='bill_id.bill_number', string='Bill Number')
    period_label = fields.Char(related='bill_id.period_label', string='Bill Month')
    amount = fields.Float(digits=(16, 2), required=True)
    state = fields.Selection(related='submission_id.state', store=True, index=True)

    _amount_positive = models.Constraint('CHECK(amount > 0)', 'Each allocated amount must be more than zero.')

    @api.constrains('account_id', 'bill_id')
    def _check_bill_account(self):
        for l in self:
            if l.bill_id and l.bill_id.account_id != l.account_id:
                raise UserError(_('The bill %(bill)s does not belong to account %(csin)s.',
                                  bill=l.bill_id.bill_number, csin=l.account_id.csin))


class RescoPaymentProof(models.Model):
    """The uploaded proof of payment: PNG, JPEG or PDF, checked by content (FR-WEB-040)."""
    _name = 'resco.payment.proof'
    _description = 'Proof of Payment File'
    _order = 'submission_id, id'

    submission_id = fields.Many2one('resco.payment.submission', required=True, index=True, ondelete='cascade')
    name = fields.Char('File Name', required=True)
    mimetype = fields.Char(required=True)
    file = fields.Binary('File', attachment=True, required=True)
