import base64
import re

from odoo import api, fields, models, _
from odoo.exceptions import UserError

MAX_FILE_BYTES = 20 * 1024 * 1024
BLOCKED_EXT = {'exe', 'bat', 'cmd', 'com', 'scr', 'js', 'vbs', 'sh', 'ps1', 'msi', 'jar', 'dll', 'html', 'htm', 'svg', 'php'}


def clean_name(name):
    base = re.sub(r'[^A-Za-z0-9._ -]', '_', (name or 'file').rsplit('/', 1)[-1].rsplit('\\', 1)[-1]).strip('. ') or 'file'
    return base[:150]


class RescoFileFolder(models.Model):
    """Folders of the staff file library (FR-WEB-073 to 075)."""
    _name = 'resco.file.folder'
    _description = 'File Library Folder'
    _parent_name = 'parent_id'
    _order = 'complete_name'

    name = fields.Char(required=True)
    parent_id = fields.Many2one('resco.file.folder', 'Parent Folder', index=True, ondelete='restrict')
    complete_name = fields.Char(compute='_compute_complete_name', store=True, recursive=True)
    file_count = fields.Integer(compute='_compute_file_count')

    _name_uniq = models.Constraint('UNIQUE(name, parent_id)', 'A folder with this name already exists here.')

    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for f in self:
            f.complete_name = f'{f.parent_id.complete_name} / {f.name}' if f.parent_id else f.name

    def _compute_file_count(self):
        counts = {g.id: n for g, n in self.env['resco.file']._read_group([('folder_id', 'in', self.ids)], ['folder_id'], ['__count'])}
        for f in self:
            f.file_count = counts.get(f.id, 0)

    def _compute_display_name(self):
        for f in self:
            f.display_name = f.complete_name


class RescoFile(models.Model):
    _name = 'resco.file'
    _description = 'File Library Entry'
    _order = 'folder_id, name, version desc'

    name = fields.Char('File Name', required=True, index=True)
    folder_id = fields.Many2one('resco.file.folder', 'Folder', index=True, ondelete='restrict')
    file = fields.Binary(attachment=True, required=True)
    mimetype = fields.Char()
    size = fields.Integer('Size (bytes)', readonly=True)
    version = fields.Integer(default=1, readonly=True)
    active = fields.Boolean(default=True, help='Replaced versions are archived, not deleted.')
    replaces_id = fields.Many2one('resco.file', readonly=True, ondelete='set null')
    uploaded_by_id = fields.Many2one('res.users', 'Uploaded By', default=lambda s: s.env.user, readonly=True)
    create_date = fields.Datetime('Uploaded On', readonly=True)
    note = fields.Char()

    @api.model
    def _store(self, name, raw, folder, overwrite=True, note=False):
        """Add one file. A file with the same name in the same folder is archived and replaced by a new version."""
        name = clean_name(name)
        ext = name.rsplit('.', 1)[-1].lower() if '.' in name else ''
        if ext in BLOCKED_EXT:
            raise UserError(_('"%s": this file type is not allowed.', name))
        if not raw:
            raise UserError(_('"%s" is empty.', name))
        if len(raw) > MAX_FILE_BYTES:
            raise UserError(_('"%(n)s" is larger than %(mb)s MB.', n=name, mb=MAX_FILE_BYTES // (1024 * 1024)))
        old = self.search([('name', '=', name), ('folder_id', '=', folder.id or False)], limit=1)
        if old and not overwrite:
            raise UserError(_('"%s" already exists in this folder.', name))
        vals = {'name': name, 'folder_id': folder.id or False, 'file': base64.b64encode(raw), 'size': len(raw), 'note': note}
        if old:
            vals.update(version=old.version + 1, replaces_id=old.id)
            old.active = False
        rec = self.create(vals)
        self.env['resco.event.log']._log('upload', ref=name, detail=f'library v{rec.version} in {folder.complete_name or "(no folder)"}')
        return rec

    def action_download_zip(self):
        ids = ','.join(str(i) for i in self.ids)
        return {'type': 'ir.actions.act_url', 'url': f'/resco/files/zip?ids={ids}', 'target': 'self'}


class RescoFileUploadWizard(models.TransientModel):
    _name = 'resco.file.upload.wizard'
    _description = 'Upload Files to the Library'

    folder_id = fields.Many2one('resco.file.folder', 'Folder')
    attachment_ids = fields.Many2many('ir.attachment', string='Files')
    overwrite = fields.Boolean('Replace files with the same name', default=True,
                               help='The old version is archived and stays available.')
    note = fields.Char()
    result = fields.Text(readonly=True)

    def action_upload(self):
        self.ensure_one()
        if not self.attachment_ids:
            raise UserError(_('Add at least one file.'))
        ok, lines = 0, []
        for att in self.attachment_ids:
            try:
                with self.env.cr.savepoint():
                    rec = self.env['resco.file']._store(att.name, base64.b64decode(att.datas or b''), self.folder_id, self.overwrite, self.note)
                    lines.append(f'OK    {rec.name} (version {rec.version})')
                    ok += 1
            except UserError as e:
                lines.append(f'FAIL  {e.args[0]}')
        self.attachment_ids.unlink()
        self.result = '\n'.join(lines)
        if ok == len(lines):
            return {'type': 'ir.actions.act_window', 'res_model': 'resco.file', 'view_mode': 'list,form', 'name': _('File Library')}
        return {'type': 'ir.actions.act_window', 'res_model': self._name, 'res_id': self.id, 'view_mode': 'form', 'target': 'new'}
