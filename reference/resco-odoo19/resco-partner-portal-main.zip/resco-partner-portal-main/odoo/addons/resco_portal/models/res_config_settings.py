from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    resco_sftp_enabled = fields.Boolean('Collect bills from SFTP', config_parameter='resco_portal.sftp_enabled')
    resco_sftp_host = fields.Char('SFTP Host', config_parameter='resco_portal.sftp_host')
    resco_sftp_port = fields.Char('SFTP Port', config_parameter='resco_portal.sftp_port', default='22')
    resco_sftp_user = fields.Char('SFTP User', config_parameter='resco_portal.sftp_user')
    resco_sftp_private_key = fields.Text('SFTP Private Key', config_parameter='resco_portal.sftp_private_key',
                                         help='OpenSSH private key without passphrase (Ed25519, RSA or ECDSA).')
    resco_sftp_host_key = fields.Char('SFTP Host Key Fingerprint', config_parameter='resco_portal.sftp_host_key',
                                      help='Format SHA256:xxxx, from "ssh-keygen -lf" on the server key. The connection is refused if it differs.')
    resco_sftp_root = fields.Char('SFTP Root Folder', config_parameter='resco_portal.sftp_root', default='/',
                                  help='Folder that contains inbound/, processed/ and error/.')
    resco_reminder_offsets = fields.Char('Payment Reminder Days', config_parameter='resco_portal.reminder_offsets',
                                         default='5,1,-1',
                                         help='Days relative to the due date. 5 = five days before, -1 = one day after.')
    resco_payment_notify_emails = fields.Char('Payment Submission Alerts To', config_parameter='resco_portal.payment_notify_emails',
                                              help='Comma-separated addresses told about each new proof of payment. Empty: the account managers of the accounts paid.')
    resco_support_notify_emails = fields.Char('Support Ticket Alerts To', config_parameter='resco_portal.support_notify_emails',
                                              help='Comma-separated addresses told about every new ticket, for example a shared support mailbox.')
    resco_ai_enabled = fields.Boolean('Enable the AI assistant', config_parameter='resco_portal.ai_enabled')
    resco_gemini_api_key = fields.Char('Gemini API Key', config_parameter='resco_portal.gemini_api_key',
                                       help='From Google AI Studio. Stored in the database and never sent to the browser.')
    resco_gemini_model = fields.Char('Gemini Model', config_parameter='resco_portal.gemini_model', default='gemini-flash-latest',
                                     help='Model id, for example gemini-flash-latest. See the Gemini API model list.')
    resco_ai_messages_per_hour = fields.Integer('Assistant Messages per User per Hour', config_parameter='resco_portal.ai_messages_per_hour', default=30)
