from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class RescoAccount(models.Model):
    """A contestable service account. Odoo is the master for these records."""
    _name = 'resco.account'
    _description = 'RESCo Service Account'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name, csin'
    _rec_names_search = ['name', 'csin']

    name = fields.Char('Account Name', required=True, tracking=True)
    csin = fields.Char('CSIN', required=True, copy=False, index=True, tracking=True,
                       help='Contestable Service Identification Number')
    partner_id = fields.Many2one('res.partner', 'Company', required=True, index=True, tracking=True,
                                 domain=[('is_company', '=', True)], ondelete='restrict')
    service_address = fields.Char('Service Address')
    pricing_product = fields.Char('Pricing Product')
    contracted_capacity_kw = fields.Float('Contracted Capacity (kW)', digits=(12, 2))
    meq_kwh = fields.Float('Monthly Energy Quantity (kWh)', digits=(16, 2))
    contract_start = fields.Date('Contract Start')
    contract_end = fields.Date('Contract End')
    sam_name = fields.Char('Account Manager (name)', help='Shown to the customer when no Odoo user is assigned as Strategic Account Manager.')
    sam_email = fields.Char('Account Manager (email)')
    sam_id = fields.Many2one('res.users', 'Strategic Account Manager', tracking=True,
                             domain=[('share', '=', False)], index=True)
    active = fields.Boolean(default=True, tracking=True)
    access_ids = fields.One2many('resco.account.access', 'account_id', string='Users with Access')
    bill_ids = fields.One2many('resco.bill', 'account_id', string='Bills')
    bill_count = fields.Integer(compute='_compute_bill_count')
    user_count = fields.Integer(compute='_compute_bill_count')

    _csin_uniq = models.Constraint('UNIQUE(csin)', 'CSIN must be unique.')
    _capacity_positive = models.Constraint('CHECK(contracted_capacity_kw >= 0)', 'Contracted capacity cannot be negative.')

    @api.depends('bill_ids', 'access_ids.active')
    def _compute_bill_count(self):
        for a in self:
            a.bill_count = len(a.bill_ids)
            a.user_count = len(a.access_ids.filtered('active'))

    @api.model_create_multi
    def create(self, vals_list):
        for v in vals_list:
            if v.get('csin'):
                v['csin'] = v['csin'].strip()
        return super().create(vals_list)

    def write(self, vals):
        if vals.get('csin'):
            vals['csin'] = vals['csin'].strip()
        return super().write(vals)

    @api.depends('name', 'csin')
    def _compute_display_name(self):
        for a in self:
            a.display_name = f'{a.name} ({a.csin})' if a.csin else a.name

    def action_open_bills(self):
        self.ensure_one()
        return {'type': 'ir.actions.act_window', 'name': _('Bills'), 'res_model': 'resco.bill',
                'view_mode': 'list,form', 'domain': [('account_id', '=', self.id)],
                'context': {'default_account_id': self.id}}


class RescoAccountAccess(models.Model):
    """Which portal user may see which account (ACC-001, IAM-002)."""
    _name = 'resco.account.access'
    _description = 'Account Access'
    _order = 'account_id, user_id'

    user_id = fields.Many2one('res.users', required=True, index=True, ondelete='cascade',
                              domain=[('share', '=', True)])
    account_id = fields.Many2one('resco.account', required=True, index=True, ondelete='cascade')
    active = fields.Boolean(default=True)
    granted_by_id = fields.Many2one('res.users', default=lambda s: s.env.user, readonly=True)
    granted_on = fields.Datetime(default=fields.Datetime.now, readonly=True)

    _user_account_uniq = models.Constraint('UNIQUE(user_id, account_id)', 'This user already has access to the account.')

    @api.constrains('user_id', 'account_id')
    def _check_same_company(self):
        """A user can only be given accounts of their own company. This blocks cross-customer exposure (BIL-005)."""
        for r in self.sudo():
            if r.user_id.partner_id.commercial_partner_id != r.account_id.partner_id.commercial_partner_id:
                raise ValidationError(_(
                    'User %(user)s belongs to %(company)s and cannot be given access to account %(account)s of %(other)s.',
                    user=r.user_id.name, company=r.user_id.partner_id.commercial_partner_id.name,
                    account=r.account_id.csin, other=r.account_id.partner_id.commercial_partner_id.name))

    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        for r in recs:
            self.env['resco.event.log'].sudo()._log('access_granted', user=r.user_id, account=r.account_id,
                                                    detail=f'by {self.env.user.login}')
        return recs

    def write(self, vals):
        res = super().write(vals)
        if 'active' in vals:
            for r in self:
                self.env['resco.event.log'].sudo()._log('access_changed', user=r.user_id, account=r.account_id,
                                                        detail=f'active={r.active} by {self.env.user.login}')
        return res

    def unlink(self):
        for r in self:
            self.env['resco.event.log'].sudo()._log('access_revoked', user=r.user_id, account=r.account_id,
                                                    detail=f'by {self.env.user.login}')
        return super().unlink()
