import base64
import hashlib
import io
import logging
import threading

import odoo
from odoo.modules import module as odoo_module
import posixpath
import stat

from odoo import api, models, _

from ..lib import sftp_inbox
from ..lib.cms_files import safe_file_name as billing_safe

_logger = logging.getLogger(__name__)


class ParamikoTransport(sftp_inbox.Transport):
    """SFTP transport. paramiko is imported lazily so the module installs without it."""

    def __init__(self, host, port, user, private_key, host_key_fingerprint, root='/'):
        try:
            import paramiko
        except ImportError as e:  # pragma: no cover
            raise RuntimeError('paramiko is not installed in the Odoo image (pip install paramiko).') from e
        self._p = paramiko
        self.root = root.rstrip('/')
        tr = paramiko.Transport((host, int(port or 22)))
        tr.start_client(timeout=30)
        remote = tr.get_remote_server_key()
        got = 'SHA256:' + base64.b64encode(hashlib.sha256(remote.asbytes()).digest()).decode().rstrip('=')
        if got != host_key_fingerprint.strip():
            tr.close()
            raise RuntimeError(f'SFTP host key mismatch: server presented {got}.')
        pkey = None
        for cls in (paramiko.Ed25519Key, paramiko.RSAKey, paramiko.ECDSAKey):
            try:
                pkey = cls.from_private_key(io.StringIO(private_key))
                break
            except Exception:  # noqa: BLE001
                continue
        if pkey is None:
            tr.close()
            raise RuntimeError('The SFTP private key could not be read (Ed25519, RSA or ECDSA, no passphrase).')
        tr.auth_publickey(user, pkey)
        self._tr = tr
        self._c = paramiko.SFTPClient.from_transport(tr)

    def _abs(self, path):
        return f'{self.root}{path}' if path.startswith('/') else f'{self.root}/{path}'

    def listdir(self, path):
        return self._c.listdir(self._abs(path))

    def isdir(self, path):
        try:
            return stat.S_ISDIR(self._c.stat(self._abs(path)).st_mode)
        except OSError:
            return False

    def read(self, path):
        with self._c.open(self._abs(path), 'rb') as f:
            return f.read()

    def write(self, path, data):
        with self._c.open(self._abs(path), 'wb') as f:
            f.write(data)

    def makedirs(self, path):
        cur = ''
        for part in self._abs(path).strip('/').split('/'):
            cur += '/' + part
            try:
                self._c.stat(cur)
            except OSError:
                self._c.mkdir(cur)

    def move(self, src, dst):
        self._c.rename(self._abs(src), self._abs(dst))

    def close(self):
        try:
            self._c.close()
        finally:
            self._tr.close()


class RescoUploadBatchSftp(models.Model):
    _inherit = 'resco.upload.batch'

    @api.model
    def _sftp_params(self):
        P = self.env['ir.config_parameter'].sudo()
        return {k: P.get_param(f'resco_portal.sftp_{k}', '') for k in
                ('enabled', 'host', 'port', 'user', 'private_key', 'host_key', 'root')}

    @api.model
    def _open_transport(self, p):
        return ParamikoTransport(p['host'], p['port'] or 22, p['user'], p['private_key'], p['host_key'], p['root'] or '/')

    @api.model
    def _commit_unless_testing(self):
        if not (getattr(threading.current_thread(), 'testing', False) or odoo_module.current_test or odoo.tools.config['test_enable']):
            self.env.cr.commit()

    def _cron_poll_sftp(self, transport=None):
        """Collect complete CMS-RES batches from the SFTP inbox and load them. `transport` is for tests."""
        p = self._sftp_params()
        if not transport and p['enabled'] not in ('1', 'True', 'true'):
            return 0
        own = transport is None
        try:
            t = transport or self._open_transport(p)
        except Exception as e:  # noqa: BLE001
            _logger.error('SFTP connection failed: %s', e)
            self.env['resco.event.log']._log('error', detail=f'SFTP connection failed: {e}', login='sftp')
            return 0
        done = 0
        robot = self.env.ref('base.user_root')
        try:
            for batch in sftp_inbox.find_ready_batches(t):
                try:
                    with self.env.cr.savepoint():
                        files = {}
                        for name, path in batch.paths.items():
                            files[billing_safe(name)] = t.read(path)
                        rec = self.load('sftp', files, overwrite=True, source_name=batch.name, user=robot)
                        sftp_inbox.archive_batch(t, batch, rec.state != 'failed', rec.result_text())
                    self._commit_unless_testing()
                    done += 1
                except Exception as e:  # noqa: BLE001
                    _logger.exception('SFTP batch %s failed', batch.name)
                    self.env['resco.event.log']._log('error', detail=f'SFTP batch {batch.name}: {e}', login='sftp')
                    try:
                        sftp_inbox.archive_batch(t, batch, False, f'Batch {batch.name} could not be processed: {e}\n')
                    except Exception:  # noqa: BLE001
                        _logger.exception('Could not move failed batch %s', batch.name)
                    self._commit_unless_testing()
        finally:
            if own:
                t.close()
        return done
