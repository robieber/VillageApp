{
    'name': 'RESCo Partner Portal',
    'version': '19.0.0.1.0',
    'summary': 'Customer portal for a Retail Electricity Supplier: accounts, bills from CMS-RES, billing history and energy charts',
    'description': """
RESCo Partner Portal (Phase 1)

* Odoo is the master for companies, service accounts (CSIN), contacts and the assigned Strategic Account Manager
* Per-account access for portal users, with customer roles
* Bills from CMS-RES: one PDF per bill plus a billing details CSV, loaded by SFTP or manual upload
* Re-loading a bill replaces it after confirmation and keeps the old version for audit
* Bill-ready and due-date reminder emails, automatic user deactivation with a 2-week warning
* JSON API at /api/resco/v1 for the React account area
""",
    'author': 'RESCo',
    'category': 'Services',
    'license': 'LGPL-3',
    'depends': ['base', 'mail', 'portal', 'auth_signup'],
    'data': [
        'security/resco_security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence.xml',
        'data/mail_templates.xml',
        'data/ticket_data.xml',
        'data/privacy_data.xml',
        'data/ir_cron.xml',
        'views/resco_account_views.xml',
        'views/resco_bill_views.xml',
        'views/resco_upload_views.xml',
        'views/resco_payment_views.xml',
        'views/resco_ticket_views.xml',
        'views/resco_tools_views.xml',
        'views/resco_event_views.xml',
        'views/res_users_views.xml',
        'views/res_config_settings_views.xml',
        'wizard/resco_bill_upload_wizard_views.xml',
        'views/menus.xml',
    ],
    'application': True,
    'installable': True,
}
