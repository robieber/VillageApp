import base64

from odoo import fields, models, _
from odoo.exceptions import UserError

from ..lib import user_import


class _DryRun(Exception):
    pass


class RescoUserImportWizard(models.TransientModel):
    """Create, update or deactivate many portal users from one CSV (FR-WEB-069)."""
    _name = 'resco.user.import.wizard'
    _description = 'Import Portal Users from CSV'

    csv_file = fields.Binary('CSV file', required=True)
    csv_name = fields.Char()
    send_invitation = fields.Boolean('Email new users a link to set their password', default=True)
    state = fields.Selection([('select', 'Select'), ('checked', 'Checked'), ('done', 'Imported')], default='select')
    result_html = fields.Html(readonly=True, sanitize=False)
    n_ok = fields.Integer(readonly=True)
    n_problem = fields.Integer(readonly=True)

    def action_check(self):
        return self._run(apply=False)

    def action_import(self):
        return self._run(apply=True)

    def action_back(self):
        self.write({'state': 'select', 'result_html': False})
        return self._reopen()

    def _reopen(self):
        return {'type': 'ir.actions.act_window', 'res_model': self._name, 'res_id': self.id, 'view_mode': 'form', 'target': 'new'}

    def _run(self, apply):
        self.ensure_one()
        try:
            text = base64.b64decode(self.csv_file or b'').decode('utf-8-sig')
        except UnicodeDecodeError:
            raise UserError(_('Save the file as CSV (UTF-8) and try again.'))
        rows, errors = user_import.parse(text)
        out = [(r, 'rejected', m) for r, m in errors]
        for row in rows:
            try:
                with self.env.cr.savepoint():
                    msg = self._apply_row(row, apply)
                    if not apply:
                        raise _DryRun()
            except _DryRun:
                pass
            except Exception as e:  # noqa: BLE001 - one bad row never stops the rest
                out.append((row['row'], 'rejected', f"{row['email']}: {e.args[0] if e.args else e}"))
                continue
            out.append((row['row'], 'ok' if apply else 'would be done', msg))
        out.sort(key=lambda x: x[0])
        esc = lambda s: str(s).replace('&', '&amp;').replace('<', '&lt;')  # noqa: E731
        bad = [o for o in out if o[1] == 'rejected']
        good = len(out) - len(bad)
        head = (f'<p><b>{good}</b> row(s) {"imported" if apply else "ready to import"}, <b>{len(bad)}</b> problem(s).</p>')
        body = '<ul>' + ''.join(f'<li>{"row %s: " % r if r else ""}<b>{esc(s)}</b> {esc(m)}</li>' for r, s, m in out[:300]) + '</ul>'
        self.write({'state': 'done' if apply else 'checked', 'result_html': head + body, 'n_ok': good, 'n_problem': len(bad)})
        self.env['resco.event.log']._log('upload', ref=self.csv_name or 'user import', detail=f"{'applied' if apply else 'checked'}: {good} ok, {len(bad)} problems")
        return self._reopen()

    def _apply_row(self, row, apply):
        Users = self.env['res.users'].sudo().with_context(active_test=False, no_reset_password=True)
        Partner = self.env['res.partner'].sudo()
        Access = self.env['resco.account.access'].sudo().with_context(active_test=False)
        portal = self.env.ref('base.group_portal')
        user = Users.search([('login', '=', row['email'])], limit=1)
        if row['action'] == 'deactivate':
            if not user or not user.share:
                raise UserError(_('No portal user with this email.'))
            user.active = False
            self.env['resco.event.log'].sudo()._log('user_deactivated', user=user, detail=f'by import, {self.env.user.login}')
            return _('%s deactivated.', row['email'])
        accounts = self.env['resco.account'].sudo().search([('csin', 'in', row['csins'])])
        missing = set(row['csins']) - set(accounts.mapped('csin'))
        if missing:
            raise UserError(_('Unknown CSIN: %s.', ', '.join(sorted(missing))))
        companies = accounts.partner_id.commercial_partner_id
        if len(companies) > 1:
            raise UserError(_('The CSINs belong to different companies. Use one row per company.'))
        if row['action'] == 'update' and not user:
            raise UserError(_('No portal user with this email. Use ACTION add to create one.'))
        verb = 'updated'
        if not user:
            company = companies[:1]
            partner = Partner.create({'name': row['name'] or row['email'], 'email': row['email'], 'phone': row['mobile'] or False,
                                      'parent_id': company.id})
            user = Users.create({'login': row['email'], 'partner_id': partner.id, 'group_ids': [(6, 0, portal.ids)],
                                 'resco_company_role': row['role'], 'resco_designation': row['designation'] or False})
            verb = 'created'
            if apply and self.send_invitation:
                user.with_context(no_reset_password=False, create_user=True).action_reset_password()
        else:
            if not user.share:
                raise UserError(_('This email belongs to a staff user.'))
            if accounts and user.partner_id.commercial_partner_id != companies[:1]:
                raise UserError(_('This user belongs to another company.'))
            vals = {'resco_company_role': row['role']}
            if row['designation']:
                vals['resco_designation'] = row['designation']
            user.write(vals)
            if row['name']:
                user.partner_id.name = row['name']
            if row['mobile']:
                user.partner_id.phone = row['mobile']
            if not user.active:
                user.active = True
                verb = 'reactivated'
        granted = 0
        for acc in accounts:
            link = Access.search([('user_id', '=', user.id), ('account_id', '=', acc.id)], limit=1)
            if not link:
                Access.create({'user_id': user.id, 'account_id': acc.id})
                granted += 1
            elif not link.active:
                link.active = True
                granted += 1
        return _('%(e)s %(v)s, %(n)s account(s) granted.', e=row['email'], v=verb, n=granted)
