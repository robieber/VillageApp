import base64

from odoo import fields, models, _
from odoo.exceptions import UserError

from ..lib import cms_files, ziputil


class RescoBillUploadWizard(models.TransientModel):
    """Manual upload of CMS-RES files. Same loader and validation as the SFTP route."""
    _name = 'resco.bill.upload.wizard'
    _description = 'Upload CMS-RES Files'

    state = fields.Selection([('select', 'Select files'), ('confirm', 'Confirm')], default='select')
    zip_file = fields.Binary('ZIP with all files')
    zip_name = fields.Char()
    file_ids = fields.Many2many('ir.attachment', string='Files',
                                help='The CSV files (bill header, components, payment status, hourly energy) and the bill PDFs.')
    initial_password = fields.Char('Initial password for new portal users (test systems only)',
                                   help='If a customer file creates new portal users, they get this password. Leave empty on a live '
                                        'system and send them a password reset instead.')
    preview_html = fields.Html(readonly=True, sanitize=False)
    n_new = fields.Integer(readonly=True)
    n_replace = fields.Integer(readonly=True)
    n_errors = fields.Integer(readonly=True)
    n_other = fields.Integer(readonly=True)

    def _collect(self):
        self.ensure_one()
        files = {}
        if self.zip_file:
            files, msgs = ziputil.extract_batch(base64.b64decode(self.zip_file))
            if files is None:
                raise UserError('\n'.join(msgs))
        for att in self.file_ids:
            files[cms_files.safe_file_name(att.name)] = base64.b64decode(att.datas)
        if not files:
            raise UserError(_('Upload a ZIP, or the CSV and PDF files.'))
        return files, (self.zip_name or 'manual upload')

    def action_check(self):
        """Step 1: validate everything and show what would happen. Nothing is written."""
        self.ensure_one()
        files, _name = self._collect()
        pv = self.env['resco.upload.batch'].preview(files)
        esc = lambda s: (s or '').replace('&', '&amp;').replace('<', '&lt;')  # noqa: E731
        parts = [f'<p><b>{len(pv["new"])}</b> new bill(s), <b>{len(pv["replace"])}</b> existing bill(s) to replace, '
                 f'<b>{pv["accounts"]}</b> account(s) to create or update, '
                 f'<b>{pv["payments"]}</b> payment status update(s), <b>{pv["intervals"]}</b> hourly reading(s), '
                 f'<b>{len(pv["errors"])}</b> problem(s).</p>']
        if pv['replace']:
            parts.append('<p>Replacing keeps the old PDF and data as an archived version:</p><ul>' + ''.join(
                f'<li>{esc(b.csin)} {b.year}-{b.month:02d}: bill {esc(old.bill_number)} (v{old.version}) '
                f'will be replaced by {esc(b.bill_number)}</li>' for b, old in pv['replace']) + '</ul>')
        if pv['errors']:
            parts.append('<p>Rejected:</p><ul>' + ''.join(
                f'<li>{esc(e.file)} {"row %s " % e.row if e.row else ""}{esc(e.key)} {esc(e.message)}</li>'
                for e in pv['errors'][:50]) + '</ul>')
        if pv['warnings']:
            parts.append('<p>Warnings:</p><ul>' + ''.join(
                f'<li>{esc(w.file)} {esc(w.message)}</li>' for w in pv['warnings'][:50]) + '</ul>')
        self.write({'state': 'confirm', 'preview_html': ''.join(parts), 'n_new': len(pv['new']),
                    'n_replace': len(pv['replace']), 'n_errors': len(pv['errors']),
                    'n_other': pv['payments'] + pv['intervals'] + pv['accounts']})
        return self._reopen()

    def action_load(self):
        """Step 2: the user has seen the replacements and confirmed them."""
        self.ensure_one()
        files, name = self._collect()
        batch = self.env['resco.upload.batch'].load('manual', files, overwrite=True, source_name=name,
                                                       initial_password=self.initial_password or None)
        self.initial_password = False       # do not keep it
        return {'type': 'ir.actions.act_window', 'res_model': 'resco.upload.batch', 'res_id': batch.id,
                'view_mode': 'form', 'target': 'current'}

    def action_back(self):
        self.state = 'select'
        return self._reopen()

    def _reopen(self):
        return {'type': 'ir.actions.act_window', 'res_model': self._name, 'res_id': self.id, 'view_mode': 'form',
                'target': 'new'}
