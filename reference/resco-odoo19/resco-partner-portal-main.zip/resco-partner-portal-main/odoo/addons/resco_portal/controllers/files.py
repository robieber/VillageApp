import base64
import io
import re
import zipfile

from odoo import http
from odoo.exceptions import AccessError
from odoo.http import request

MAX_ZIP_BYTES = 200 * 1024 * 1024


class RescoFiles(http.Controller):

    @http.route('/resco/files/zip', type='http', auth='user', methods=['GET'], sitemap=False)
    def zip_files(self, ids='', **kw):
        """Staff download of selected library files as one ZIP. Record rules and groups decide what is readable."""
        user = request.env.user
        if user.share or not user.has_group('resco_portal.group_resco_readonly'):
            return request.not_found()
        wanted = [int(i) for i in re.findall(r'\d+', ids)][:500]
        files = request.env['resco.file'].with_context(active_test=False).browse(wanted).exists()
        try:
            files.check_access('read')
        except AccessError:
            return request.not_found()
        total = sum(f.size for f in files)
        if not files or total > MAX_ZIP_BYTES:
            return request.make_response('Select between 1 file and 200 MB of files.', status=400)
        buf, used = io.BytesIO(), set()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
            for f in files:
                folder = (f.folder_id.complete_name or '').replace(' / ', '/')
                name = f"{folder + '/' if folder else ''}{f.name}" if f.active else f"{folder + '/' if folder else ''}v{f.version}-{f.name}"
                while name in used:
                    name = f'{f.id}-{name}'
                used.add(name)
                z.writestr(name, base64.b64decode(f.file or b''))
        request.env['resco.event.log'].sudo()._log('download', ref='library zip', detail=f'{len(files)} files')
        return request.make_response(buf.getvalue(), headers=[
            ('Content-Type', 'application/zip'), ('Content-Disposition', 'attachment; filename="resco-files.zip"'),
            ('X-Content-Type-Options', 'nosniff')])
