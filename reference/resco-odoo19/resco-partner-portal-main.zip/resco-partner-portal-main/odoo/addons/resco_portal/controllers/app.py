from odoo import http
from odoo.http import request
from odoo.tools import file_open


class RescoAppController(http.Controller):
    """Serves the React account area at /portal-app once it is built into static/app (Phase 1b)."""

    @http.route(['/portal-app', '/portal-app/'], type='http', auth='public', sitemap=False)
    def resco_app(self, **kw):
        try:
            with file_open('resco_portal/static/app/index.html', 'rb') as f:
                html = f.read()
        except FileNotFoundError:
            return request.not_found()
        return request.make_response(html, headers=[('Content-Type', 'text/html; charset=utf-8'),
                                                    ('Cache-Control', 'no-cache')])
