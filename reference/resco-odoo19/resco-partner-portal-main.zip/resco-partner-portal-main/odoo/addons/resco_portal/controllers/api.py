"""JSON API for the Partners Portal account area: /api/resco/v1/*

Authentication, like the Araw Solar API this is adapted from:

1. Odoo session cookie when the React app is served by Odoo. State-changing calls must send
   ``X-Requested-With: RescoPortal`` and any Origin header must match the Odoo host (CSRF defence).
2. ``Authorization: Bearer <token>``: an Odoo API key restricted to the ``resco_portal`` scope.

Access rule: every query is scoped through ``res.users._resco_accounts()`` BEFORE sudo() is used, so a user can only
ever reach the accounts they were granted. Anything outside returns 404, never 403, to avoid confirming it exists.
"""
import base64
import functools
import logging
import os
import re
from datetime import datetime, timedelta
from urllib.parse import urlparse

from odoo import _, fields, http
from odoo.exceptions import AccessDenied, UserError, ValidationError
from odoo.http import request
from odoo.tools import html2plaintext

from ..lib import aggregate, password_policy, payment_rules
from ..models.resco_ticket import TICKET_STATES

_logger = logging.getLogger(__name__)
PREFIX = '/api/resco/v1'
TOKEN_SCOPE = 'resco_portal'
TOKEN_DAYS = 30
CSRF_HEADER = 'RescoPortal'
CORS = os.environ.get('RESCO_APP_CORS_ORIGIN') or None
WRITE_METHODS = ('POST', 'PUT', 'PATCH', 'DELETE')
MAX_LOGO_BYTES = 2 * 1024 * 1024


def route(path, methods):
    if CORS:
        methods = methods + ['OPTIONS']
    return http.route(f'{PREFIX}{path}', type='http', auth='public', methods=methods, csrf=False, cors=CORS, sitemap=False)


def _json(data, status=200):
    return request.make_json_response(data, status=status, headers=[('Cache-Control', 'no-store')])


def _error(message, status=400, code='bad_request'):
    return _json({'error': {'code': code, 'message': message}}, status=status)


def _body():
    try:
        return request.get_json_data() or {}
    except Exception:  # noqa: BLE001
        return {}


def _method():
    return request.httprequest.method


def _ip():
    return request.httprequest.remote_addr


def _bearer():
    header = request.httprequest.headers.get('Authorization') or ''
    m = re.match(r'^bearer\s+(.+)$', header, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return (request.httprequest.headers.get('X-Resco-Token') or '').strip() or None


def _issue_token(user):
    expires = datetime.now() + timedelta(days=TOKEN_DAYS)
    return request.env['res.users.apikeys'].with_user(user).sudo()._generate(TOKEN_SCOPE, 'Partners Portal app', expires)


def _revoke_token(token):
    request.env.cr.execute(
        "DELETE FROM res_users_apikeys WHERE scope = %s AND index = %s AND user_id = %s",
        (TOKEN_SCOPE, token[:8], request.env.uid))


def _cors_allows(origin):
    return bool(CORS) and (CORS == '*' or origin.rstrip('/') in {o.strip().rstrip('/') for o in CORS.split(',')})


def endpoint(auth=True):
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(self, *args, **kwargs):
            token = _bearer()
            if token:
                uid = request.env['res.users.apikeys']._check_credentials(scope=TOKEN_SCOPE, key=token)
                if not uid:
                    return _error(_('Session expired, please sign in again'), 401, 'unauthenticated')
                request.update_env(user=uid)
                request.session.can_save = False
            elif _method() in WRITE_METHODS:
                headers = request.httprequest.headers
                if headers.get('X-Requested-With') != CSRF_HEADER:
                    return _error('Missing X-Requested-With header', 403, 'csrf')
                origin = headers.get('Origin')
                if origin and urlparse(origin).netloc != request.httprequest.host:
                    if auth or not _cors_allows(origin):
                        return _error('Cross-origin cookie requests are not allowed; use a bearer token', 403, 'csrf')
                    request.session.can_save = False
            if auth:
                user = request.env.user
                if user._is_public():
                    return _error(_('Not signed in'), 401, 'unauthenticated')
                if not user.share:
                    return _error(_('Staff accounts use the Odoo back office.'), 403, 'forbidden')
                user._resco_touch_activity()
            try:
                return fn(self, *args, **kwargs)
            except AccessDenied:
                request.env.cr.rollback()
                return _error(_('Incorrect email or password'), 403, 'access_denied')
            except (UserError, ValidationError) as e:
                request.env.cr.rollback()
                return _error(str(e.args[0] if e.args else e), 400, 'user_error')
        return wrapper
    return deco


def _decode_files(raw_files, limit=payment_rules.MAX_PROOF_FILES):
    """Checked attachments from a JSON body. Raises ValueError with a message safe to show."""
    raw_files = raw_files if isinstance(raw_files, list) else []
    if len(raw_files) > limit:
        raise ValueError(f'Attach at most {limit} files.')
    files = []
    for f in raw_files:
        f = f if isinstance(f, dict) else {}
        name = str(f.get('name') or 'file')
        try:
            blob = base64.b64decode(str(f.get('data') or '').split(',')[-1], validate=True)
        except Exception:  # noqa: BLE001
            raise ValueError(f'"{name}" could not be read.')
        clean, mime = payment_rules.check_file(name, blob)
        files.append({'name': clean, 'mimetype': mime, 'data': base64.b64encode(blob)})
    return files


def _csv_ids(raw):
    out = []
    for tok in (raw or '').split(','):
        tok = tok.strip()
        if tok.isdigit():
            out.append(int(tok))
    return out


class RescoApi(http.Controller):

    # ------------------------------------------------------------------
    # Scoping helpers
    # ------------------------------------------------------------------
    def _accounts(self):
        return request.env.user._resco_accounts()

    def _scoped_accounts(self, ids):
        """Selected accounts that the user may see. Empty selection means all of them."""
        mine = self._accounts()
        if not ids:
            return mine
        return mine.filtered(lambda a: a.id in ids)

    def _account_payload(self, a):
        sam = a.sam_id.sudo()
        return {
            'id': a.id, 'name': a.name, 'csin': a.csin, 'company': a.partner_id.name,
            'service_address': a.service_address or '', 'pricing_product': a.pricing_product or '',
            'contracted_capacity_kw': a.contracted_capacity_kw,
            'sam': ({'name': sam.name, 'email': sam.email or '', 'phone': sam.partner_id.phone or '',
                     'designation': sam.resco_designation or ''} if sam else
                    {'name': a.sam_name, 'email': a.sam_email or '', 'phone': '', 'designation': ''}
                    if a.sam_name else None),
        }

    def _bill_payload(self, b, full=False):
        data = {
            'id': b.id, 'account_id': b.account_id.id, 'csin': b.csin, 'account_name': b.account_id.name,
            'year': b.year, 'month': b.month, 'period': b.period_label, 'bill_number': b.bill_number,
            'due_date': str(b.due_date), 'total_amount': round(b.total_amount, 2), 'payment_status': b.payment_status,
            'overdue': b.payment_status == 'overdue' or (b.payment_status in ('unpaid', 'partial')
                                                         and b.due_date < fields.Date.context_today(b)),
            'amount_paid': b.amount_paid, 'outstanding_balance': b.outstanding_balance,
            'last_payment_date': str(b.last_payment_date) if b.last_payment_date else None,
            'period_from': str(b.period_from) if b.period_from else None, 'period_to': str(b.period_to) if b.period_to else None,
            'has_pdf': bool(b.pdf), 'version': b.version,
            'energy_kwh': b.energy_kwh, 'meq_kwh': b.meq_kwh,
        }
        if full:
            data.update({
                'bill_key': b.bill_key, 'pricing_product': b.pricing_product or '',
                'peak_demand_kw': b.peak_demand_kw, 'current_charges': b.current_charges,
                'vat_amount': b.vat_amount, 'previous_balance': b.previous_balance, 'adjustments': b.adjustments,
                'components': [{'code': l.code, 'name': l.component, 'quantity': l.quantity, 'uom': l.uom or '',
                                'rate': l.rate, 'amount': l.amount} for l in b.line_ids],
            })
        return data

    def _bill_domain(self, accounts):
        return [('account_id', 'in', accounts.ids)]

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------
    @route('/auth/login', ['POST'])
    @endpoint(auth=False)
    def login(self, **kw):
        data = _body()
        login = (data.get('email') or '').strip().lower()
        credential = {'login': login, 'password': data.get('password') or '', 'type': 'password'}
        try:
            request.session.authenticate(request.env, credential)
        except AccessDenied:
            request.env['resco.event.log']._log('login_failed', detail='bad credentials', ip=_ip(), login=login)
            request.env.cr.commit()   # the error handler rolls back; keep the audit row
            raise
        request.update_env(user=request.session.uid)
        user = request.env.user
        if not user.share:
            request.session.logout(keep_db=True)
            return _error(_('Staff accounts use the Odoo back office.'), 403, 'forbidden')
        if not user._resco_accounts():
            request.session.logout(keep_db=True)
            request.env['resco.event.log']._log('login_failed', user=user, detail='no accounts assigned', ip=_ip())
            return _error(_('Your user has no accounts yet. Please contact your account manager.'), 403, 'no_accounts')
        user._resco_touch_activity()
        request.env['resco.event.log']._log('login', user=user, ip=_ip())
        token = _issue_token(user) if data.get('issue_token', True) else None
        return _json({'ok': True, 'token': token, 'me': self._me_payload()})

    @route('/auth/logout', ['POST'])
    @endpoint(auth=False)
    def logout(self, **kw):
        user = request.env.user
        token = _bearer()
        if token and not user._is_public():
            _revoke_token(token)
        if not user._is_public():
            request.env['resco.event.log']._log('logout', user=user, ip=_ip())
        request.session.logout(keep_db=True)
        return _json({'ok': True})

    @route('/auth/reset-password', ['POST'])
    @endpoint(auth=False)
    def reset_password(self, **kw):
        email = (_body().get('email') or '').strip().lower()
        try:
            request.env['res.users'].sudo().reset_password(email)
        except Exception:  # noqa: BLE001 - never reveal whether an account exists
            _logger.info('Password reset requested for unknown login')
        return _json({'ok': True, 'message': _('If an account exists for that email, a reset link has been sent.')})

    # ------------------------------------------------------------------
    # Profile
    # ------------------------------------------------------------------
    def _me_payload(self):
        user = request.env.user
        p = user.partner_id
        c = p.commercial_partner_id
        return {
            'id': user.id, 'name': p.name, 'email': user.login, 'designation': user.resco_designation or '',
            'mobile': p.phone or '', 'landline': user.resco_landline or '', 'gender': user.resco_gender or '',
            'birthday': str(user.resco_birthday) if user.resco_birthday else None,
            'role': user.resco_company_role or 'viewer',
            'company': {'name': c.name, 'website': c.website or '', 'has_logo': bool(c.image_1920),
                        'address': ', '.join(x for x in [c.street, c.street2, c.city, c.zip] if x)},
            'preferences': {'email_optout': user.resco_email_optout, 'email_optout_reason': user.resco_email_optout_reason or ''},
            'account_count': len(user._resco_accounts()),
            'privacy_pending': not request.env['resco.privacy.consent']._accepted(user),
        }

    @route('/me', ['GET', 'PUT', 'PATCH'])
    @endpoint()
    def me(self, **kw):
        if _method() == 'GET':
            return _json(self._me_payload())
        data = _body()
        user = request.env.user.sudo()
        pvals = {}
        if 'name' in data:
            name = (data['name'] or '').strip()
            if not name:
                raise UserError(_('Name cannot be empty.'))
            pvals['name'] = name
        if 'mobile' in data:
            pvals['phone'] = (data['mobile'] or '').strip()
        uvals = {}
        for key, field in (('designation', 'resco_designation'), ('landline', 'resco_landline')):
            if key in data:
                uvals[field] = (data[key] or '').strip()
        if 'gender' in data:
            if data['gender'] not in ('female', 'male', 'other', '', None):
                raise UserError(_('Invalid gender value.'))
            uvals['resco_gender'] = data['gender'] or False
        if 'birthday' in data:
            uvals['resco_birthday'] = fields.Date.to_date(data['birthday']) if data['birthday'] else False
        if pvals:
            user.partner_id.write(pvals)
        if uvals:
            user.write(uvals)
        # Company details belong to the company; only a Customer Administrator may change them.
        company_vals = {}
        for key, field in (('company_website', 'website'),):
            if key in data:
                company_vals[field] = (data[key] or '').strip()
        if company_vals:
            if user.resco_company_role != 'admin':
                return _error(_('Only a Customer Administrator can change company details.'), 403, 'forbidden')
            user.partner_id.commercial_partner_id.write(company_vals)
        return _json(self._me_payload())

    @route('/me/password', ['POST'])
    @endpoint()
    def change_password(self, **kw):
        data = _body()
        old, new = data.get('old_password') or '', data.get('new_password') or ''
        problems = password_policy.check(new, request.env.user.login)
        if problems:
            raise UserError(password_policy.message(problems))
        request.env.user.change_password(old, new)
        request.env.cr.commit()
        if not _bearer():
            request.session.session_token = request.env.user._compute_session_token(request.session.sid)
        return _json({'ok': True})

    @route('/me/email-preferences', ['PUT', 'PATCH'])
    @endpoint()
    def email_preferences(self, **kw):
        data = _body()
        optout = bool(data.get('email_optout'))
        reason = (data.get('reason') or '').strip()
        if optout and not reason:
            raise UserError(_('Please tell us why you are unsubscribing.'))
        request.env.user.sudo().write({'resco_email_optout': optout,
                                       'resco_email_optout_reason': reason if optout else False})
        return _json(self._me_payload())

    @route('/me/company-logo', ['POST'])
    @endpoint()
    def company_logo(self, **kw):
        user = request.env.user.sudo()
        if user.resco_company_role != 'admin':
            return _error(_('Only a Customer Administrator can change the company logo.'), 403, 'forbidden')
        b64 = (_body().get('image_base64') or '').split(',')[-1]
        try:
            raw = base64.b64decode(b64, validate=True)
        except Exception:  # noqa: BLE001
            raise UserError(_('The image could not be read.'))
        if len(raw) > MAX_LOGO_BYTES:
            raise UserError(_('The logo must be smaller than 2 MB.'))
        if not (raw.startswith(b'\x89PNG\r\n\x1a\n') or raw.startswith(b'\xff\xd8\xff')):
            raise UserError(_('The logo must be a PNG or JPEG image.'))
        user.partner_id.commercial_partner_id.write({'image_1920': base64.b64encode(raw)})
        return _json(self._me_payload())

    @route('/company/logo', ['GET'])
    @endpoint()
    def company_logo_get(self, **kw):
        c = request.env.user.partner_id.commercial_partner_id.sudo()
        if not c.image_128:
            return _error(_('No logo'), 404, 'not_found')
        return request.make_response(base64.b64decode(c.image_256 or c.image_128),
                                     headers=[('Content-Type', 'image/png'), ('Cache-Control', 'private, max-age=300')])

    @route('/company/users', ['GET'])
    @endpoint()
    def company_users(self, **kw):
        """FR-WEB-008: other active users of the same company and the accounts each can access."""
        me = request.env.user
        if me.resco_company_role != 'admin':
            return _error(_('Only a Customer Administrator can see the other users of the company.'), 403, 'forbidden')
        company = me.partner_id.commercial_partner_id
        my_accounts = self._accounts()
        users = request.env['res.users'].sudo().search([('share', '=', True), ('active', '=', True),
                                                        ('partner_id.commercial_partner_id', '=', company.id)])
        out = []
        for u in users:
            accs = u._resco_accounts() & my_accounts
            out.append({'id': u.id, 'name': u.name, 'email': u.login, 'role': u.resco_company_role or 'viewer',
                        'designation': u.resco_designation or '',
                        'accounts': [{'id': a.id, 'name': a.name, 'csin': a.csin} for a in accs]})
        return _json(sorted(out, key=lambda x: x['name'].lower()))

    # ------------------------------------------------------------------
    # Accounts
    # ------------------------------------------------------------------
    @route('/accounts', ['GET'])
    @endpoint()
    def accounts(self, q=None, **kw):
        accs = self._accounts()
        if q:
            ql = q.strip().lower()
            accs = accs.filtered(lambda a: ql in (a.name or '').lower() or ql in (a.csin or '').lower())
        return _json([self._account_payload(a) for a in accs.sorted(lambda a: (a.name or '').lower())])

    @route('/accounts/<int:account_id>', ['GET'])
    @endpoint()
    def account(self, account_id, **kw):
        a = self._accounts().filtered(lambda x: x.id == account_id)
        if not a:
            return _error(_('Account not found'), 404, 'not_found')
        return _json(self._account_payload(a))

    # ------------------------------------------------------------------
    # Bills
    # ------------------------------------------------------------------
    @route('/bills', ['GET'])
    @endpoint()
    def bills(self, account_id=None, year=None, month=None, **kw):
        accounts = self._scoped_accounts(_csv_ids(account_id))
        domain = self._bill_domain(accounts)
        if year and str(year).isdigit():
            domain.append(('year', '=', int(year)))
        if month and str(month).isdigit():
            domain.append(('month', '=', int(month)))
        bills = request.env['resco.bill'].sudo().search(domain, limit=500)
        pending = self._pending_bill_ids(bills)
        return _json([dict(self._bill_payload(b), payment_pending=b.id in pending) for b in bills])

    def _pending_bill_ids(self, bills):
        lines = request.env['resco.payment.line'].sudo().search([('bill_id', 'in', bills.ids), ('state', '=', 'for_validation')])
        return set(lines.bill_id.ids)

    def _bill(self, bill_id):
        return request.env['resco.bill'].sudo().search(
            self._bill_domain(self._accounts()) + [('id', '=', bill_id)], limit=1)

    @route('/bills/<int:bill_id>', ['GET'])
    @endpoint()
    def bill(self, bill_id, **kw):
        b = self._bill(bill_id)
        if not b:
            return _error(_('Bill not found'), 404, 'not_found')
        data = self._bill_payload(b, full=True)
        data['payment_pending'] = b.id in self._pending_bill_ids(b)
        data['submissions'] = [self._payment_payload(s) for s in self._submissions([('line_ids.bill_id', '=', b.id)])]
        return _json(data)

    @route('/bills/<int:bill_id>/pdf', ['GET'])
    @endpoint()
    def bill_pdf(self, bill_id, **kw):
        b = self._bill(bill_id)
        if not b or not b.pdf:
            return _error(_('Bill not found'), 404, 'not_found')
        request.env['resco.event.log']._log('download', account=b.account_id, ref=b.bill_number, ip=_ip())
        name = re.sub(r'[^A-Za-z0-9._-]', '_', b.pdf_name or f'{b.bill_number}.pdf')
        return request.make_response(base64.b64decode(b.pdf), headers=[
            ('Content-Type', 'application/pdf'), ('Content-Disposition', f'attachment; filename="{name}"'),
            ('Cache-Control', 'private, no-store'), ('X-Content-Type-Options', 'nosniff')])

    # ------------------------------------------------------------------
    # Charts
    # ------------------------------------------------------------------
    @route('/billing-history', ['GET'])
    @endpoint()
    def billing_history(self, account_id=None, months=12, **kw):
        accounts = self._scoped_accounts(_csv_ids(account_id))
        lines = request.env['resco.bill.line'].sudo().search([('account_id', 'in', accounts.ids)], order='sequence')
        n = max(1, min(int(months) if str(months).isdigit() else 12, 36))
        rows = [(l.year, l.month, l.component, l.amount) for l in lines]
        # VAT is a separate column on the bill, not a component line; show it as its own stacked series.
        bills = request.env['resco.bill'].sudo().search([('account_id', 'in', accounts.ids)])
        rows += [(b.year, b.month, 'VAT', b.vat_amount) for b in bills if b.vat_amount]
        result = aggregate.billing_history(rows, months=n)
        result['account_ids'] = accounts.ids
        return _json(result)

    @route('/energy/yearly', ['GET'])
    @endpoint()
    def energy_yearly(self, account_id=None, year=None, **kw):
        """Clustered columns, one cluster per month: billed energy and MEQ."""
        accounts = self._scoped_accounts(_csv_ids(account_id))
        year = int(year) if year and str(year).isdigit() else fields.Date.context_today(request.env.user).year
        bills = request.env['resco.bill'].sudo().search([('account_id', 'in', accounts.ids), ('year', '=', year)])
        result = aggregate.energy_yearly([(b.year, b.month, b.energy_kwh, b.meq_kwh or None) for b in bills], year)
        result['account_ids'] = accounts.ids
        return _json(result)

    def _intervals(self, accounts, start_utc, end_utc):
        recs = request.env['resco.energy.interval'].sudo().search([
            ('account_id', 'in', accounts.ids), ('interval_start', '>=', start_utc), ('interval_start', '<', end_utc)])
        return [(r.interval_start, r.kwh, r.kw_demand or None) for r in recs]

    @route('/energy/daily', ['GET'])
    @endpoint()
    def energy_daily(self, account_id=None, year=None, month=None, **kw):
        """Combo chart for one month: bars = kWh per day, line = peak kW in the day."""
        accounts = self._scoped_accounts(_csv_ids(account_id))
        today = fields.Date.context_today(request.env.user)
        year = int(year) if year and str(year).isdigit() else today.year
        month = int(month) if month and str(month).isdigit() and 1 <= int(month) <= 12 else today.month
        start = datetime(year, month, 1) - timedelta(hours=8)
        end = (datetime(year + (month == 12), month % 12 + 1, 1)) - timedelta(hours=8)
        result = aggregate.energy_daily(self._intervals(accounts, start, end), year, month)
        result['account_ids'] = accounts.ids
        return _json(result)

    @route('/energy/hourly', ['GET'])
    @endpoint()
    def energy_hourly(self, account_id=None, date=None, **kw):
        """Combo chart for one day: bars = kWh per hour, line = kW demand."""
        accounts = self._scoped_accounts(_csv_ids(account_id))
        try:
            day = fields.Date.to_date(date) if date else None
        except Exception:  # noqa: BLE001
            day = None
        if not day:
            return _error(_('date must be YYYY-MM-DD'), 400, 'bad_request')
        start = datetime(day.year, day.month, day.day) - timedelta(hours=8)
        result = aggregate.energy_hourly(self._intervals(accounts, start, start + timedelta(days=1)), day)
        result['account_ids'] = accounts.ids
        return _json(result)

    # ------------------------------------------------------------------
    # Proof of payment (PAY-001 to PAY-003, FR-WEB-027 to 030)
    # ------------------------------------------------------------------
    def _submissions(self, extra=None, limit=200):
        """Submissions that touch the user's accounts, last 12 months."""
        mine = self._accounts()
        since = datetime.now() - timedelta(days=payment_rules.HISTORY_DAYS)
        domain = [('line_ids.account_id', 'in', mine.ids), ('submitted_on', '>=', since)] + (extra or [])
        return request.env['resco.payment.submission'].sudo().search(domain, limit=limit)

    def _payment_payload(self, s, full=False):
        mine = self._accounts()
        lines = s.line_ids.filtered(lambda l: l.account_id in mine)
        data = {
            'id': s.id, 'reference': s.name, 'submitted_on': fields.Datetime.to_string(s.submitted_on),
            'submitted_by': s.user_id.name, 'payment_date': str(s.payment_date), 'bank_name': s.bank_name,
            'payment_mode': s.payment_mode, 'amount_paid': round(s.amount_paid, 2), 'status': s.state,
            'remarks': s.remarks or '' if s.state != 'for_validation' else '',
            'validated_on': fields.Datetime.to_string(s.validated_on) if s.validated_on else None,
            'partial_view': len(lines) != len(s.line_ids),
            'lines': [{'account_id': l.account_id.id, 'csin': l.csin, 'account_name': l.account_id.name,
                       'bill_id': l.bill_id.id or None, 'bill_number': l.bill_number or '',
                       'period': l.period_label or '', 'amount': round(l.amount, 2)} for l in lines],
            'files': [{'id': p.id, 'name': p.name, 'mimetype': p.mimetype} for p in s.proof_ids],
        }
        return data

    @route('/payments', ['GET'])
    @endpoint()
    def payments(self, account_id=None, status=None, **kw):
        wanted = set(_csv_ids(account_id))
        extra = [('state', '=', status)] if status in ('for_validation', 'confirmed', 'rejected') else []
        rows = self._submissions(extra)
        if wanted:
            rows = rows.filtered(lambda s: wanted & set(s.line_ids.account_id.ids))
        return _json([self._payment_payload(s) for s in rows])

    @route('/payments/options', ['GET'])
    @endpoint()
    def payment_options(self, **kw):
        """What the form needs: modes, who may submit, and the open bills of each account."""
        me = request.env.user
        accounts = self._accounts()
        bills = request.env['resco.bill'].sudo().search(
            [('account_id', 'in', accounts.ids), ('payment_status', '!=', 'paid')], limit=500)
        return _json({
            'can_submit': me.resco_company_role in ('admin', 'billing'),
            'modes': [{'key': k, 'label': v} for k, v in payment_rules.MODES],
            'max_files': payment_rules.MAX_PROOF_FILES, 'max_file_mb': payment_rules.MAX_PROOF_BYTES // (1024 * 1024),
            'open_bills': [{'id': b.id, 'account_id': b.account_id.id, 'bill_number': b.bill_number, 'period': b.period_label,
                            'total_amount': round(b.total_amount, 2),
                            'outstanding': round(b.outstanding_balance or b.total_amount, 2)} for b in bills],
        })

    @route('/payments/<int:payment_id>', ['GET'])
    @endpoint()
    def payment(self, payment_id, **kw):
        s = self._submissions([('id', '=', payment_id)], limit=1)
        if not s:
            return _error(_('Payment submission not found'), 404, 'not_found')
        return _json(self._payment_payload(s, full=True))

    @route('/payments/<int:payment_id>/file/<int:file_id>', ['GET'])
    @endpoint()
    def payment_file(self, payment_id, file_id, **kw):
        s = self._submissions([('id', '=', payment_id)], limit=1)
        proof = s.proof_ids.filtered(lambda p: p.id == file_id)
        if not proof:
            return _error(_('File not found'), 404, 'not_found')
        request.env['resco.event.log']._log('download', account=s.line_ids.account_id[:1], ref=s.name, ip=_ip())
        name = re.sub(r'[^A-Za-z0-9._-]', '_', proof.name)
        return request.make_response(base64.b64decode(proof.file), headers=[
            ('Content-Type', proof.mimetype), ('Content-Disposition', f'attachment; filename="{name}"'),
            ('Cache-Control', 'private, no-store'), ('X-Content-Type-Options', 'nosniff')])

    @route('/payments', ['POST'])
    @endpoint()
    def payment_submit(self, **kw):
        me = request.env.user
        if me.resco_company_role not in ('admin', 'billing'):
            return _error(_('Only a Customer Administrator or a Billing contact can submit proof of payment.'), 403, 'forbidden')
        data = _body()
        today = fields.Date.context_today(me)
        try:
            pdate = fields.Date.to_date(data.get('payment_date')) if data.get('payment_date') else None
        except Exception:  # noqa: BLE001
            pdate = None
        try:
            pdate, bank, mode, amount = payment_rules.check_header(
                pdate, data.get('bank_name'), data.get('payment_mode'), data.get('amount_paid'), today)
            raw_lines = data.get('lines') if isinstance(data.get('lines'), list) else []
            raw_lines = [l for l in raw_lines if isinstance(l, dict)]
            mine = self._accounts()
            bill_ids = [l.get('bill_id') for l in raw_lines if isinstance(l.get('bill_id'), int)]
            bills = request.env['resco.bill'].sudo().search([('id', 'in', bill_ids), ('account_id', 'in', mine.ids)])
            lines = payment_rules.check_allocations(
                raw_lines, amount, set(mine.ids), {b.id: b.account_id.id for b in bills})
            raw_files = data.get('files') if isinstance(data.get('files'), list) else []
            if not raw_files:
                raise ValueError('Attach the proof of payment (PNG, JPEG or PDF).')
            if len(raw_files) > payment_rules.MAX_PROOF_FILES:
                raise ValueError(f'Attach at most {payment_rules.MAX_PROOF_FILES} files.')
            files = []
            for f in raw_files:
                name = str((f or {}).get('name') or 'proof')
                try:
                    blob = base64.b64decode(str((f or {}).get('data') or '').split(',')[-1], validate=True)
                except Exception:  # noqa: BLE001
                    raise ValueError(f'"{name}" could not be read.')
                clean, mime = payment_rules.check_file(name, blob)
                files.append({'name': clean, 'mimetype': mime, 'data': base64.b64encode(blob)})
        except ValueError as e:
            return _error(str(e), 400, 'invalid')
        sub = request.env['resco.payment.submission']._submit_from_portal(
            me, {'payment_date': pdate, 'bank_name': bank, 'payment_mode': mode, 'amount_paid': amount}, lines, files)
        return _json(self._payment_payload(sub, full=True), status=201)

    # ------------------------------------------------------------------
    # Helpdesk (HLP-001, HLP-002, FR-WEB-017/018/019)
    # ------------------------------------------------------------------
    def _tickets(self, extra=None, limit=200):
        return request.env['resco.ticket'].sudo().search(
            [('account_id', 'in', self._accounts().ids)] + (extra or []), limit=limit)

    def _ticket_payload(self, t, full=False):
        data = {'id': t.id, 'reference': t.name, 'subject': t.subject, 'status': t.state, 'status_label': t.state_label,
                'category': t.category_id.name, 'account_id': t.account_id.id, 'csin': t.csin, 'account_name': t.account_id.name,
                'created_on': fields.Datetime.to_string(t.create_date), 'last_activity': fields.Datetime.to_string(t.last_activity),
                'assigned_to': t.assigned_user_id.name or '', 'raised_by': t.user_id.name, 'source': t.source}
        if full:
            data['messages'] = [{
                'id': m.id, 'from': m.author_id.name, 'staff': bool(m.author_id.user_ids and not m.author_id.user_ids.filtered('share')),
                'at': fields.Datetime.to_string(m.date), 'text': html2plaintext(m.body or '').strip(),
                'files': [{'id': a.id, 'name': a.name} for a in m.attachment_ids]} for m in t._public_messages()]
        return data

    @route('/tickets', ['GET'])
    @endpoint()
    def tickets(self, account_id=None, status=None, **kw):
        wanted = _csv_ids(account_id)
        extra = [('account_id', 'in', wanted)] if wanted else []
        if status in dict(TICKET_STATES):
            extra.append(('state', '=', status))
        return _json([self._ticket_payload(t) for t in self._tickets(extra)])

    @route('/tickets/options', ['GET'])
    @endpoint()
    def ticket_options(self, **kw):
        cats = request.env['resco.ticket.category'].sudo().search([])
        return _json({'categories': [{'id': c.id, 'name': c.name, 'to_account_manager': c.sam_message} for c in cats],
                      'max_files': payment_rules.MAX_PROOF_FILES, 'max_file_mb': payment_rules.MAX_PROOF_BYTES // (1024 * 1024)})

    @route('/tickets/<int:ticket_id>', ['GET'])
    @endpoint()
    def ticket(self, ticket_id, **kw):
        t = self._tickets([('id', '=', ticket_id)], limit=1)
        if not t:
            return _error(_('Ticket not found'), 404, 'not_found')
        return _json(self._ticket_payload(t, full=True))

    @route('/tickets', ['POST'])
    @endpoint()
    def ticket_create(self, **kw):
        data = _body()
        mine = self._accounts()
        account = mine.filtered(lambda a: a.id == data.get('account_id')) if isinstance(data.get('account_id'), int) else mine.browse()
        category = request.env['resco.ticket.category'].sudo().browse(data.get('category_id') if isinstance(data.get('category_id'), int) else 0).exists()
        if not account:
            return _error(_('Choose one of your accounts.'), 400, 'invalid')
        if not category or not category.active:
            return _error(_('Choose a category.'), 400, 'invalid')
        try:
            files = _decode_files(data.get('files'))
        except ValueError as e:
            return _error(str(e), 400, 'invalid')
        t = request.env['resco.ticket']._open_from_portal(
            request.env.user, account, category, str(data.get('subject') or ''), str(data.get('description') or ''), files)
        return _json(self._ticket_payload(t, full=True), status=201)

    @route('/tickets/<int:ticket_id>/reply', ['POST'])
    @endpoint()
    def ticket_reply(self, ticket_id, **kw):
        t = self._tickets([('id', '=', ticket_id)], limit=1)
        if not t:
            return _error(_('Ticket not found'), 404, 'not_found')
        data = _body()
        try:
            files = _decode_files(data.get('files'))
        except ValueError as e:
            return _error(str(e), 400, 'invalid')
        t._customer_reply(request.env.user, str(data.get('message') or ''), files)
        return _json(self._ticket_payload(t, full=True))

    @route('/tickets/<int:ticket_id>/file/<int:file_id>', ['GET'])
    @endpoint()
    def ticket_file(self, ticket_id, file_id, **kw):
        t = self._tickets([('id', '=', ticket_id)], limit=1)
        att = t._public_messages().attachment_ids.filtered(lambda a: a.id == file_id) if t else None
        if not att:
            return _error(_('File not found'), 404, 'not_found')
        request.env['resco.event.log']._log('download', account=t.account_id, ref=t.name, ip=_ip())
        name = re.sub(r'[^A-Za-z0-9._-]', '_', att.name)
        return request.make_response(base64.b64decode(att.datas), headers=[
            ('Content-Type', att.mimetype), ('Content-Disposition', f'attachment; filename="{name}"'),
            ('Cache-Control', 'private, no-store'), ('X-Content-Type-Options', 'nosniff')])

    # ------------------------------------------------------------------
    # AI assistant
    # ------------------------------------------------------------------
    def _chat_session(self, sid):
        return request.env['resco.chat.session'].sudo().search([('id', '=', sid), ('user_id', '=', request.env.user.id)], limit=1)

    @route('/chat/status', ['GET'])
    @endpoint()
    def chat_status(self, **kw):
        return _json({'enabled': request.env['resco.chat']._available()})

    @route('/chat/sessions', ['GET'])
    @endpoint()
    def chat_sessions(self, **kw):
        rows = request.env['resco.chat.session'].sudo().search([('user_id', '=', request.env.user.id)], limit=20)
        return _json([{'id': s.id, 'title': s.name, 'updated': fields.Datetime.to_string(s.write_date)} for s in rows])

    @route('/chat/sessions/<int:sid>', ['GET'])
    @endpoint()
    def chat_session(self, sid, **kw):
        s = self._chat_session(sid)
        if not s:
            return _error(_('Chat not found'), 404, 'not_found')
        return _json({'id': s.id, 'title': s.name, 'tickets': [{'id': t.id, 'reference': t.name} for t in s.ticket_ids],
                      'messages': [{'role': m.role, 'text': m.content} for m in s.message_ids.sorted('id')]})

    @route('/chat', ['POST'])
    @endpoint()
    def chat_send(self, **kw):
        Chat = request.env['resco.chat']
        if not Chat._available():
            return _error(_('The assistant is not available right now.'), 503, 'unavailable')
        data = _body()
        me = request.env.user
        sid = data.get('session_id')
        session = self._chat_session(sid) if isinstance(sid, int) else None
        if sid and not session:
            return _error(_('Chat not found'), 404, 'not_found')
        if not session:
            session = request.env['resco.chat.session'].sudo().create({'user_id': me.id})
        text, tickets = Chat.reply(me, session, str(data.get('message') or ''))
        return _json({'session_id': session.id, 'reply': text,
                      'tickets': [{'id': t.id, 'reference': t.name} for t in request.env['resco.ticket'].sudo().browse(tickets)]})

    @route('/chat/sessions/<int:sid>/ticket', ['POST'])
    @endpoint()
    def chat_to_ticket(self, sid, **kw):
        """The customer asks for a person: open a ticket that carries the whole conversation."""
        s = self._chat_session(sid)
        if not s:
            return _error(_('Chat not found'), 404, 'not_found')
        data = _body()
        mine = self._accounts()
        account = mine.filtered(lambda a: a.id == data.get('account_id')) if isinstance(data.get('account_id'), int) else mine[:1]
        category = request.env['resco.ticket.category'].sudo().browse(data.get('category_id') if isinstance(data.get('category_id'), int) else 0).exists()
        if not account or not category:
            return _error(_('Choose an account and a category.'), 400, 'invalid')
        subject = str(data.get('subject') or s.name or 'Help from the assistant chat')
        body = (str(data.get('note') or '').strip() or 'Please help me with the conversation below.') + '\n\n--- Chat ---\n' + s.transcript()
        t = request.env['resco.ticket']._open_from_portal(request.env.user, account, category, subject, body, source='ai_chat', chat=s)
        return _json(self._ticket_payload(t, full=True), status=201)

    # ------------------------------------------------------------------
    # Privacy notice with recorded consent, and portal popups (FR-WEB-062 to 065)
    # ------------------------------------------------------------------
    @route('/privacy', ['GET'])
    @endpoint()
    def privacy(self, **kw):
        n = request.env['resco.privacy.notice'].sudo()._current()
        if not n:
            return _json({'version': None, 'accepted': True})
        return _json({'version': n.version, 'title': n.title, 'paragraphs': [p.strip() for p in n.body.split('\n\n') if p.strip()],
                      'accepted': request.env['resco.privacy.consent']._accepted(request.env.user)})

    @route('/privacy/accept', ['POST'])
    @endpoint()
    def privacy_accept(self, **kw):
        version = _body().get('version')
        request.env['resco.privacy.consent']._accept(request.env.user, version if isinstance(version, int) else -1, ip=_ip())
        request.env['resco.event.log']._log('submission', ref='privacy consent', detail=f'version {version}', ip=_ip())
        return _json({'accepted': True})

    @route('/popups', ['GET'])
    @endpoint()
    def popups(self, **kw):
        return _json([{'id': p.id, 'title': p.title, 'paragraphs': [x.strip() for x in p.body.split('\n\n') if x.strip()],
                       'link_url': p.link_url if (p.link_url or '').startswith(('https://', '/')) else '', 'link_label': p.link_label or ''}
                      for p in request.env['resco.popup'].sudo()._for_user(request.env.user)])

    @route('/popups/<int:popup_id>/dismiss', ['POST'])
    @endpoint()
    def popup_dismiss(self, popup_id, **kw):
        p = request.env['resco.popup'].sudo().browse(popup_id).exists()
        if p and not request.env['resco.popup.dismissal'].sudo().search_count([('popup_id', '=', p.id), ('user_id', '=', request.env.user.id)]):
            request.env['resco.popup.dismissal'].sudo().create({'popup_id': p.id, 'user_id': request.env.user.id})
        return _json({'dismissed': True})
