import re

from odoo.tests import HttpCase, tagged

GOOD = {'contact_name': 'Juan Dela Cruz', 'partner_name': 'Acme Mills Corp', 'email_from': 'juan@acme.test',
        'phone': '0917 123 4567', 'location': 'Laguna', 'bill_range': '2m_10m', 'message': 'Please call after 2pm', 'consent': '1'}


@tagged('post_install', '-at_install', 'resco_leads')
class TestLeads(HttpCase):

    def _token(self):
        r = self.url_open('/get-in-touch')
        self.assertEqual(r.status_code, 200)
        self.assertIn('Contact me', r.text)
        return re.search(r'name="csrf_token" value="([^"]+)"', r.text).group(1)

    def _post(self, **over):
        data = dict(GOOD, csrf_token=self._token(), **over)
        return self.url_open('/get-in-touch', data=data, allow_redirects=False)

    def _leads(self):
        return self.env['crm.lead'].search([('email_from', '=', 'juan@acme.test')])

    def test_valid_submission_creates_lead_and_emails(self):
        icp = self.env['ir.config_parameter'].sudo()
        icp.set_param('resco_leads.notify_email', 'sales@resco.test')
        r = self._post()
        self.assertEqual((r.status_code, r.headers['Location'].endswith('/get-in-touch/thanks')), (303, True))
        lead = self._leads()
        self.assertEqual((lead.partner_name, lead.phone), ('Acme Mills Corp', '0917 123 4567'))
        self.assertIn('PHP 2 million to 10 million', lead.description)
        self.assertEqual(lead.source_id, self.env.ref('resco_leads.utm_source_partner_portal'))
        self.assertTrue(self.env['mail.mail'].search([('email_to', '=', 'sales@resco.test')]))
        self.assertTrue(self.env['mail.mail'].search([('email_to', '=', 'juan@acme.test')]))
        self.assertEqual(self.url_open('/get-in-touch/thanks').status_code, 200)

    def test_leads_go_to_resco_sales_team_by_default(self):
        team = self.env.ref('resco_leads.team_resco_sales')
        rep = self.env['res.users'].create({'name': 'Sales Rep', 'login': 'rep@resco.test', 'email': 'rep@resco.test'})
        team.member_ids = [(4, rep.id)]
        self._post()
        self.assertEqual(self._leads().team_id, team)
        self.assertTrue(self.env['mail.mail'].search([('email_to', 'like', 'rep@resco.test')]))

    def test_consent_and_validation_are_required(self):
        for bad in ({'consent': ''}, {'email_from': 'not-an-email'}, {'phone': '12'}, {'contact_name': ''}):
            r = self._post(**bad)
            self.assertEqual(r.status_code, 400, bad)
        self.assertFalse(self._leads())

    def test_honeypot_looks_successful_but_creates_nothing(self):
        r = self._post(website_url='http://spam.test')
        self.assertEqual(r.status_code, 303)
        self.assertFalse(self._leads())

    def test_rate_limit_per_ip(self):
        for i in range(5):
            self.assertEqual(self._post(email_from=f'juan@acme.test').status_code, 303)
        self.assertEqual(self._post().status_code, 400)
        self.assertEqual(len(self._leads()), 5)
