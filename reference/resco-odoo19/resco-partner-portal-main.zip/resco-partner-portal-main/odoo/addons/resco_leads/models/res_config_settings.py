from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    resco_leads_team_id = fields.Many2one('crm.team', 'Sales Team', config_parameter='resco_leads.team_id')
    resco_leads_user_id = fields.Many2one('res.users', 'Salesperson', config_parameter='resco_leads.user_id')
    resco_leads_notify_email = fields.Char('Notify This Email', config_parameter='resco_leads.notify_email',
                                           help='Optional shared mailbox that is emailed for every new lead.')
