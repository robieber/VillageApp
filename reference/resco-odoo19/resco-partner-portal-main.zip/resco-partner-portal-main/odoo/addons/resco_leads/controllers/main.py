"""Public 'Get in touch' form on the Partners Portal landing site. Creates a CRM lead for the sales team."""
import logging
import re
from datetime import timedelta

from odoo import _, fields, http
from odoo.http import request

_logger = logging.getLogger(__name__)
EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
BILL_RANGES = [
    ('lt_500k', 'Below PHP 500,000'), ('500k_2m', 'PHP 500,000 to 2 million'),
    ('2m_10m', 'PHP 2 million to 10 million'), ('gt_10m', 'Above PHP 10 million'), ('unsure', 'Not sure'),
]
MAX_PER_IP_PER_HOUR = 5


class RescoLeadsController(http.Controller):

    def _params(self):
        icp = request.env['ir.config_parameter'].sudo()
        return {'team': int(icp.get_param('resco_leads.team_id') or 0) or False,
                'user': int(icp.get_param('resco_leads.user_id') or 0) or False,
                'notify': (icp.get_param('resco_leads.notify_email') or '').strip()}

    @http.route('/get-in-touch', type='http', auth='public', website=True, methods=['GET'], sitemap=True)
    def form(self, **kw):
        return request.render('resco_leads.get_in_touch', {'bill_ranges': BILL_RANGES, 'values': {}, 'errors': {}})

    @http.route('/get-in-touch/thanks', type='http', auth='public', website=True, sitemap=False)
    def thanks(self, **kw):
        return request.render('resco_leads.get_in_touch_thanks', {})

    @http.route('/get-in-touch', type='http', auth='public', website=True, methods=['POST'], sitemap=False)
    def submit(self, **post):
        # Honeypot: real visitors never see this field. Pretend success so bots learn nothing.
        if (post.get('website_url') or '').strip():
            return request.redirect('/get-in-touch/thanks')
        v = {k: (post.get(k) or '').strip() for k in
             ('contact_name', 'partner_name', 'email_from', 'phone', 'location', 'bill_range', 'message')}
        errors = {}
        if not v['contact_name']:
            errors['contact_name'] = _('Please enter your name.')
        if not v['partner_name']:
            errors['partner_name'] = _('Please enter your company.')
        if not EMAIL_RE.match(v['email_from']):
            errors['email_from'] = _('Please enter a valid email address.')
        if len(re.sub(r'\D', '', v['phone'])) < 7:
            errors['phone'] = _('Please enter a phone number we can reach you on.')
        if v['bill_range'] not in dict(BILL_RANGES) and v['bill_range']:
            errors['bill_range'] = _('Please choose from the list.')
        if len(v['message']) > 2000:
            errors['message'] = _('Please keep the message under 2000 characters.')
        if not post.get('consent'):
            errors['consent'] = _('We need your consent to contact you.')
        ip = request.httprequest.remote_addr or ''
        Lead = request.env['crm.lead'].sudo()
        since = fields.Datetime.now() - timedelta(hours=1)
        if ip and Lead.search_count([('create_date', '>=', since), ('description', 'like', f'IP: {ip}')]) >= MAX_PER_IP_PER_HOUR:
            errors['rate'] = _('Too many requests from your network. Please try again later.')
        if errors:
            response = request.render('resco_leads.get_in_touch',
                                      {'bill_ranges': BILL_RANGES, 'values': v, 'errors': errors})
            response.status_code = 400
            return response

        p = self._params()
        bill = dict(BILL_RANGES).get(v['bill_range'], '')
        description = '\n'.join([
            f'Monthly electricity bill: {bill or "not given"}', f'Location: {v["location"] or "not given"}', '',
            v['message'], '', f'Consent to be contacted: given {fields.Datetime.now():%Y-%m-%d %H:%M} UTC',
            f'IP: {ip}'])
        vals = {
            'name': f'Website inquiry: {v["partner_name"]}', 'contact_name': v['contact_name'],
            'partner_name': v['partner_name'], 'email_from': v['email_from'], 'phone': v['phone'],
            'description': description, 'source_id': request.env.ref('resco_leads.utm_source_partner_portal').id,
        }
        if p['team']:
            vals['team_id'] = p['team']
        if p['user']:
            vals['user_id'] = p['user']
        lead = Lead.create(vals)
        self._notify(lead, p['notify'])
        return request.redirect('/get-in-touch/thanks')

    def _notify(self, lead, notify_email):
        Mail = request.env['mail.mail'].sudo()
        try:
            team = lead.team_id
            recipients = {e for e in [notify_email, *(team.member_ids | team.user_id).mapped('email')] if e}
            if recipients:
                Mail.create({'subject': _('New website inquiry: %s', lead.partner_name),
                             'body_html': '<p>%s</p><p>%s %s<br/>%s<br/>%s</p>' % (
                                 _('A new lead was submitted on the Partners Portal landing site.'),
                                 lead.contact_name, lead.partner_name or '', lead.email_from, lead.phone),
                             'email_to': ','.join(sorted(recipients)), 'auto_delete': True})
            Mail.create({'subject': _('We received your request'),
                         'body_html': '<p>%s</p>' % _('Thank you for your interest. Our team will contact you shortly.'),
                         'email_to': lead.email_from, 'auto_delete': True})
        except Exception:  # noqa: BLE001 - the lead is saved; a mail problem must not lose it
            _logger.exception('Lead notification failed for lead %s', lead.id)
