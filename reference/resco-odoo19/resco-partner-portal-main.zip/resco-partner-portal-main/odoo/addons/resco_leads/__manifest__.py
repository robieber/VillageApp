{
    'name': 'RESCo Leads',
    'version': '19.0.1.0.0',
    'category': 'Sales/CRM',
    'summary': 'Interested applicants ask to be contacted from the Partners Portal landing site',
    'license': 'LGPL-3',
    'depends': ['crm', 'website', 'resco_portal'],
    'data': [
        'data/resco_leads_data.xml',
        'views/templates.xml',
        'views/res_config_settings_views.xml',
    ],
    'installable': True,
    'application': False,
}
