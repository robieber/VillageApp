import csv, glob, io, os, random, zipfile, collections
from datetime import datetime, timedelta, date
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors

SRC = 'source/'  # the unzipped MPWR_Interim_CSV_Package
ORANGE, NAVY = colors.HexColor('#FF5016'), colors.HexColor('#0B1650')
def rd(path): return list(csv.DictReader(open(path, encoding='utf-8-sig', newline='')))
hdrs = {os.path.basename(f)[-10:-4]: rd(f) for f in sorted(glob.glob(SRC + 'MPWR_BILL_HDR_2*.csv'))}
comps = collections.defaultdict(list)
for f in sorted(glob.glob(SRC + 'MPWR_BILL_COMP_2*.csv')):
    for r in rd(f): comps[r['BILL_KEY']].append(r)
pays = {}
for f in glob.glob(SRC + 'MPWR_PAY_STAT_2*.csv'):
    for r in rd(f): pays[r['BILL_KEY']] = r
accts = {r['CSIN']: r for r in rd(SRC + 'MPWR_ACCOUNT_SAMPLE.csv')}
peso = lambda v: 'PHP {:,.2f}'.format(float(v or 0))

def make_pdf(h):
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=A4); W, H = A4
    c.setFillColor(NAVY); c.rect(0, H - 90, W, 90, fill=1, stroke=0)
    c.setFillColor(ORANGE); c.rect(0, H - 94, W, 4, fill=1, stroke=0)
    c.setFillColor(colors.white); c.setFont('Helvetica-Bold', 22); c.drawString(40, H - 52, 'MPower')
    c.setFont('Helvetica', 10); c.drawString(40, H - 70, 'Local Retail Electricity Supplier  |  SAMPLE BILL FOR TESTING ONLY')
    c.setFont('Helvetica-Bold', 13); c.drawRightString(W - 40, H - 52, 'Statement of Account')
    c.setFont('Helvetica', 10); c.drawRightString(W - 40, H - 70, 'Bill no. ' + h['BILL_NUMBER'])
    y = H - 130; c.setFillColor(NAVY); c.setFont('Helvetica-Bold', 12); c.drawString(40, y, h['ACCOUNT_NAME'])
    c.setFont('Helvetica', 10); c.setFillColor(colors.black)
    a = accts[h['CSIN']]
    for line in [f"CSIN {h['CSIN']}   |   {a['PARENT_COMPANY_NAME']}", h['SERVICE_ADDRESS'], f"Pricing product: {h['PRICING_PRODUCT']}   |   Contracted capacity: {float(h['CONTRACTED_CAPACITY_KW']):,.0f} kW"]:
        y -= 15; c.drawString(40, y, line)
    y -= 28
    box = [('Bill date', h['BILL_DATE']), ('Billing period', f"{h['BILLING_PERIOD_FROM']} to {h['BILLING_PERIOD_TO']}"), ('Due date', h['DUE_DATE']),
           ('Energy consumed', f"{float(h['ENERGY_KWH']):,.0f} kWh"), ('Peak demand', f"{float(h['PEAK_DEMAND_KW']):,.2f} kW")]
    for k, v in box:
        c.setFont('Helvetica-Bold', 10); c.drawString(40, y, k); c.setFont('Helvetica', 10); c.drawString(170, y, v); y -= 15
    y -= 14; c.setFillColor(ORANGE); c.rect(40, y - 4, W - 80, 20, fill=1, stroke=0); c.setFillColor(colors.white)
    c.setFont('Helvetica-Bold', 10); c.drawString(48, y + 2, 'Charges'); c.drawRightString(W - 48, y + 2, 'Amount')
    y -= 22; c.setFillColor(colors.black); c.setFont('Helvetica', 10)
    for r in sorted(comps[h['BILL_KEY']], key=lambda r: int(r['SORT_ORDER'])):
        c.drawString(48, y, r['COMPONENT_NAME']); c.drawRightString(W - 48, y, peso(r['AMOUNT'])); y -= 16
    rows = [('Current charges (before VAT)', h['CURRENT_CHARGES']), ('VAT', h['VAT_AMOUNT']), ('Previous balance', h['PREVIOUS_BALANCE']), ('Adjustments', h['ADJUSTMENTS'])]
    c.line(40, y + 8, W - 40, y + 8); y -= 6
    for k, v in rows:
        c.drawString(48, y, k); c.drawRightString(W - 48, y, peso(v)); y -= 16
    y -= 6; c.setFillColor(NAVY); c.rect(40, y - 6, W - 80, 26, fill=1, stroke=0); c.setFillColor(colors.white)
    c.setFont('Helvetica-Bold', 12); c.drawString(48, y + 2, 'TOTAL AMOUNT DUE'); c.drawRightString(W - 48, y + 2, peso(h['TOTAL_AMOUNT_DUE']))
    c.setFillColor(colors.grey); c.setFont('Helvetica-Oblique', 8)
    c.drawString(40, 40, 'Fictitious data created for testing the MPower Partners Portal. This is not a real bill.')
    c.showPage(); c.save(); return buf.getvalue()

def ctrl_ok(name):  # CTRL files are used as supplied
    return open(SRC + name, 'rb').read()

# ---- 1 accounts
with zipfile.ZipFile('MPWR_LOAD_1_ACCOUNTS.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(SRC + 'MPWR_ACCOUNT_SAMPLE.csv', 'MPWR_ACCOUNT_SAMPLE.csv')

# ---- 2 bills
n = 0
with zipfile.ZipFile('MPWR_LOAD_2_BILLS_12_MONTHS.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for ym in sorted(hdrs):
        for kind in ('BILL_HDR', 'BILL_COMP', 'PAY_STAT', 'CTRL'):
            z.write(f'{SRC}MPWR_{kind}_{ym}.csv', f'MPWR_{kind}_{ym}.csv')
        for h in hdrs[ym]:
            z.writestr(h['PDF_FILE_NAME'], make_pdf(h)); n += 1
print('pdfs', n)

# ---- 3 hourly readings, 1 Aug to 21 Oct 2026, scaled to each account's billed energy
random.seed(7)
energy = {(h['CSIN'], int(h['BILL_YEAR']), int(h['BILL_MONTH'])): float(h['ENERGY_KWH']) for ym in hdrs for h in hdrs[ym]}
def shape(hour, weekend, product):
    base = 0.55 + 0.45 * max(0.0, __import__('math').sin((hour - 5) / 15 * __import__('math').pi)) ** 1.5
    return base * (0.8 if weekend else 1.0)
rows = []
d, end = date(2026, 8, 1), date(2026, 10, 21)
days = []
while d <= end: days.append(d); d += timedelta(days=1)
for csin, a in accts.items():
    cap = float(a['CONTRACTED_CAPACITY_KW'])
    for key_month in ((2026, 8), (2026, 9), (2026, 10)):
        mdays = [x for x in days if (x.year, x.month) == key_month]
        kwh_month = energy.get((csin,) + (key_month if key_month != (2026, 10) else (2026, 9)))
        weights = [(x, hh, shape(hh, x.weekday() >= 5, a['PRICING_PRODUCT']) * random.uniform(0.93, 1.07)) for x in mdays for hh in range(24)]
        full_days = (date(key_month[0] + (key_month[1] == 12), key_month[1] % 12 + 1, 1) - date(*key_month, 1)).days
        total_w = sum(w for _, _, w in weights) * (full_days / len(mdays))
        for x, hh, w in weights:
            kwh = kwh_month * w / total_w
            ts = datetime(x.year, x.month, x.day, hh).strftime('%Y-%m-%dT%H:00:00+08:00')
            rows.append((csin, ts, round(kwh, 3), round(min(kwh * random.uniform(1.0, 1.08), cap), 2)))
buf = io.StringIO(); w = csv.writer(buf, lineterminator='\r\n'); w.writerow(['CSIN', 'INTERVAL_START', 'KWH', 'KW_DEMAND']); w.writerows(rows)
with zipfile.ZipFile('MPWR_LOAD_3_HOURLY.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('MPWR_ENERGY_HRLY_202608_202610.csv', buf.getvalue())
print('hourly rows', len(rows))
