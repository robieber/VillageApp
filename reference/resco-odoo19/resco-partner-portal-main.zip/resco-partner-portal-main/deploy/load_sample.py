# Load the fictitious MPower sample data (10 customers, 12 months of bills, payments, hourly readings).
# Run:  docker compose run --rm -T -v ~/resco-partner-portal/sample-data:/sample-data:ro \
#         -e SAMPLE_PASSWORD='<password for the new portal users>' odoo odoo shell -d resco < load_sample.py
import os
import zipfile

folder = os.environ.get('SAMPLE_DIR', '/sample-data')
password = os.environ.get('SAMPLE_PASSWORD') or None
for name in ('MPWR_LOAD_1_ACCOUNTS.zip', 'MPWR_LOAD_2_BILLS_12_MONTHS.zip', 'MPWR_LOAD_3_HOURLY.zip'):
    with zipfile.ZipFile(os.path.join(folder, name)) as z:
        files = {n: z.read(n) for n in z.namelist()}
    batch = env['resco.upload.batch'].load('manual', files, overwrite=True, source_name=name,  # noqa: F821
                                           initial_password=password)
    env.cr.commit()  # noqa: F821
    print(f'{name}: {batch.summary}')
