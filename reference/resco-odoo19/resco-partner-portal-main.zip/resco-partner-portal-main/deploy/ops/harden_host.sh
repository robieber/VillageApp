#!/usr/bin/env bash
# Turn on automatic security updates for the VM (Debian/Ubuntu). Safe to run again.
#   sudo bash deploy/ops/harden_host.sh            # reboot at 03:30 Philippine time when an update needs it
#   sudo AUTO_REBOOT=false bash deploy/ops/harden_host.sh   # install updates but never reboot by itself
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Run with sudo" >&2; exit 1; }
AUTO_REBOOT="${AUTO_REBOOT:-true}"

export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq unattended-upgrades apt-listchanges needrestart >/dev/null

# Reboot time is read in the VM's own timezone. 03:30 PHT is 19:30 UTC.
VM_TZ="$(timedatectl show -p Timezone --value 2>/dev/null || echo UTC)"
case "$VM_TZ" in
  Asia/Manila|Asia/Singapore) WHEN="03:30" ;;
  *)                          WHEN="19:30" ;;
esac

cat > /etc/apt/apt.conf.d/20auto-upgrades <<'CFG'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
CFG

# The distribution's default 50unattended-upgrades already limits updates to the security archive.
# Only the rules below are ours, so a package upgrade cannot change them.
cat > /etc/apt/apt.conf.d/52resco-unattended <<CFG
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "${AUTO_REBOOT}";
Unattended-Upgrade::Automatic-Reboot-WithUsers "true";
Unattended-Upgrade::Automatic-Reboot-Time "${WHEN}";
Unattended-Upgrade::SyslogEnable "true";
CFG

# Docker brings the containers back after a reboot: confirm it starts at boot.
systemctl enable docker >/dev/null 2>&1 || true
systemctl enable --now unattended-upgrades >/dev/null 2>&1 || true
unattended-upgrade --dry-run >/dev/null 2>&1 && echo "Dry run of unattended-upgrade: OK" || echo "Dry run reported a problem: run 'sudo unattended-upgrade --dry-run -d' to see it"
echo "Automatic security updates are on. Auto reboot: ${AUTO_REBOOT} at ${WHEN} (${VM_TZ})."
echo "History: /var/log/unattended-upgrades/unattended-upgrades.log"
