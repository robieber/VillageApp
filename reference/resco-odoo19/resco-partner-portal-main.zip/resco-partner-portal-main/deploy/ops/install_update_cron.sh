#!/usr/bin/env bash
# Run update_images.sh on the first Sunday of every month at 03:00 Philippine time.
# Enable this only when a staging copy exists, or when you accept the automatic rollback as your safety net.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
USER_NAME="$(id -un)"
DEST=/home/deploy/wave0-bin
mkdir -p "$DEST"; install -m 755 "$HERE/update_images.sh" "$DEST/update_images.sh"
VM_TZ="$(timedatectl show -p Timezone --value 2>/dev/null || echo UTC)"
case "$VM_TZ" in
  Asia/Manila|Asia/Singapore) WHEN="0 3" ;;
  *)                          WHEN="0 19" ;;    # 03:00 PHT is 19:00 UTC the day before; first-Sunday check uses the VM date
esac
sudo tee /etc/cron.d/resco-update >/dev/null <<CRONTAB
# Managed by deploy/ops/install_update_cron.sh
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
$WHEN * * 0 $USER_NAME [ "\$(date +\\%d)" -le 7 ] && $DEST/update_images.sh >> /home/deploy/backups/cron-update.out 2>&1
CRONTAB
sudo chmod 644 /etc/cron.d/resco-update
echo "Installed /etc/cron.d/resco-update (first Sunday, $WHEN, $VM_TZ). Log: /home/deploy/backups/update.log"
