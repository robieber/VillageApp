#!/usr/bin/env bash
# Refresh the container images (Odoo base image, PostgreSQL 16 minor, Caddy) and restart, with a backup first and an
# automatic rollback of the Odoo image if the health check fails.
#   bash deploy/ops/update_images.sh            # run by hand, or by the monthly cron job
# Does NOT upgrade Odoo to a new major version, and does not touch the database schema.
set -euo pipefail
PROD_DIR="${PROD_DIR:-/home/deploy/resco-partner-portal}"
BACKUP_DIR="${BACKUP_DIR:-/home/deploy/backups}"
DOCKER="${DOCKER:-sudo docker}"
BACKUP_BIN="${BACKUP_BIN:-/home/deploy/wave0-bin/backup_prod.sh}"
LOG="$BACKUP_DIR/update.log"
mkdir -p "$BACKUP_DIR"
log() { printf '%s %s\n' "$(date '+%F %T %Z')" "$*" | tee -a "$LOG"; logger -t resco-update -- "$*" 2>/dev/null || true; }

cd "$PROD_DIR/deploy"
log "update start"
if [ -x "$BACKUP_BIN" ]; then "$BACKUP_BIN" || { log "ABORT: backup failed, nothing was changed"; exit 1; }
else log "WARNING: $BACKUP_BIN not found, continuing without a fresh backup"; fi

PREV="resco-odoo:19-prev"
$DOCKER tag resco-odoo:19 "$PREV" 2>/dev/null && log "kept the current Odoo image as $PREV" || log "no current image to keep"

health() {  # Odoo answers /web/health from inside its own container
  for _ in $(seq 1 30); do
    if $DOCKER compose exec -T odoo python3 -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://localhost:8069/web/health', timeout=5).status == 200 else 1)" 2>/dev/null; then return 0; fi
    sleep 5
  done
  return 1
}

log "pulling base images and rebuilding"
$DOCKER compose pull db caddy
$DOCKER compose build --pull odoo
$DOCKER compose up -d
if health; then
  $DOCKER image prune -f >/dev/null 2>&1 || true
  log "update OK"
else
  log "health check FAILED: rolling Odoo back to $PREV"
  $DOCKER tag "$PREV" resco-odoo:19
  $DOCKER compose up -d --no-build odoo
  health && log "rolled back, portal is up on the previous image" || log "ROLLBACK ALSO UNHEALTHY: check 'docker compose logs odoo'"
  exit 1
fi
