#!/usr/bin/env python3
"""Small, dependency-free, fail-closed editors. Never print configuration values."""
import pathlib
import re
import sys

TUNING = dict(workers='2', max_cron_threads='1', limit_memory_soft='1073741824',
              limit_memory_hard='1342177280', limit_request='8192',
              limit_time_cpu='120', limit_time_real='240', gevent_port='8072')


def conf(text, changes):
    lines = text.splitlines(keepends=True)
    out, section, seen = [], '', set()
    for line in lines:
        heading = re.match(r'\s*\[([^]]+)\]', line)
        if heading:
            if section == 'options':
                out.extend(f'{k} = {v}\n' for k, v in changes.items() if k not in seen)
            section = heading[1].lower()
        key = re.match(r'\s*([\w_]+)\s*=', line)
        if section == 'options' and key and key[1] in changes:
            if key[1] not in seen:
                out.append(f'{key[1]} = {changes[key[1]]}\n')
                seen.add(key[1])
        else:
            out.append(line if line.endswith('\n') else line + '\n')
    if section == 'options':
        out.extend(f'{k} = {v}\n' for k, v in changes.items() if k not in seen)
    if not re.search(r'^\s*\[options\]', text, re.M):
        raise ValueError('missing [options] section')
    return ''.join(out)


STAGING = '''# BEGIN WAVE0 STAGING
{$STAGING_HOST} {
    encode gzip
    @dbm path /web/database*
    # route preserves explicit order: database manager blocked before authentication.
    route {
        respond @dbm 404
        basic_auth {
            staging {$STAGING_BASIC_AUTH_HASH}
        }
        reverse_proxy odoo-staging:8069
    }
}
# END WAVE0 STAGING
'''


def caddy(text):
    # Preserve all existing directives; locate only the approved production site.
    match = re.search(r'^\{\$PORTAL_HOST\}\s*\{\s*$', text, re.M)
    if not match:
        raise ValueError('expected {$PORTAL_HOST} site; review customized Caddyfile manually')
    start, depth, end = match.end(), 1, None
    # Count structural braces, excluding env placeholders and comments.
    pos = start
    for line in text[start:].splitlines(keepends=True):
        clean = re.sub(r'\{\$[^}]+\}', '', line.split('#', 1)[0])
        depth += clean.count('{') - clean.count('}')
        pos += len(line)
        if depth == 0:
            end = pos
            break
    if end is None:
        raise ValueError('unbalanced production site')
    block = text[start:end]
    # Drop obsolete instructional comments and the two known commented ws lines.
    if not re.search(r'^\s*reverse_proxy odoo:8069\s*$', block, re.M):
        raise ValueError('expected production reverse_proxy odoo:8069; manual review required')
    if not re.search(r'^\s*reverse_proxy @ws odoo:8072\s*$', block, re.M):
        block = re.sub(r'^\s*# (?:With workers.*|uncomment these.*|@ws path.*|reverse_proxy @ws.*)\n', '', block, flags=re.M)
        block = '\n    @ws path /websocket*\n    reverse_proxy @ws odoo:8072\n' + block
    text = text[:start] + block + text[end:]
    text = re.sub(r'# BEGIN WAVE0 STAGING\n.*?# END WAVE0 STAGING\n?', '', text, flags=re.S)
    if '{$STAGING_HOST}' in text:
        raise ValueError('unmanaged staging site exists; review manually')
    return text.rstrip() + '\n\n' + STAGING


def env_update(text, changes):
    # These values are hostnames or bcrypt hashes. Single quotes stop Compose interpolation.
    for key, value in changes.items():
        if "'" in value or '\n' in value:
            raise ValueError('unsafe env value')
        replacement = f"{key}='{value}'"
        pattern = rf'^{re.escape(key)}=.*$'
        if re.search(pattern, text, re.M):
            text = re.sub(pattern, lambda _: replacement, text, flags=re.M)
        else:
            text = text.rstrip() + '\n' + replacement + '\n'
    return text


if __name__ == '__main__':
    mode, filename, *args = sys.argv[1:]
    path = pathlib.Path(filename)
    text = path.read_text()
    if mode == 'tune':
        text = conf(text, TUNING)
    elif mode == 'caddy':
        text = caddy(text)
    elif mode == 'addons':
        base = pathlib.Path(args[0] if args else '/home/deploy/oca-addons')
        roots = sorted(p.name for p in base.iterdir() if p.is_dir() and (p / '.git').exists()) if base.is_dir() else []
        current = re.search(r'^\s*addons_path\s*=\s*(.*)$', text, re.M)
        parts = [x.strip() for x in (current[1] if current else '/mnt/extra-addons,/usr/lib/python3/dist-packages/odoo/addons').split(',') if x.strip()]
        parts = [x for x in parts if not x.startswith('/mnt/oca/')] + ['/mnt/oca/' + p for p in roots]
        text = conf(text, {'addons_path': ','.join(parts)})
    elif mode == 'env':
        text = env_update(text, dict(x.split('=', 1) for x in args))
    else:
        raise ValueError(mode)
    # Write in place: preserves permissions and bind-mount inode.
    with path.open('w') as stream:
        stream.write(text)
