#!/usr/bin/env bash
# Shared helpers for Wave 0 server scripts. Source this file; never print secrets from here.
# shellcheck disable=SC2034
PROD_DIR="${PROD_DIR:-/home/deploy/resco-partner-portal}"
PROD_DEPLOY="$PROD_DIR/deploy"
STAGING_DIR="${STAGING_DIR:-/home/deploy/resco-staging}"
OCA_DIR="${OCA_DIR:-/home/deploy/oca-addons}"
BACKUP_DIR="${BACKUP_DIR:-/home/deploy/backups}"
KIT_DIR="${KIT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
TS="$(date +%Y%m%d-%H%M%S)"
DOCKER="${DOCKER:-sudo docker}"

log() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
docker_() { $DOCKER "$@"; }

# envval FILE KEY: print a value from a .env file (no sourcing, handles $ and quotes).
envval() {
  local v
  v="$(grep -E "^$2=" "$1" 2>/dev/null | tail -n1 | cut -d= -f2- || true)"
  v="${v#\'}"; v="${v%\'}"; v="${v#\"}"; v="${v%\"}"
  printf '%s' "$v"
}

# backup_file FILE: copy to FILE.bak-<timestamp> (sudo-free, keeps mode); prints nothing.
backup_file() {
  if [ -e "$1" ]; then cp -p "$1" "$1.bak-$TS"; log "backup: $1.bak-$TS"; fi
}

# prod_compose ARGS...: docker compose in the production deploy dir (auto-loads docker-compose.override.yml).
prod_compose() { (cd "$PROD_DEPLOY" && $DOCKER compose "$@"); }
staging_compose() { (cd "$STAGING_DIR/deploy" && $DOCKER compose "$@"); }

# wait_odoo_health COMPOSE_FN SERVICE [TRIES]: poll /web/health inside the container.
wait_odoo_health() {
  local fn="$1" svc="$2" tries="${3:-45}" i
  for i in $(seq 1 "$tries"); do
    if $fn exec -T "$svc" python3 -c "import urllib.request; urllib.request.urlopen('http://localhost:8069/web/health', timeout=5)" >/dev/null 2>&1; then
      log "$svc healthy"; return 0
    fi
    sleep 4
  done
  log "$svc did not become healthy"; return 1
}

# https_status HOST PATH [extra curl args]: HTTP code, resolved to localhost so it works on the VM itself.
https_status() {
  local host="$1" path="$2"; shift 2
  curl -sk -o /dev/null -w '%{http_code}' --max-time 8 --resolve "$host:443:127.0.0.1" "$@" "https://$host$path" 2>/dev/null || true
}

ws_status() {
  https_status "$1" /websocket -H 'Connection: Upgrade' -H 'Upgrade: websocket' \
    -H 'Sec-WebSocket-Version: 13' -H 'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ=='
}

# rand N: URL-safe random string.
rand() { openssl rand -base64 48 | tr -dc 'A-Za-z0-9' | head -c "${1:-24}"; }
