#!/usr/bin/env bash
# Wave 0 / fetch_oca: shallow-clone or update OCA repos listed in deploy/oca/repos.txt into /home/deploy/oca-addons.
# Updates addons_path in prod and staging odoo.conf. With an empty list nothing changes.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$HERE/lib.sh"

LIST="${REPOS_FILE:-$KIT_DIR/oca/repos.txt}"
[ -f "$LIST" ] || die "missing $LIST"
mkdir -p "$OCA_DIR"
COUNT=0
while read -r repo branch _; do
  case "${repo:-}" in ""|\#*) continue ;; esac
  [[ "$repo" =~ ^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || die "bad repo name: $repo"
  [[ "${branch:-}" =~ ^[A-Za-z0-9_./-]+$ ]] || die "bad branch for $repo"
  dir="$OCA_DIR/${repo#*/}"
  COUNT=$((COUNT + 1))
  if [ -d "$dir/.git" ]; then
    log "update $repo ($branch)"
    git -C "$dir" fetch --depth 1 origin "$branch"
    git -C "$dir" checkout -q -B "$branch" FETCH_HEAD
  else
    log "clone $repo ($branch)"
    git clone --depth 1 --branch "$branch" "https://github.com/$repo.git" "$dir"
  fi
done < "$LIST"
log "$COUNT repo(s) processed"

CHANGED=0
for conf in "$PROD_DEPLOY/odoo.conf" "$STAGING_DIR/deploy/odoo.conf"; do
  [ -f "$conf" ] || continue
  before="$(sha256sum < "$conf")"
  if [ "$COUNT" -gt 0 ] || grep -q '/mnt/oca/' "$conf"; then
    backup_file "$conf"
    python3 "$HERE/edit_config.py" addons "$conf" "$OCA_DIR"
  fi
  [ "$before" = "$(sha256sum < "$conf")" ] || { CHANGED=1; log "addons_path updated in $conf"; }
done
if [ "$CHANGED" = 1 ]; then
  log "addons_path changed: restart odoo (prod: compose restart odoo; staging via deploy-staging) and update the apps list"
else
  log "no config change"
fi
