#!/usr/bin/env bash
# Wave 0 / status: read-only overview. Prints no secrets.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$HERE/lib.sh"

echo "== machine"; uname -n; nproc | sed 's/^/cpus: /'; free -m
echo "== disk"; df -h / /home/deploy 2>/dev/null | awk '!seen[$0]++'
echo "== containers"
$DOCKER ps --format 'table {{.Names}}\t{{.Status}}\t{{.Image}}'
echo "== docker stats"
$DOCKER stats --no-stream --format 'table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}' || true
echo "== workers / conf (prod)"
grep -E '^(workers|max_cron_threads|limit_memory_(soft|hard)|gevent_port)\b' "$PROD_DEPLOY/odoo.conf" 2>/dev/null || echo "odoo.conf not found"
echo "== backups"
if [ -f "$BACKUP_DIR/backup.log" ]; then tail -n 3 "$BACKUP_DIR/backup.log"; else echo "no backup log yet"; fi
find "$BACKUP_DIR" -maxdepth 1 -mindepth 1 -type d -name '[0-9]*' 2>/dev/null | sort | tail -n 3
[ -f /etc/cron.d/resco-backup ] && echo "cron: installed" || echo "cron: NOT installed"
echo "== staging"
[ -f "$STAGING_DIR/deploy/.env" ] && echo "staging stack: present" || echo "staging stack: not set up"
echo "== resco_portal version"
modver() { # fn container-service db
  $1 exec -T db psql -U odoo -d "$2" -At -c "SELECT name||' '||state||' '||coalesce(latest_version,'') FROM ir_module_module WHERE name IN ('resco_portal','resco_leads','resco_website')" 2>/dev/null || echo "n/a"
}
echo "prod (resco):"; modver prod_compose resco
if [ -d "$STAGING_DIR/deploy" ]; then echo "staging (resco_staging):"; modver staging_compose resco_staging; fi
echo "== network / edge"
$DOCKER network inspect resco-edge >/dev/null 2>&1 && echo "resco-edge: present" || echo "resco-edge: missing"
echo "== oca repos"; ls -1 "$OCA_DIR" 2>/dev/null || echo "none"

echo "== ownership of production deploy files (Wave 0 scripts need read/write as $(id -un))"
stat -c '%U:%G %a %n' /home/deploy/resco-partner-portal/deploy /home/deploy/resco-partner-portal/deploy/* /home/deploy/resco-partner-portal/deploy/.env 2>/dev/null || true
