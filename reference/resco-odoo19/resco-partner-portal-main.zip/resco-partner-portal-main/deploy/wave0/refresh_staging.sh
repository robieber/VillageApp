#!/usr/bin/env bash
# Wave 0 / refresh_staging: replace staging data with a neutralised copy of production.
# Prod keeps running (pg_dump is online, prod is only read). The new copy is built as resco_staging_new,
# neutralised, then swapped in; the previous staging DB is dropped only after staging is healthy.
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$HERE/lib.sh"

S="$STAGING_DIR"
SENV="$S/deploy/.env"
PROD_DB="${PROD_DB:-resco}"
NEW=resco_staging_new
CUR=resco_staging
OLD=resco_staging_old
[ -f "$SENV" ] || die "run setup_staging first"
STAGING_HOST="$(envval "$SENV" PORTAL_HOST)"
ADMIN_PW="$(envval "$SENV" ADMIN_PASSWORD)"
USED="$(df --output=pcent /home/deploy | tail -n1 | tr -dc 0-9)"
[ "$USED" -le 80 ] || die "disk ${USED}% used; free space first"

PROD_DBC="$(prod_compose ps -q db)"; PROD_ODOO="$(prod_compose ps -q odoo)"
[ -n "$PROD_DBC" ] && [ -n "$PROD_ODOO" ] || die "production db/odoo containers not running"
spsql() { staging_compose exec -T db psql -U odoo -v ON_ERROR_STOP=1 -q "$@"; }

swap_done=0
cleanup_on_fail() {
  log "FAILED. Production untouched. Cleaning partial copy."
  staging_compose stop odoo >/dev/null 2>&1 || true
  spsql -d postgres -c "DROP DATABASE IF EXISTS $NEW" >/dev/null 2>&1 || true
  staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "rm -rf /var/lib/odoo/filestore/$NEW" >/dev/null 2>&1 || true
  if [ "$swap_done" = 1 ]; then
    log "swap had happened; restoring previous staging DB"
    spsql -d postgres -c "DROP DATABASE IF EXISTS $CUR" -c "ALTER DATABASE $OLD RENAME TO $CUR" >/dev/null 2>&1 || true
    staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "rm -rf /var/lib/odoo/filestore/$CUR && mv /var/lib/odoo/filestore/$OLD /var/lib/odoo/filestore/$CUR" >/dev/null 2>&1 || true
  fi
  staging_compose up -d odoo >/dev/null 2>&1 || true
  exit 1
}
trap cleanup_on_fail ERR

log "making sure staging db is up"
staging_compose up -d db
for _ in $(seq 1 30); do staging_compose exec -T db pg_isready -U odoo >/dev/null 2>&1 && break; sleep 2; done
log "stopping staging odoo"
staging_compose stop odoo

log "recreating $NEW and streaming pg_dump of '$PROD_DB' from production (online dump)"
spsql -d postgres -c "DROP DATABASE IF EXISTS $NEW" -c "CREATE DATABASE $NEW OWNER odoo"
docker_ exec "$PROD_DBC" pg_dump -U odoo -Fc --no-owner "$PROD_DB" \
  | staging_compose exec -T db pg_restore -U odoo -d "$NEW" --no-owner --exit-on-error
log "database restored"

log "copying filestore"
staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "rm -rf /var/lib/odoo/filestore/$NEW && mkdir -p /var/lib/odoo/filestore/$NEW"
if docker_ exec "$PROD_ODOO" test -d "/var/lib/odoo/filestore/$PROD_DB"; then
  docker_ exec "$PROD_ODOO" tar -C "/var/lib/odoo/filestore/$PROD_DB" -cf - . \
    | staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "tar -C /var/lib/odoo/filestore/$NEW -xf - && chown -R odoo:odoo /var/lib/odoo/filestore/$NEW"
else
  log "WARNING: no production filestore found at filestore/$PROD_DB"
fi

log "odoo neutralize"
staging_compose run --rm --no-deps -T odoo odoo neutralize -d "$NEW" --no-http

log "extra neutralisation (SQL)"
spsql -d "$NEW" <<SQL
UPDATE ir_config_parameter SET value = 'https://$STAGING_HOST' WHERE key = 'web.base.url';
INSERT INTO ir_config_parameter (key, value, create_date, write_date) SELECT 'web.base.url', 'https://$STAGING_HOST', now(), now()
  WHERE NOT EXISTS (SELECT 1 FROM ir_config_parameter WHERE key = 'web.base.url');
UPDATE ir_config_parameter SET value = 'True' WHERE key = 'web.base.url.freeze';
INSERT INTO ir_config_parameter (key, value, create_date, write_date) SELECT 'web.base.url.freeze', 'True', now(), now()
  WHERE NOT EXISTS (SELECT 1 FROM ir_config_parameter WHERE key = 'web.base.url.freeze');
-- never auto-email invoices from staging
UPDATE ir_config_parameter SET value = 'False' WHERE key = 'resco_portal.auto_send';
INSERT INTO ir_config_parameter (key, value, create_date, write_date) SELECT 'resco_portal.auto_send', 'False', now(), now()
  WHERE NOT EXISTS (SELECT 1 FROM ir_config_parameter WHERE key = 'resco_portal.auto_send');
-- no outgoing or incoming mail servers, drop queued mail
-- keep the dummy server that 'odoo neutralize' inserts (smtp_host 'invalid'); it blocks fallback to odoo.conf SMTP
UPDATE ir_mail_server SET active = false WHERE smtp_host IS DISTINCT FROM 'invalid';
UPDATE mail_mail SET state = 'cancel' WHERE state = 'outgoing';
DO \$\$ BEGIN
  IF to_regclass('fetchmail_server') IS NOT NULL THEN UPDATE fetchmail_server SET active = false, state = 'draft'; END IF;
END \$\$;
SQL

log "setting staging admin password"
staging_compose run --rm --no-deps -T -e ADMIN_PW="$ADMIN_PW" odoo odoo shell -d "$NEW" --no-http <<'PY' >/dev/null
import os
env.ref('base.user_admin').password = os.environ['ADMIN_PW']
env.cr.commit()
PY

log "swapping $NEW into place"
spsql -d postgres -c "DROP DATABASE IF EXISTS $OLD"
staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "rm -rf /var/lib/odoo/filestore/$OLD"
spsql -d postgres -c "SELECT 1 FROM pg_database WHERE datname='$CUR'" -t | grep -q 1 && spsql -d postgres -c "ALTER DATABASE $CUR RENAME TO $OLD"
staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "[ -d /var/lib/odoo/filestore/$CUR ] && mv /var/lib/odoo/filestore/$CUR /var/lib/odoo/filestore/$OLD || true"
spsql -d postgres -c "ALTER DATABASE $NEW RENAME TO $CUR"
staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "mv /var/lib/odoo/filestore/$NEW /var/lib/odoo/filestore/$CUR"
swap_done=1

log "starting staging odoo"
staging_compose up -d odoo
wait_odoo_health staging_compose odoo 60

trap - ERR
log "health ok: dropping previous staging copy"
spsql -d postgres -c "DROP DATABASE IF EXISTS $OLD" || true
staging_compose run --rm --no-deps -T --user root --entrypoint sh odoo -c "rm -rf /var/lib/odoo/filestore/$OLD" || true
VER="$(spsql -d "$CUR" -At -c "SELECT latest_version FROM ir_module_module WHERE name='resco_portal'" 2>/dev/null || true)"
log "OK: staging refreshed from prod. resco_portal=$VER  https://$STAGING_HOST (basic auth, then Odoo login 'admin' with ADMIN_PASSWORD from $SENV)"
