#!/usr/bin/env python3
"""Offline checks for edit_config.py. Run: python3 deploy/wave0/test_edit_config.py (optionally CADDY=/path/to/caddy)."""
import os
import pathlib
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import edit_config as e  # noqa: E402

DEPLOY = HERE.parent


def parse(text):
    return {k.strip(): v.strip() for k, _, v in (l.partition('=') for l in text.splitlines() if '=' in l and not l.startswith((';', '#')))}


def test_conf():
    src = (DEPLOY / 'odoo.conf').read_text().replace('CHANGE_ME_MASTER_PASSWORD', 'S3cret!pw')
    out = e.conf(src, e.TUNING)
    got = parse(out)
    for k, v in e.TUNING.items():
        assert got[k] == v, k
        assert out.count(f'\n{k} =') == 1, f'{k} duplicated'
    assert got['admin_passwd'] == 'S3cret!pw'
    for k in ('db_name', 'dbfilter', 'list_db', 'proxy_mode', 'data_dir', 'log_level'):
        assert got[k] == parse(src)[k], k
    assert e.conf(out, e.TUNING) == out, 'not idempotent'
    # missing keys are appended inside [options]
    out2 = e.conf('[options]\nadmin_passwd = x\n', e.TUNING)
    assert parse(out2)['workers'] == '2' and parse(out2)['admin_passwd'] == 'x'
    # trailing other section keeps keys in [options]
    out3 = e.conf('[options]\nadmin_passwd = x\n[other]\na = 1\n', e.TUNING)
    assert out3.index('workers') < out3.index('[other]')
    try:
        e.conf('nothing', {})
        raise SystemExit('expected error')
    except ValueError:
        pass


def test_addons():
    with tempfile.TemporaryDirectory() as d:
        base = pathlib.Path(d)
        (base / 'helpdesk' / '.git').mkdir(parents=True)
        (base / 'empty').mkdir()
        conf = base / 'odoo.conf'
        orig = (DEPLOY / 'odoo.conf').read_text()
        conf.write_text(orig)
        for _ in range(2):
            subprocess.run([sys.executable, str(HERE / 'edit_config.py'), 'addons', str(conf), d], check=True)
        got = parse(conf.read_text())['addons_path']
        assert got == '/mnt/extra-addons,/usr/lib/python3/dist-packages/odoo/addons,/mnt/oca/helpdesk', got
        (base / 'none').mkdir()
        conf.write_text(orig)
        subprocess.run([sys.executable, str(HERE / 'edit_config.py'), 'addons', str(conf), str(base / 'none')], check=True)
        assert parse(conf.read_text())['addons_path'] == parse(orig)['addons_path']


def test_caddy():
    src = (DEPLOY / 'Caddyfile').read_text()
    out = e.caddy(src)
    assert '@ws path /websocket*' in out and 'reverse_proxy @ws odoo:8072' in out
    assert 'reverse_proxy odoo:8069' in out and '{$STAGING_HOST}' in out
    assert 'respond @dbm 404' in out and 'basic_auth' in out and 'odoo-staging:8069' in out
    assert e.caddy(out) == out, 'not idempotent'
    # a VM file where the ws lines were already uncommented by hand
    manual = src.replace('# @ws path', '@ws path').replace('# reverse_proxy @ws', 'reverse_proxy @ws')
    out_m = e.caddy(manual)
    assert out_m.count('reverse_proxy @ws odoo:8072') == 1
    try:
        e.caddy('example.com {\n respond ok\n}\n')
        raise SystemExit('expected error')
    except ValueError:
        pass
    caddy = os.environ.get('CADDY')
    if caddy:
        env = dict(os.environ, PORTAL_HOST='portal.example.test', STAGING_HOST='staging.example.test',
                   STAGING_BASIC_AUTH_HASH='$2a$14$abcdefghijklmnopqrstuuABCDEFGHIJKLMNOPQRSTUVWXYZ01234')
        with tempfile.NamedTemporaryFile('w', suffix='.Caddyfile') as f:
            f.write(out)
            f.flush()
            r = subprocess.run([caddy, 'validate', '--config', f.name, '--adapter', 'caddyfile'], env=env, capture_output=True, text=True)
            assert r.returncode == 0, r.stderr
            print('caddy validate: ok')


def test_env():
    out = e.env_update('A=1\nSTAGING_HOST=old\n', {'STAGING_HOST': 's.x', 'STAGING_BASIC_AUTH_HASH': '$2a$14$abc'})
    assert "STAGING_HOST='s.x'" in out and "STAGING_BASIC_AUTH_HASH='$2a$14$abc'" in out and out.count('STAGING_HOST') == 1


if __name__ == '__main__':
    for name, fn in list(globals().items()):
        if name.startswith('test_'):
            fn()
            print('ok', name)
