#!/usr/bin/env bash
# Wave 0 / prod_tuning: workers=2, /websocket -> 8072, staging site block in Caddy, shared network resco-edge.
# Run on the VM as the deploy user. Idempotent. Backs up every edited file; rolls back if health checks fail.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$HERE/lib.sh"

CONF="$PROD_DEPLOY/odoo.conf"
CADDYFILE="$PROD_DEPLOY/Caddyfile"
ENVF="$PROD_DEPLOY/.env"
OVERRIDE="$PROD_DEPLOY/docker-compose.override.yml"
CRED="$STAGING_DIR/.staging-credentials"

for f in "$CONF" "$CADDYFILE" "$ENVF" "$PROD_DEPLOY/docker-compose.yml"; do
  [ -f "$f" ] || die "missing $f"
done
command -v python3 >/dev/null || die "python3 required"
for f in "$CONF" "$CADDYFILE" "$ENVF"; do
  [ -r "$f" ] && [ -w "$f" ] || die "$f is not readable/writable by $(id -un) (owner: $(stat -c %U "$f")). Fix with: sudo chown $(id -un) $f"
done
[ -w "$PROD_DEPLOY" ] || die "$PROD_DEPLOY is not writable by $(id -un); backups and the override file go there"
PORTAL_HOST="$(envval "$ENVF" PORTAL_HOST)"
[ -n "$PORTAL_HOST" ] || die "PORTAL_HOST missing in $ENVF"
STAGING_HOST="${STAGING_HOST:-$(envval "$ENVF" STAGING_HOST)}"
if [ -z "$STAGING_HOST" ]; then
  case "$PORTAL_HOST" in portal.*) STAGING_HOST="staging.${PORTAL_HOST#portal.}" ;; *) die "set STAGING_HOST explicitly" ;; esac
fi
log "portal=$PORTAL_HOST staging=$STAGING_HOST"

# Refuse to run if the VM starts compose with explicit -f files (an override would be ignored).
CID="$(prod_compose ps -q odoo 2>/dev/null || true)"
if [ -n "$CID" ]; then
  CFG="$(docker_ inspect -f '{{ index .Config.Labels "com.docker.compose.project.config_files" }}' "$CID" 2>/dev/null || true)"
  case "$CFG" in ""|*docker-compose.yml*) ;; *) die "compose was started with custom files ($CFG); override would not apply" ;; esac
fi

# --- backups (before touching anything)
OVERRIDE_EXISTED=0; [ -f "$OVERRIDE" ] && OVERRIDE_EXISTED=1
for f in "$CONF" "$CADDYFILE" "$ENVF" "$OVERRIDE"; do backup_file "$f"; done
BEFORE_SUM="$(cat "$CONF" "$CADDYFILE" "$ENVF" | sha256sum)"

rollback() {
  log "ROLLING BACK to files saved with suffix .bak-$TS"
  for f in "$CONF" "$CADDYFILE" "$ENVF"; do [ -f "$f.bak-$TS" ] && cp -p "$f.bak-$TS" "$f"; done
  if [ "$OVERRIDE_EXISTED" = 1 ]; then cp -p "$OVERRIDE.bak-$TS" "$OVERRIDE"; else rm -f "$OVERRIDE"; fi
  prod_compose up -d || true
  prod_compose restart odoo || true
  wait_odoo_health prod_compose odoo 45 || log "WARNING: still unhealthy after rollback; check: sudo docker compose logs odoo"
}
fail() { log "FAILED: $*"; rollback; exit 1; }

# --- staging credentials (plain text only in the 600-mode file)
mkdir -p "$STAGING_DIR"
if [ ! -s "$CRED" ]; then
  umask 077
  printf 'user=staging\npassword=%s\n' "$(rand 24)" > "$CRED"
  chmod 600 "$CRED"
  log "created $CRED"
fi
chmod 600 "$CRED"

# --- shared network, override file
docker_ network inspect resco-edge >/dev/null 2>&1 || { docker_ network create resco-edge >/dev/null; log "created network resco-edge"; }
cat > "$OVERRIDE" <<'YAML'
# Managed by Wave 0 (deploy/wave0/prod_tuning.sh). The main docker-compose.yml is not modified.
services:
  odoo:
    volumes:
      - /home/deploy/oca-addons:/mnt/oca:ro
  caddy:
    environment:
      STAGING_HOST: ${STAGING_HOST}
      STAGING_BASIC_AUTH_HASH: ${STAGING_BASIC_AUTH_HASH}
    networks:
      - default
      - resco-edge
networks:
  resco-edge:
    external: true
    name: resco-edge
YAML
mkdir -p "$OCA_DIR"

# --- bcrypt hash (password passed via environment, not argv)
if [ -z "$(envval "$ENVF" STAGING_BASIC_AUTH_HASH)" ] || [ "${ROTATE_STAGING_AUTH:-0}" = 1 ]; then
  PW="$(grep '^password=' "$CRED" | cut -d= -f2-)"; export PW
  python3 "$HERE/edit_config.py" env "$ENVF" "STAGING_HOST=$STAGING_HOST" "STAGING_BASIC_AUTH_HASH=placeholder"
  # shellcheck disable=SC2016  # $PW must expand inside the container, not here
  HASH="$(prod_compose run --rm --no-deps -T -e PW caddy sh -c 'caddy hash-password --plaintext "$PW"' | tail -n1 | tr -d '\r')"
  unset PW
  # shellcheck disable=SC2016
  case "$HASH" in '$2a$'*|'$2b$'*) ;; *) fail "could not generate bcrypt hash" ;; esac
  python3 "$HERE/edit_config.py" env "$ENVF" "STAGING_HOST=$STAGING_HOST" "STAGING_BASIC_AUTH_HASH=$HASH"
else
  python3 "$HERE/edit_config.py" env "$ENVF" "STAGING_HOST=$STAGING_HOST"
fi

# --- config edits
python3 "$HERE/edit_config.py" tune "$CONF" || fail "odoo.conf edit"
python3 "$HERE/edit_config.py" addons "$CONF" "$OCA_DIR" || fail "addons_path edit"
python3 "$HERE/edit_config.py" caddy "$CADDYFILE" || fail "Caddyfile edit"

# --- validate before applying
prod_compose config -q || fail "docker compose config invalid"
prod_compose run --rm --no-deps -T caddy caddy validate --config /etc/caddy/Caddyfile >/dev/null 2>&1 || fail "caddy validate failed"
log "configuration validated"

AFTER_SUM="$(cat "$CONF" "$CADDYFILE" "$ENVF" | sha256sum)"
prod_compose up -d || fail "compose up"
if [ "$BEFORE_SUM" != "$AFTER_SUM" ]; then prod_compose restart odoo || fail "odoo restart"; fi
prod_compose exec -T caddy caddy reload --config /etc/caddy/Caddyfile >/dev/null 2>&1 || fail "caddy reload"

# --- health checks
wait_odoo_health prod_compose odoo 60 || fail "odoo unhealthy"
sleep 3
CODE="$(https_status "$PORTAL_HOST" /web/health)"
[ "$CODE" = 200 ] || fail "https://$PORTAL_HOST/web/health returned $CODE"
WS="$(ws_status "$PORTAL_HOST")"
case "$WS" in 101|400|426) log "websocket route ok (HTTP $WS)" ;; *) fail "websocket check returned '$WS' (502/000 means gevent port not reachable)" ;; esac

log "OK: workers=2 active, /websocket -> 8072, staging block ready for $STAGING_HOST"
log "staging credentials: $CRED (mode 600; not printed)"
