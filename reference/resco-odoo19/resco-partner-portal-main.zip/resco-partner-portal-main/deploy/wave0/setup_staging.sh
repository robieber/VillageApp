#!/usr/bin/env bash
# Wave 0 / setup_staging: create /home/deploy/resco-staging and start an empty staging stack.
# Idempotent: existing .env, odoo.conf passwords and volumes are kept. Run refresh_staging.sh afterwards for data.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$HERE/lib.sh"

TEMPLATES="$KIT_DIR/staging"
PROD_ENV="$PROD_DEPLOY/.env"
S="$STAGING_DIR"
[ -f "$PROD_ENV" ] || die "missing $PROD_ENV"
[ -f "$TEMPLATES/docker-compose.yml" ] || die "missing staging templates in $TEMPLATES"

PORTAL_HOST="$(envval "$PROD_ENV" PORTAL_HOST)"
STAGING_HOST="${STAGING_HOST:-$(envval "$PROD_ENV" STAGING_HOST)}"
if [ -z "$STAGING_HOST" ]; then
  case "$PORTAL_HOST" in portal.*) STAGING_HOST="staging.${PORTAL_HOST#portal.}" ;; *) die "set STAGING_HOST" ;; esac
fi

log "creating directories"
mkdir -p "$S/deploy" "$S/odoo/addons" "$OCA_DIR"
docker_ network inspect resco-edge >/dev/null 2>&1 || { docker_ network create resco-edge >/dev/null; log "created network resco-edge"; }

if [ ! -f "$S/deploy/.env" ]; then
  log "writing staging .env (random passwords, not printed)"
  umask 077
  {
    echo "DB_PASSWORD=$(rand 28)"
    echo "ADMIN_PASSWORD=$(rand 20)"
    echo "MASTER_PASSWORD=$(rand 28)"
    echo "PORTAL_HOST=$STAGING_HOST"
    echo "COMPANY_NAME=$(envval "$PROD_ENV" COMPANY_NAME)"
    echo "POWERSIGHT_URL=$(envval "$PROD_ENV" POWERSIGHT_URL)"
    echo "POWERSIGHT_USER=$(envval "$PROD_ENV" POWERSIGHT_USER)"
    echo "POWERSIGHT_PASSWORD=$(envval "$PROD_ENV" POWERSIGHT_PASSWORD)"
  } > "$S/deploy/.env"
  chmod 600 "$S/deploy/.env"
else
  log ".env exists, kept"
fi

backup_file "$S/deploy/docker-compose.yml"
cp "$TEMPLATES/docker-compose.yml" "$S/deploy/docker-compose.yml"

if [ ! -f "$S/deploy/odoo.conf" ]; then
  MASTER="$(envval "$S/deploy/.env" MASTER_PASSWORD)"
  umask 077
  sed "s|__MASTER_PASSWORD__|$MASTER|" "$TEMPLATES/odoo.conf" > "$S/deploy/odoo.conf"
  chmod 644 "$S/deploy/odoo.conf"   # read by the odoo container user
else
  log "odoo.conf exists, kept"
fi
python3 "$HERE/edit_config.py" addons "$S/deploy/odoo.conf" "$OCA_DIR"

if [ -z "$(ls -A "$S/odoo/addons" 2>/dev/null)" ]; then
  log "copying production addons into staging"
  cp -a "$PROD_DIR/odoo/addons/." "$S/odoo/addons/"
fi

staging_compose config -q || die "staging compose invalid"
log "starting staging db and odoo (no database yet; refresh_staging.sh loads data)"
staging_compose up -d db
for _ in $(seq 1 30); do
  staging_compose exec -T db pg_isready -U odoo >/dev/null 2>&1 && break
  sleep 2
done
staging_compose up -d odoo
sleep 5
staging_compose ps
log "OK. Staging host: $STAGING_HOST (needs prod_tuning for the Caddy block). Next: refresh_staging"
