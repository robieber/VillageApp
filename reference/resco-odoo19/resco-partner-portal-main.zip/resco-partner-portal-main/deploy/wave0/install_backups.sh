#!/usr/bin/env bash
# Wave 0 / install_backups: install nightly cron (01:30 Asia/Manila) and run one backup now.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
. "$HERE/lib.sh"

DEST=/home/deploy/wave0-bin
CRON=/etc/cron.d/resco-backup
USER_NAME="$(id -un)"
mkdir -p "$DEST" "$BACKUP_DIR"
install -m 755 "$HERE/backup_prod.sh" "$DEST/backup_prod.sh"   # stable copy, independent of the kit directory
[ -f "$CRON" ] && sudo cp -p "$CRON" "$CRON.bak-$TS"
# Ubuntu's cron ignores CRON_TZ, so schedule in the VM's own timezone: 01:30 PHT = 17:30 UTC.
VM_TZ="$(timedatectl show -p Timezone --value 2>/dev/null || cat /etc/timezone 2>/dev/null || echo UTC)"
case "$VM_TZ" in
  UTC|Etc/UTC) WHEN="30 17" ;;
  Asia/Manila|Asia/Singapore) WHEN="30 1" ;;
  *) die "VM timezone $VM_TZ: set the cron time manually" ;;
esac
log "VM timezone $VM_TZ: backup at '$WHEN * * *'"
sudo tee "$CRON" >/dev/null <<CRONTAB
# Managed by Wave 0 (install_backups.sh)
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
$WHEN * * * $USER_NAME $DEST/backup_prod.sh >> $BACKUP_DIR/cron.out 2>&1
CRONTAB
sudo chmod 644 "$CRON"
log "installed $CRON"
log "running one backup now"
"$DEST/backup_prod.sh"
log "OK. Logs: $BACKUP_DIR/backup.log"
