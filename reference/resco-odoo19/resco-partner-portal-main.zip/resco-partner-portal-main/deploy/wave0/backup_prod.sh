#!/usr/bin/env bash
# Wave 0 / backup_prod: pg_dump -Fc + filestore tarball into /home/deploy/backups/YYYYmmdd-HHMM/, keep 7 days.
# Runs from cron as the deploy user (or manually). Aborts if disk free < 15%.
set -euo pipefail
export TZ=Asia/Manila
BACKUP_DIR="${BACKUP_DIR:-/home/deploy/backups}"
PROD_DIR="${PROD_DIR:-/home/deploy/resco-partner-portal}"
DOCKER="${DOCKER:-sudo docker}"
PROD_DB="${PROD_DB:-resco}"
KEEP_DAYS="${KEEP_DAYS:-7}"
MIN_FREE_PCT="${MIN_FREE_PCT:-15}"
mkdir -p "$BACKUP_DIR"
LOG="$BACKUP_DIR/backup.log"
log() { printf '%s %s\n' "$(date '+%F %T %Z')" "$*" | tee -a "$LOG"; }

FREE="$(df --output=pcent "$BACKUP_DIR" | tail -n1 | tr -dc 0-9)"
FREE=$((100 - FREE))
if [ "$FREE" -lt "$MIN_FREE_PCT" ]; then log "ABORT: only ${FREE}% disk free (< ${MIN_FREE_PCT}%)"; exit 1; fi

DEST="$BACKUP_DIR/$(date +%Y%m%d-%H%M)"
mkdir -p "$DEST"
fail() { log "FAILED: $*; removing incomplete $DEST"; rm -rf "$DEST"; exit 1; }
cd "$PROD_DIR/deploy"
DBC="$($DOCKER compose ps -q db)"; ODC="$($DOCKER compose ps -q odoo)"
[ -n "$DBC" ] && [ -n "$ODC" ] || fail "containers not running"

log "start dump of $PROD_DB"
$DOCKER exec "$DBC" pg_dump -U odoo -Fc "$PROD_DB" > "$DEST/$PROD_DB.dump" || fail "pg_dump"
$DOCKER exec -i "$DBC" pg_restore --list < "$DEST/$PROD_DB.dump" > /dev/null || fail "pg_restore --list verification"
[ -s "$DEST/$PROD_DB.dump" ] || fail "empty dump"

log "start filestore archive"
if $DOCKER exec "$ODC" test -d "/var/lib/odoo/filestore/$PROD_DB"; then
  $DOCKER exec "$ODC" tar -C "/var/lib/odoo/filestore/$PROD_DB" -cf - . | gzip > "$DEST/filestore.tar.gz" || fail "filestore tar"
  gzip -t "$DEST/filestore.tar.gz" || fail "filestore archive corrupt"
else
  log "WARNING: filestore directory not found"
fi
cp -p "$PROD_DIR/deploy/odoo.conf" "$DEST/odoo.conf" 2>/dev/null || true
chmod -R go-rwx "$DEST"

log "OK $DEST dump=$(du -h "$DEST/$PROD_DB.dump" | cut -f1) filestore=$(du -h "$DEST/filestore.tar.gz" 2>/dev/null | cut -f1 || echo none)"
find "$BACKUP_DIR" -maxdepth 1 -mindepth 1 -type d -name '[0-9]*-[0-9]*' -mtime +"$((KEEP_DAYS - 1))" -print0 \
  | while IFS= read -r -d '' old; do log "pruning $old"; rm -rf "$old"; done
