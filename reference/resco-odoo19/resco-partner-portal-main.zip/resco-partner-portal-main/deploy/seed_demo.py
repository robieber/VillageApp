"""Demo data for testing the portal: 2 companies, 3 accounts, 3 users and 12 months of bills loaded through the
real loader (so it exercises validation and versioning too). Run with:
    SEED_PASSWORD='...' odoo shell -d <db> < seed_demo.py
Never run on a production database.
"""
import os
import random

pw = os.environ.get('SEED_PASSWORD')
assert pw, 'Set SEED_PASSWORD'  # noqa: S101
Partner, Account, Users = env['res.partner'], env['resco.account'], env['res.users']  # noqa: F821
portal = env.ref('base.group_portal')  # noqa: F821
admin = env.ref('base.user_admin')  # noqa: F821


def company(name):
    return Partner.search([('name', '=', name), ('is_company', '=', True)], limit=1) or Partner.create(
        {'name': name, 'is_company': True, 'website': 'https://example.com', 'street': '1 Demo Street', 'city': 'Makati City'})


def account(name, csin, comp, kw):
    return Account.search([('csin', '=', csin)], limit=1) or Account.create(
        {'name': name, 'csin': csin, 'partner_id': comp.id, 'contracted_capacity_kw': kw, 'sam_id': admin.id,
         'service_address': f'{name} Plant Road - Laguna', 'pricing_product': 'Fixed Price 24M'})


def user(login, name, comp, role, accounts):
    u = Users.search([('login', '=', login)], limit=1)
    if not u:
        p = Partner.create({'name': name, 'email': login, 'parent_id': comp.id})
        u = Users.with_context(no_reset_password=True).create(
            {'login': login, 'partner_id': p.id, 'group_ids': [(6, 0, portal.ids)], 'resco_company_role': role})
    u.password = pw
    for a in accounts:
        if not env['resco.account.access'].search([('user_id', '=', u.id), ('account_id', '=', a.id)]):  # noqa: F821
            env['resco.account.access'].create({'user_id': u.id, 'account_id': a.id})  # noqa: F821
    return u


def pdf(text):
    body = f'BT /F1 18 Tf 72 720 Td ({text}) Tj ET'.encode()
    objs = [b'<< /Type /Catalog /Pages 2 0 R >>', b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
            b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
            b'<< /Length %d >>\nstream\n' % len(body) + body + b'\nendstream',
            b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
    out, offs = b'%PDF-1.4\n', []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += b'%d 0 obj\n' % i + o + b'\nendobj\n'
    x = len(out)
    out += b'xref\n0 %d\n0000000000 65535 f \n' % (len(objs) + 1) + b''.join(b'%010d 00000 n \n' % o for o in offs)
    return out + b'trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n' % (len(objs) + 1, x)


acme, beta = company('Acme Mills Corp'), company('Beta Foods Inc')
a1 = account('Acme Mill 1', 'CSIN-0001', acme, 500)
a2 = account('Acme Mill 2', 'CSIN-0002', acme, 750)
b1 = account('Beta Plant', 'CSIN-0003', beta, 1200)
user('admin@acme.test', 'Ana Acme', acme, 'admin', [a1, a2])
user('viewer@acme.test', 'Vic Acme', acme, 'viewer', [a2])
user('admin@beta.test', 'Ben Beta', beta, 'admin', [b1])

random.seed(7)
HDR = ('BILL_KEY,CSIN,ACCOUNT_NAME,SERVICE_ADDRESS,BILL_NUMBER,BILL_MONTH,BILL_YEAR,BILL_DATE,BILLING_PERIOD_FROM,'
       'BILLING_PERIOD_TO,DUE_DATE,PRICING_PRODUCT,CONTRACTED_CAPACITY_KW,ENERGY_KWH,MEQ_KWH,CURRENT_CHARGES,VAT_AMOUNT,'
       'PREVIOUS_BALANCE,ADJUSTMENTS,TOTAL_AMOUNT_DUE,CURRENCY,PAYMENT_STATUS,PDF_FILE_NAME,IS_REVISED,'
       'SUPERSEDES_BILL_KEY,SOURCE_SYSTEM,EXTRACT_BATCH_ID,EXTRACT_TIMESTAMP')
COMP = 'BILL_KEY,COMPONENT_CODE,COMPONENT_NAME,QUANTITY,UOM,RATE,AMOUNT,SORT_ORDER'
PAY = 'BILL_KEY,PAYMENT_STATUS,AMOUNT_PAID,OUTSTANDING_BALANCE,LAST_PAYMENT_DATE,STATUS_AS_OF'
hdr, comp, pay, pdfs = [HDR], [COMP], [PAY], {}
for acc, base in ((a1, 480000), (a2, 720000), (b1, 1100000)):
    for k in range(12):
        y, m = (2025 + (9 + k) // 12, (9 + k) % 12 + 1)
        kwh = round(base / 9.5 * random.uniform(0.85, 1.15))
        parts = [('GEN', 'Generation', 5.1), ('TRANS', 'Transmission', 0.9), ('SYSLOSS', 'System Loss', 0.4), ('UC', 'Universal Charges', 0.5)]
        amounts = [(c, n, round(kwh * r, 2)) for c, n, r in parts]
        vat = round(sum(a for _c, _n, a in amounts) * 0.12, 2)
        current = round(sum(a for _c, _n, a in amounts), 2)
        total = round(current + vat, 2)
        key = f'{acc.csin}-{y}{m:02d}-{acc.csin[-4:]}{y % 100}{m:02d}'
        fn = f'{y}{m:02d}-{acc.csin}.pdf'
        pdfs[fn] = pdf(f'{acc.name} bill {y}-{m:02d}')
        ny, nm = (y + (m == 12), m % 12 + 1)
        hdr.append(','.join(str(x) for x in [
            key, acc.csin, acc.name, acc.service_address, key.rsplit('-', 1)[1], m, y, f'{y}-{m:02d}-28', f'{y}-{m:02d}-01',
            f'{y}-{m:02d}-28', f'{ny}-{nm:02d}-15', 'Fixed Price 24M', acc.contracted_capacity_kw, kwh, round(kwh * 0.97),
            current, vat, 0, 0, total, 'PHP', 'UNPAID', fn, 'N', '', 'CMS-RES', 'SEED', f'{y}-{m:02d}-28T10:00:00+08:00']))
        for i, (c, n, a) in enumerate(amounts, 1):
            comp.append(f'{key},{c},{n},{kwh},KWH,,{a},{i * 10}')
        if k < 10:
            pay.append(f'{key},PAID,{total},0,{ny}-{nm:02d}-10,{ny}-{nm:02d}-10T09:00:00+08:00')
files = {'MPWR_BILL_HDR_SEED.csv': '\n'.join(hdr).encode(), 'MPWR_BILL_COMP_SEED.csv': '\n'.join(comp).encode(),
         'MPWR_PAY_STAT_SEED.csv': '\n'.join(pay).encode(), **pdfs}
# Hourly readings for the latest bill month of each account
HR = ['CSIN,INTERVAL_START,KWH,KW_DEMAND']
for acc, base in ((a1, 480000), (a2, 720000), (b1, 1100000)):
    for d in range(1, 31):
        for h in range(24):
            load = base / 9.5 / 720 * (1.4 if 8 <= h <= 18 else 0.6) * random.uniform(0.9, 1.1)
            HR.append(f'{acc.csin},2026-08-{d:02d}T{h:02d}:00:00+08:00,{load:.2f},{load * 1.1:.2f}')
files['MPWR_ENERGY_HRLY_SEED.csv'] = '\n'.join(HR).encode()
batch = env['resco.upload.batch'].load('manual', files, overwrite=True, source_name='seed_demo')  # noqa: F821
env.cr.commit()  # noqa: F821
print('Seeded:', batch.summary, '| log in as admin@acme.test / viewer@acme.test / admin@beta.test')
