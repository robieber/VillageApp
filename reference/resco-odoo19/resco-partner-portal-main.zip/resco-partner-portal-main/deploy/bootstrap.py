"""One-time bootstrap for a fresh database. Run with:
    odoo shell -d <db> < bootstrap.py
Sets the company to the Philippines (PHP), the admin timezone and password, and the public base URL.
Environment variables (optional): COMPANY_NAME, BASE_URL, ADMIN_PASSWORD
"""
import os

company = env.company  # noqa: F821  (provided by odoo shell)
ph = env.ref('base.ph')  # noqa: F821
company.write({'name': os.environ.get('COMPANY_NAME', 'RESCo'), 'country_id': ph.id})
if company.currency_id != env.ref('base.PHP'):  # noqa: F821
    company.currency_id = env.ref('base.PHP')  # noqa: F821
admin = env.ref('base.user_admin')  # noqa: F821
admin.tz = 'Asia/Manila'
if os.environ.get('ADMIN_PASSWORD'):
    admin.password = os.environ['ADMIN_PASSWORD']  # never leave admin/admin on a public server
base_url = os.environ.get('BASE_URL')
if base_url:
    env['ir.config_parameter'].set_param('web.base.url', base_url)  # noqa: F821
    env['ir.config_parameter'].set_param('web.base.url.freeze', 'True')  # noqa: F821
env.cr.commit()  # noqa: F821
print('Bootstrap complete for', company.name, company.currency_id.name)
