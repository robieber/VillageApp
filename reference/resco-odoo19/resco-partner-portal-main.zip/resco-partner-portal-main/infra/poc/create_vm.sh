#!/usr/bin/env bash
# Run in Google Cloud Shell. Creates the RESCo POC server from nothing: static IP, firewall, daily snapshots, VM with Docker.
# Idempotent: re-running skips what exists. Never deletes anything.
#   PROJECT=resco-poc ./create_vm.sh
set -euo pipefail
PROJECT="${PROJECT:?set PROJECT to your GCP project id, e.g. PROJECT=resco-poc}"
ZONE="${ZONE:-asia-southeast1-b}"          # Singapore, closest region to the Philippines
INSTANCE="${INSTANCE:-resco-odoo}"
TYPE="${TYPE:-e2-standard-2}"              # 2 vCPU, 8 GB. e2-medium (4 GB) is the floor for a demo.
DISK_GB="${DISK_GB:-50}"
REGION="${ZONE%-*}"
G=(gcloud --project "$PROJECT" --quiet)
die() { echo "ERROR: $*" >&2; exit 1; }
command -v gcloud >/dev/null || die "run this in Google Cloud Shell"

echo "[1] Enable the Compute Engine API"
"${G[@]}" services enable compute.googleapis.com

echo "[2] Reserve a static external IP (resco-odoo-ip)"
"${G[@]}" compute addresses describe resco-odoo-ip --region "$REGION" >/dev/null 2>&1 || \
  "${G[@]}" compute addresses create resco-odoo-ip --region "$REGION"
IP="$("${G[@]}" compute addresses describe resco-odoo-ip --region "$REGION" --format='value(address)')"

echo "[3] Firewall: allow web (80, 443) from anywhere; SSH comes from the default rule"
"${G[@]}" compute firewall-rules describe resco-allow-web >/dev/null 2>&1 || \
  "${G[@]}" compute firewall-rules create resco-allow-web --network default --direction INGRESS \
    --allow tcp:80,tcp:443 --target-tags resco-web --source-ranges 0.0.0.0/0

echo "[4] Create the VM ($TYPE, Debian 12, ${DISK_GB} GB) with Docker installed on first boot"
if ! "${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" >/dev/null 2>&1; then
  cat > /tmp/resco-startup.sh <<'S'
#!/bin/bash
set -e
[ -f /var/lib/resco-bootstrapped ] && exit 0
apt-get update
apt-get install -y ca-certificates curl git ufw unattended-upgrades
curl -fsSL https://get.docker.com | sh
id deploy >/dev/null 2>&1 || useradd -m -s /bin/bash -G docker,sudo deploy
echo 'deploy ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/deploy
# Automatic security updates, with a reboot at 03:30 Philippine time (19:30 UTC) when one is needed.
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'CFG'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
CFG
cat > /etc/apt/apt.conf.d/52resco-unattended <<'CFG'
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "true";
Unattended-Upgrade::Automatic-Reboot-WithUsers "true";
Unattended-Upgrade::Automatic-Reboot-Time "19:30";
CFG
systemctl enable --now unattended-upgrades
touch /var/lib/resco-bootstrapped
S
  "${G[@]}" compute instances create "$INSTANCE" --zone "$ZONE" --machine-type "$TYPE" \
    --image-family debian-12 --image-project debian-cloud \
    --boot-disk-size "${DISK_GB}GB" --boot-disk-type pd-balanced \
    --address "$IP" --tags resco-web --metadata-from-file startup-script=/tmp/resco-startup.sh
else
  echo "instance $INSTANCE already exists"
fi

echo "[5] Daily disk snapshot at 02:00 PHT, keep 7 days"
"${G[@]}" compute resource-policies describe resco-odoo-daily --region "$REGION" >/dev/null 2>&1 || \
  "${G[@]}" compute resource-policies create snapshot-schedule resco-odoo-daily --region "$REGION" \
    --daily-schedule --start-time 18:00 --max-retention-days 7 --storage-location "$REGION"
"${G[@]}" compute disks add-resource-policies "$INSTANCE" --zone "$ZONE" --resource-policies resco-odoo-daily 2>/dev/null || true

echo
echo "Done. Server IP: $IP"
echo "Portal address to use in .env (HTTPS certificate is automatic): PORTAL_HOST=portal.${IP}.sslip.io"
echo "Connect:  gcloud --project $PROJECT compute ssh $INSTANCE --zone $ZONE"
echo "Docker needs about 2 minutes after first boot; check with: sudo tail -n3 /var/log/syslog | grep startup-script"
