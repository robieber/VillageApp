#!/usr/bin/env bash
# Run in Cloud Shell once. Creates a log store with a 1-year retention, routes the portal's container logs into it,
# and adds counters for failed sign-ins and errors that you can alert on.
#   PROJECT=resco-512413 bash infra/poc/setup_logging.sh
set -euo pipefail
PROJECT="${PROJECT:?set PROJECT}"
LOCATION="${LOCATION:-asia-southeast1}"
RETENTION_DAYS="${RETENTION_DAYS:-365}"
BUCKET=resco-audit
G=(gcloud --project "$PROJECT" --quiet)

"${G[@]}" services enable logging.googleapis.com monitoring.googleapis.com

echo "[1] Log bucket $BUCKET ($RETENTION_DAYS days, $LOCATION)"
"${G[@]}" logging buckets describe "$BUCKET" --location "$LOCATION" >/dev/null 2>&1 || \
  "${G[@]}" logging buckets create "$BUCKET" --location "$LOCATION" --retention-days "$RETENTION_DAYS" \
    --description "RESCo portal container and audit logs"

echo "[2] Route container logs from the VM into it"
FILTER='logName="projects/'"$PROJECT"'/logs/gcplogs-docker-driver"'
"${G[@]}" logging sinks describe resco-audit-sink >/dev/null 2>&1 || \
  "${G[@]}" logging sinks create resco-audit-sink \
    "logging.googleapis.com/projects/$PROJECT/locations/$LOCATION/buckets/$BUCKET" --log-filter "$FILTER"

echo "[3] Counters"
metric() {  # name, description, filter
  "${G[@]}" logging metrics describe "$1" >/dev/null 2>&1 || \
    "${G[@]}" logging metrics create "$1" --description "$2" --log-filter "$3"
}
metric resco_login_failed "Failed portal sign-ins" \
  "$FILTER"' AND jsonPayload.message:"AUDIT" AND jsonPayload.message:"login_failed"'
metric resco_server_errors "Odoo errors and criticals" \
  "$FILTER"' AND jsonPayload.container.name:"odoo" AND (jsonPayload.message:" ERROR " OR jsonPayload.message:" CRITICAL ")'
metric resco_http_5xx "Web server 5xx responses" \
  "$FILTER"' AND jsonPayload.container.name:"caddy" AND jsonPayload.message:"\"status\":5"'

cat <<EOM

Done.
 - Read logs:  Console > Logging > Logs Explorer, filter  logName:"gcplogs-docker-driver"
 - Stored 1 year in bucket $BUCKET (Logging > Logs Storage). To make the retention impossible to shorten, lock it
   with: gcloud logging buckets update $BUCKET --location=$LOCATION --locked   (this cannot be undone)
 - Alerts: Console > Monitoring > Alerting > Create policy, pick the metric resco_login_failed (for example more
   than 20 in 5 minutes) or resco_server_errors, and choose an email notification channel.
 - Then on the VM: put COMPOSE_FILE=docker-compose.yml:docker-compose.gcp-logging.yml in deploy/.env and run
   sudo docker compose up -d --force-recreate
EOM
