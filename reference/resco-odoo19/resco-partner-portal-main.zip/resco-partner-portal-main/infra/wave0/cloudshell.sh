#!/usr/bin/env bash
# Wave 0, step 1: run in Google Cloud Shell. Snapshot, daily snapshot policy, reserved IP, resize to e2-standard-2.
# Idempotent. Never deletes anything. Override defaults with env vars, e.g. ASSUME_YES=1 for non-interactive use.
set -euo pipefail

PROJECT="${PROJECT:-resco-poc}"
ZONE="${ZONE:-asia-southeast1-b}"
INSTANCE="${INSTANCE:-resco-odoo}"
EXPECTED_IP="${EXPECTED_IP:-}"
TARGET_TYPE="${TARGET_TYPE:-e2-standard-2}"
OLD_TYPE="${OLD_TYPE:-e2-small}"
POLICY="${POLICY:-resco-odoo-daily}"
STEP=0
step() { STEP=$((STEP + 1)); printf '\n[%s] %s\n' "$STEP" "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

command -v gcloud >/dev/null || die "gcloud not found (run this in Google Cloud Shell)"
REGION="${ZONE%-*}"
G=(gcloud --project "$PROJECT" --quiet)

step "Verify project, zone and instance"
"${G[@]}" projects describe "$PROJECT" --format='value(projectId)' >/dev/null || die "cannot access project $PROJECT"
STATUS="$("${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" --format='value(status)')" || die "instance $INSTANCE not found in $ZONE"
CURRENT_TYPE="$("${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" --format='value(machineType.basename())')"
BOOT_DISK="$("${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" --format='value(disks[0].source.basename())')"
IP="$("${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" --format='value(networkInterfaces[0].accessConfigs[0].natIP)')"
echo "project=$PROJECT zone=$ZONE instance=$INSTANCE status=$STATUS machine=$CURRENT_TYPE boot_disk=$BOOT_DISK ip=$IP"
[ -n "$BOOT_DISK" ] || die "could not determine boot disk"
if [ -n "$EXPECTED_IP" ] && [ "$IP" != "$EXPECTED_IP" ]; then
  echo "WARNING: external IP $IP differs from expected $EXPECTED_IP"
fi

step "Create on-demand snapshot of the boot disk"
SNAP="resco-odoo-pre-wave0-$(date -u +%Y%m%d-%H%M%S)"
"${G[@]}" compute disks snapshot "$BOOT_DISK" --zone "$ZONE" --snapshot-names "$SNAP" \
  --description "Before Wave 0 resize" --storage-location "$REGION"
echo "snapshot created: $SNAP"

step "Daily snapshot schedule ($POLICY: 18:00 UTC = 02:00 PHT, keep 7 days)"
if "${G[@]}" compute resource-policies describe "$POLICY" --region "$REGION" >/dev/null 2>&1; then
  echo "policy $POLICY already exists"
else
  "${G[@]}" compute resource-policies create snapshot-schedule "$POLICY" --region "$REGION" \
    --daily-schedule --start-time 18:00 --max-retention-days 7 \
    --on-source-disk-delete keep-auto-snapshots --storage-location "$REGION"
fi
if "${G[@]}" compute disks describe "$BOOT_DISK" --zone "$ZONE" --format='value(resourcePolicies)' | grep -q "/$POLICY"; then
  echo "policy already attached to $BOOT_DISK"
else
  "${G[@]}" compute disks add-resource-policies "$BOOT_DISK" --zone "$ZONE" --resource-policies "$POLICY"
fi

step "Confirm external IP $IP is a reserved static address"
ADDR_JSON="$("${G[@]}" compute addresses list --filter="address=$IP" --format='value(name,status,addressType)')"
if [ -n "$ADDR_JSON" ]; then
  echo "reserved address found: $ADDR_JSON"
else
  NAME="resco-odoo-ip"
  echo "$IP is ephemeral; promoting to a reserved address named $NAME"
  "${G[@]}" compute addresses create "$NAME" --addresses "$IP" --region "$REGION"
fi

step "Resize $CURRENT_TYPE -> $TARGET_TYPE (stops the VM for about 1-2 minutes; the site is down meanwhile)"
if [ "$CURRENT_TYPE" = "$TARGET_TYPE" ]; then
  echo "already $TARGET_TYPE, skipping stop/resize"
  [ "$STATUS" = "RUNNING" ] || "${G[@]}" compute instances start "$INSTANCE" --zone "$ZONE"
else
  if [ "${ASSUME_YES:-}" != "1" ]; then
    printf "Type 'yes' to stop %s and resize it to %s: " "$INSTANCE" "$TARGET_TYPE"
    read -r ANSWER
    [ "$ANSWER" = "yes" ] || die "aborted (nothing stopped). Snapshot $SNAP and schedule remain."
  fi
  if [ "$STATUS" != "TERMINATED" ]; then
    "${G[@]}" compute instances stop "$INSTANCE" --zone "$ZONE"
  fi
  "${G[@]}" compute instances set-machine-type "$INSTANCE" --zone "$ZONE" --machine-type "$TARGET_TYPE"
  "${G[@]}" compute instances start "$INSTANCE" --zone "$ZONE"
fi

step "Wait for RUNNING"
for _ in $(seq 1 40); do
  S="$("${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" --format='value(status)')"
  [ "$S" = "RUNNING" ] && break
  sleep 5
done
[ "${S:-}" = "RUNNING" ] || die "instance is $S, expected RUNNING"
NEW_TYPE="$("${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" --format='value(machineType.basename())')"
NEW_IP="$("${G[@]}" compute instances describe "$INSTANCE" --zone "$ZONE" --format='value(networkInterfaces[0].accessConfigs[0].natIP)')"

step "Done"
echo "instance=$INSTANCE status=RUNNING machine=$NEW_TYPE external_ip=$NEW_IP"
echo "Docker containers use restart: unless-stopped and should be back in a minute: https://portal.${NEW_IP}.sslip.io/web/health"
echo
echo "Rollback (stop, back to $OLD_TYPE, start):"
echo "  gcloud --project $PROJECT compute instances stop $INSTANCE --zone $ZONE && \\"
echo "  gcloud --project $PROJECT compute instances set-machine-type $INSTANCE --zone $ZONE --machine-type $OLD_TYPE && \\"
echo "  gcloud --project $PROJECT compute instances start $INSTANCE --zone $ZONE"
echo "Restore disk from snapshot only if the disk is damaged: snapshot name $SNAP"
