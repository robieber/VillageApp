# RESCo Partner Portal

Customer portal for a Retail Electricity Supplier (RES) in the Philippines, built on Odoo 19 Community.
Adapted from the Araw Solar consumer app (same server kit, API pattern, auth and React app), with the solar
billing, tariff, contract and inverter modules removed.

Requirements and fit-gap: `RESCo-Partner-Portal-Odoo-Fit-Gap.xlsx` (kept outside the repo; see docs/BUILD-PLAN.md).

## Decisions in force

| Topic | Decision |
|---|---|
| Account master | Odoo. Salesforce is not used. Companies, service accounts (CSIN), contacts and the Strategic Account Manager live in Odoo. |
| Bills | Produced by CMS-RES: bill header and cost component CSVs, one PDF per bill, optional payment status and hourly energy CSVs. Loaded by SFTP or manual upload through the same loader. See docs/CMS-RES-BILLING-FILES.md. |
| Re-loading a bill | Replaces it after confirmation (manual) or automatically with a log entry (SFTP). The old version is archived, not deleted. |
| Content approval, email open/bounce tracking | Deferred. |
| Copywriting, data migration from the existing portal | Out of scope. |

## What is built (wave R1: Phase 1 backend)

`odoo/addons/resco_portal`

| Area | Status |
|---|---|
| Accounts, per-account user access, same-company rule, portal record rules | Done |
| Bill model with versions, charge and energy lines | Done |
| CSV validation and loader (bill header, cost components, payment status, hourly energy), ZIP handling, all-or-nothing per bill | Done |
| Manual upload wizard (check, then confirm) | Done |
| SFTP collector with host-key pinning, marker files, processed and error folders | Done |
| Bill-ready email, due-date reminders (configurable days) | Done |
| User auto-deactivation (2 months after last bill, 3 months inactive) with 2-week warning | Done |
| Event log (logins, downloads, uploads, access changes, deactivations) | Done |
| JSON API `/api/resco/v1`: login, profile, accounts, bills, PDF, billing history, energy, company users, logo | Done |
| Back-office roles: Read-only, Billing Operations, Account Administrator, Administrator | Done |

Not yet built, in order: React account area (wave R1b), website CMS pages and menus, helpdesk tickets,
CSV batch user creation, reports, Google Analytics, branding. See docs/BUILD-PLAN.md.

## Proof of payment (wave R2a)

Customers (Customer Administrator or Billing contact) submit proof under Payments: date, bank, mode, amount, one or more
accounts and bills with a peso amount each (must add up), and 1 to 5 PNG, JPEG or PDF files up to 5 MB, checked by content.
Billing Operations validate under RESCo Portal > Billing > Payments to Validate (Confirm, or Reject with remarks). The
validation state lives on the submission; a bill's payment status still comes only from CMS-RES. Emails: received (customer),
new submission (staff, addresses in Settings, else the account managers), decision (customer).

## Helpdesk, assistant and content (wave R2b)

- Support: customers raise a request per account with a category and attachments, or message their account manager. Routing:
  the category owner, or the account's Strategic Account Manager for categories flagged for it (Configuration > Ticket
  Categories and Routing). Staff reply in the ticket chatter; a normal message goes to the customer, a note stays internal.
- Assistant: Settings > RESCo Portal > AI Assistant. Paste a Gemini API key (Google AI Studio), tick Enable. It reads only the
  signed-in customer's data through server-side tools, never changes data, and opens a ticket only after the customer confirms.
- Privacy notice: Content > Privacy Notices. Publishing a new version asks every customer to accept again; acceptances are logged.
- Portal popups, file library (versions, ZIP download), user CSV import (Check, then Import), and email templates are under the Content menu.
- resco_website: Energy Bulletin, Regulatory Updates and Advisories blogs, events, Payment Guidelines and Energy Solutions pages.

## Tests

* `tests/pure`: file rules, SFTP inbox, ZIP safety, lifecycle dates, password rules, chart aggregation. Run with
  `python -m pytest tests/pure`.
* `odoo/addons/resco_portal/tests`: Odoo-level tests (access isolation, loader, replacement, API, SFTP, lifecycle).
  Run by the `Verify` workflow in an Odoo 19 container.

## Run it

```
cd deploy
cp .env.example .env
docker compose build
docker compose up -d db
docker compose run --rm odoo odoo -d resco -i resco_portal,resco_leads,resco_website,l10n_ph --stop-after-init
docker compose run --rm -T odoo odoo shell -d resco < bootstrap.py
docker compose run --rm -T -e SEED_PASSWORD=... odoo odoo shell -d resco < seed_demo.py   # test data only
docker compose up -d
```

`deploy/wave0`, `deploy/staging` and `infra/` are carried over from the Araw Solar repo unchanged and still refer to
its servers. Adapt them once RESCo's hosting is decided.

## Portal app theme and build

The customer screens are a React app in `app/` (MPower blue and orange). All colours live in `app/client/src/index.css`.
`npm run dev:mock` runs it with made-up data; `npm run build:odoo` writes the build into `odoo/addons/resco_portal/static/app`
(commit the result), and Odoo serves it at `/portal-app`.
